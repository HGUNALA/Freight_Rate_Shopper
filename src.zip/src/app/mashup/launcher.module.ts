import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { M3OdinModule } from '@infor-up/m3-odin-angular';
import { SohoComponentsModule } from 'ids-enterprise-ng';
import { DemoModule } from '../demo/demo.module';
import { LauncherComponent } from './launcher.component';
import { LauncherRoutingModule } from './launcher-routing.module';
import { OrderDetailComponent } from './components/order-detail/order-detail.component';
import { MainPageComponent } from './pages/main-page/main-page.component';
import { DeliveryAddressComponent } from './components/delivery-address/delivery-address.component';
import { RateListComponent } from './components/rate-list/rate-list.component';
import { CreateFreightComponent } from './components/create-freight/create-freight.component';


@NgModule({
   declarations: [
      LauncherComponent,
      MainPageComponent,
      OrderDetailComponent,
      DeliveryAddressComponent,
      RateListComponent,
      CreateFreightComponent
   ],
   entryComponents: [],
   imports: [
      CommonModule,
      FormsModule,
      M3OdinModule,
      SohoComponentsModule,
      DemoModule,
      LauncherRoutingModule
   ],
   providers: [
   ],
})
export class LauncherModule { }
