import { Component, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CoreBase, MIRecord, IMIRequest, IMIResponse, IEnvironmentContext } from '@infor-up/m3-odin';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute } from '@angular/router';
import { DemoUserContextService } from 'src/app/demo/services/usercontext.service/usercontext.service';
import { MIService, FormService } from '@infor-up/m3-odin-angular';

@Component({
   styleUrls: ['./main-page.component.css'],
   templateUrl: './main-page.component.html',
   encapsulation: ViewEncapsulation.None
})
export class MainPageComponent extends CoreBase {

   isReady: boolean= true;
   selectedOrder: MIRecord;
   selectedOrderDetails: MIRecord;
   visibility = false;
   selectedRate: MIRecord;

   constructor(
      private activatedRoute: ActivatedRoute,
      private formService: FormService,
      private miService: MIService,
      public translate: TranslateService,
      private userContextService: DemoUserContextService) {
      super('MainPageComponent');

      /**
       *    Receive data from the URL
       */
      this.activatedRoute.queryParams.subscribe(params => {
         console.log(params)
         let selectedData: string = params['selectedRecord'];
         console.log(selectedData)
         
         if (selectedData) {
            let record = new MIRecord();
            console.log(record)
            let dataArray: string[] = selectedData.split(",");
            // for (let i = 0; i < dataArray.length; i += 2) {
            //    const key = dataArray[i];
            //    const value = dataArray[i + 1];
            //    record[key] = value;
            // }
            let key = dataArray[0];
            console.log(dataArray)
            let value = dataArray[1];
            record[key] = value;
            key = dataArray[2];
            value = dataArray[3];
            record[key] = value;
            this.selectedOrder = record;
            console.log(this.selectedOrder);
         }
         /**
          *    For testing purposes
          */

         // let record = new MIRecord(); selectedRecord
         // record["ORNO"] = "4003110350";
         // this.selectedOrder = record;

         /**
          *    Development environment context. Needed for single tenant environments where
          *    we have 2 different Grids
          */

         // let context: IEnvironmentContext = {
         //    ionApiUrl: "https://m3equdemo2-xi01.cloud.infor.com:9543",
         //    isMultiTenant: false
         // }
         // this.formService.developmentSetEnvironmentContext(context);
      });

   }

   ngOnInit() {
      // setTimeout(() => {
      //  this.isReady = false;
      //    this.visibility = true;
      // }, 1000);
   }

   public onOrderDetailsChanged(record: MIRecord) {
      this.selectedOrderDetails = record;
      console.log(this.selectedOrderDetails + '  Order detiled changed');

   }

   public onRateChanged(record: MIRecord) {
      // Pass in the delivery method from the order
      if (record && this.selectedOrderDetails) {
         record["ORNO"] = this.selectedOrderDetails["OAORNO"];
         record["MODL"] = this.selectedOrderDetails["OAMODL"];
      }
      this.selectedRate = record;
      console.log(this.selectedRate)
   }

}
