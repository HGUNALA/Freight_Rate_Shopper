import { Component, ViewEncapsulation, Input, SimpleChanges } from '@angular/core';
import { MIRecord, CoreBase, IMIResponse, IMIRequest, ArrayUtil } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';
import { SohoMessageService, SohoToastService } from 'ids-enterprise-ng';
import { DemoUserContextService } from 'src/app/demo/services/usercontext.service/usercontext.service';
import { MarkUpFactor } from 'src/app/demo/services/markup.service/markupfactor.service';
import { ignoreElements } from 'rxjs/operators';
import { ThrowStmt } from '@angular/compiler';
import { DestinationAddress } from 'src/app/demo/services/daddress.service/daddress.service';
@Component({
   encapsulation: ViewEncapsulation.None,
   selector: 'create-freight',
   styleUrls: ['./create-freight.component.css'],
   templateUrl: './create-freight.component.html'
})
export class CreateFreightComponent extends CoreBase {

   @Input() selectedParentRecord: MIRecord;

   isBusy: boolean;
   freight: string;
   service: string;
   buttonVisible: boolean;
   selectedCharge: MIRecord;
   selectedDeliveryMethod: MIRecord;
   modlRecord: MIRecord;
   markupAmount: any;

   requestList: IMIRequest[] = [];

   constructor(
      protected messageService: SohoMessageService,
      protected miService: MIService,
      private toastService: SohoToastService,
      protected userContextService: DemoUserContextService,
      protected markupfactorService: MarkUpFactor,
      protected daddressConstruct: DestinationAddress) {
      super("CreateFreightComponent");
   }

   ngOnInit(): void {
      this.modlRecord = new MIRecord();
      this.modlRecord["STCO"] = "MODL";
      this.modlRecord["LNCD"] = this.userContextService.userContext.currentLanguage;
   }

   /**
    *    This method loads data when selectedParentRecord has been loaded / changed
    */
   ngOnChanges(changes: SimpleChanges) {
      if (changes.selectedParentRecord) {
         if (this.selectedParentRecord) {
            console.log(this.selectedParentRecord);

            this.buttonVisible = true;
            this.service = this.selectedParentRecord["SUFI"];
            this.freight = this.selectedParentRecord["FRET"];
            console.log(this.daddressConstruct.daddressService);

         } else {
            this.clear();
         }
      }
   }

   clear() {
      this.service = null;
      this.freight = null;
      this.selectedParentRecord = null;
   }

   protected callApi(record: MIRecord, program?: string, transaction?: string) {
      if (this.isBusy) {
         return;
      }

      this.isBusy = true;

      const request: IMIRequest = {
         includeMetadata: true,
         program: program,
         transaction: transaction,
         record: record,
         maxReturnedRecords: 100,
         typedOutput: true
      };

      this.miService.execute(request).subscribe((response: IMIResponse) => {
         if (!response.hasError()) {
            this.onResponse(response);
         } else {
            this.onError('Failed to list transaction data');
         }
         this.isBusy = false;
      }, (error: MIResponse) => {
         this.isBusy = false;
         this.clear();
         if (error.errorCode != "XRE0103") {
            this.onError('Failed to list transaction data', error);
         }
      });

   }



   public onCreateCharge() {
      console.log(this.markupfactorService.markupfactor);
      let calculate = ((100 + this.markupfactorService.markupfactor) * parseInt(this.freight))/100;
      console.log(calculate);

      // this.markupAmount = (this.freight + (this.freight * this.markupfactorService.markupfactor))
      //  if(this.markupfactorService.markupfactor > 0 && this.markupfactorService.markupfactor <= 100 )
      this.enableConfirm("The New Freight Rate is : " + calculate.toString() );

      // else
      // {
      //    this.enableConfirm("You can add uplift percentage for your selected service in the Mark up factor field")
      // }

      let record: MIRecord;
      let request: IMIRequest;

      // Update delivery method
      // if (this.selectedDeliveryMethod["STKY"] != this.selectedParentRecord["MODL"]) {
      //    record = new MIRecord();
      //    record["ORNO"] = this.selectedParentRecord["ORNO"];

      //    request = {
      //       program: "OIS100MI",
      //       transaction: "LstConnCOCharge",
      //       record: record
      //    }

      //    this.requestList.push(request);
      // }

      // Check existing charges
      record = new MIRecord();
      record["ORNO"] = this.selectedParentRecord["ORNO"];

      request = {
         program: "OIS100MI",
         transaction: "LstConnCOCharge",
         record: record
      }

      // List existing charges
      this.callApi(request.record, request.program, request.transaction);
   }

   public onChargeChanged(record: MIRecord) {
      this.selectedCharge = record;
   }

   public onDeliveryMethodChanged(record: MIRecord) {
      this.selectedDeliveryMethod = record;
   }

   protected onError(message: string, error?: any) {
      this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('An error occured')
         .message(message + '. More details might be available in the browser console.')
         .buttons(buttons)
         .open();
   }

   public enableConfirm(message: string, error?: any) {
     //  this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'OK', click: (e, modal) => { modal.close(); } }];
      this.messageService.confirm()
         .title('Confirmation on mark up factor')
         .message(message)
         .buttons(buttons)
         .open();
   }

   protected onResponse(response: IMIResponse) {
      this.isBusy = false;

      // Check existing charges response
      if (response.transaction == "LstConnCOCharge") {
         let record: MIRecord;
         let request: IMIRequest;
         let transaction: string;
         record = new MIRecord();
         record["ORNO"] = this.selectedParentRecord["ORNO"];
         record["CRID"] = this.selectedCharge["CRID"];
         record["CRAM"] = this.freight;

         if (ArrayUtil.containsByProperty(response.items, "CRID", this.selectedCharge["CRID"])) {
            transaction = "UpdConnCOCharge";
         } else {
            transaction = "AddConnCOCharge";
         }

         request = {
            program: "OIS100MI",
            transaction: transaction,
            record: record
         }

         // Add / Update M3 Charge
         this.callApi(request.record, request.program, request.transaction);
      }

      // Add / Update charges response
      if (response.transaction == "AddConnCOCharge") {
         this.toastService.show({
            title: 'Charge Added',
            message: "Charge " + this.selectedCharge["CRID"] + " added to order " + this.selectedParentRecord["ORNO"],
            position: SohoToastService.TOP_RIGHT
         });
      } else if (response.transaction == "UpdConnCOCharge") {
         this.toastService.show({
            title: 'Charge Updated',
            message: "Charge " + this.selectedCharge["CRID"] + " updated on order " + this.selectedParentRecord["ORNO"],
            position: SohoToastService.TOP_RIGHT
         });
      }
   }

}
