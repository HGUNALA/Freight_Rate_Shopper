import {
  Component,
  ViewEncapsulation,
  Input,
  SimpleChanges,
  ViewChild,
  Output,
  EventEmitter,
} from "@angular/core";
import {
  MIRecord,
  CoreBase,
  HttpUtil,
  IIonApiRequest,
  IIonApiResponse,
  IMIResponse,
  IMIRequest,
} from "@infor-up/m3-odin";
import { MIService, IonApiService } from "@infor-up/m3-odin-angular";
import { MIResponse, MIUtil } from "@infor-up/m3-odin/dist/mi/runtime";
import { SohoMessageService, SohoDataGridComponent } from "ids-enterprise-ng";
import { DemoInitService } from "src/app/demo/services/initialize.service/initialize.service";
import { DemoUserContextService } from "src/app/demo/services/usercontext.service/usercontext.service";
import { DemoUtilService } from "src/app/demo/services/util.service/util.service";
import { DestinationAddress } from "src/app/demo/services/daddress.service/daddress.service";
import { MarkUpFactor } from "src/app/demo/services/markup.service/markupfactor.service";
import { THROW_IF_NOT_FOUND } from "@angular/core/src/di/injector";
import { isBuffer } from "util";
import { ThrowStmt } from "@angular/compiler";

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: "rate-list",
  styleUrls: ["./rate-list.component.css"],
  templateUrl: "./rate-list.component.html",
})
export class RateListComponent extends CoreBase {
  @Input() selectedParentRecord: MIRecord;
  @Input() address: MIRecord;
  @Output() orderDetailsChanged = new EventEmitter<MIRecord>();
  @Output() selectionChanged = new EventEmitter<MIRecord>();
  @ViewChild(SohoDataGridComponent) datagrid: SohoDataGridComponent;

  isBusy: boolean;
  isLoading: boolean = true;
  isReady: boolean;
  packageGrid: boolean;
  packageButton: boolean;
  columns: SohoDataGridColumn[] = [];
  packageColumns: SohoDataGridColumn[] = [];
  datagridOptions: SohoDataGridOptions;
  packageDatagridOptions: SohoDataGridOptions;
  filterConditions?: SohoDataGridColumnFilterConditions[] = [];
  selectedRecord: MIRecord;
  markUpFactor: number;
  padding= {'bottom' : 70 +'px' };
  sAddress1: string = "";
  sAddress2: string = "";
  sAddress3: string = "";
  sAddress4: string = "";
  address1: string = "";
  address2: string = "";
  address3: string = "";
  address4: string = "";
  visibility: boolean = true;
  deliveryDate:any;

  dateFormat: string;
  height={
     'height': 20 + '%' }

//   isBusy: boolean;



//   selectedRecord: MIRecord;
 oNumber:boolean;
  customerName: string;
  orderNumber: string;
  shipmentTotalWeight: number;
  customerNumber: any;
  name: boolean = true;
//   address: MIRecord;

  OrderNumber: any;
  itemNumber: any;
  orderQuantity: any;
  totalWeight: any;
  itemBasic: number;
  LineNumber: any;
//   destinationAddress: string;









  /**
   *    Single Tenant URL where we have 2 different Grids
   *    private serviceUrl = 'https://m3equdemo2-xi01.cloud.infor.com:9543/CustomerApi/Tms/Api';
   */

  private serviceUrl = "TM/public/cre/shoprates";
  private source: string = "tms-rate-shop";
  private readonly developmentToken = "oqcSNQzoRN1H0aVV0OAsge3HGDPq";

  // private apiInput: string = `{
  //    "RateAPI": {
  //       "ShipToCity": "Waukesha",
  //       "ShipToState": "WI",
  //       "ShipToCountry": "US",
  //       "ShipToZipcode": "53186",
  //       "ShipFromCity": "FREMONT",
  //       "ShipFromState": "CA",
  //       "ShipFromCountry": "US",
  //       "ShipFromZipcode": "94538",
  //       "TotalWeight": "1",
  //       "DeliveryDate": "2019-12-09"
  //    }
  // }`;
  // oqcSNQzoRN1H0aVV0OAsge3HGDPq
  count: any;
   sourceAddressResponse: MIRecord;
   commodityCode: string;
   classCode: string;
   mode: string[];
   // readOnly: boolean;
  enable : boolean = true;

  constructor(
    private ionApiService: IonApiService,
    protected messageService: SohoMessageService,
    protected miService: MIService,
    protected initService: DemoInitService,
    protected utilService: DemoUtilService,
    protected daddressConstruct: DestinationAddress,
    protected markupService: MarkUpFactor,
    public userContextService: DemoUserContextService,
  ) {
    super("RateListComponent");

    if (HttpUtil.isLocalhost()) {
      this.logDebug("Setting development token");
      console.log("setting token");
      this.ionApiService.setDevelopmentToken(this.developmentToken);
    }
  }

  ngOnInit(): void {
    console.log(this.address);

    this.initColumns();
    this.init();
    setTimeout(() => {
      this.selectedParent();
    }, 5000);
   //  this.getRates();
  }
  selectedParent() {
    console.log(this.daddressConstruct.daddressService)
    console.log(this.daddressConstruct.daddressService["CUA1"]);

  }

  protected init() {

    this.datagridOptions = this.initDataGridOptions("Freight-Rate Results", this.columns);
    // this.count = this.datagridOptions.dataset.length;
    this.isReady = true;
  }

  protected initColumns() {
     for (let index = 0; index < 5; index++) {

      this.packageColumns = [
         {
           width: 250,
           id: "col-Package-Type",
           field: "PTYPE",
           name: "Package Type",
           resizable: true,
           filterType: "text",
           formatter: Soho.Formatters.Dropdown,
           editor: Soho.Editors.Dropdown,
           options: [{ label: '01 - Letter', value: -1}, { label: '02 - Package', value: 1},{ label: '03 - Tube', value: 2}, { label: '04 - Pak', value: 3},
                    { label: '05 - Small Box', value: 4}, { label: '06 - Medium Box', value: 5},{ label: '07 - Large Box', value: 6}, { label: '08 - Pallet', value: 7},
                    { label: '09 - 10KG Box', value: 8}, { label: '10 - 25KG Box', value: 9}
                   ],
         },
         {
           width: 250,
           id: "col-length",
           field: "LNTH",
           name: "Length",
           resizable: true,
           filterType: "decimal",
           formatter: Soho.Formatters.Readonly,
         },
         {
          width: 250,
          id: "col-width",
          field: "WDTH",
          name: "Width",
          filterType: "decimal",
          formatter: Soho.Formatters.Readonly,
          resizable: false,
        },
        {
          width: 250,
          id: "col-Height",
          field: "HGHT",
          name: "Height",
          filterType: "decimal",
          formatter: Soho.Formatters.Readonly,
          resizable: false,
        },
        {
          width: 250,
          id: "col-Number-of-Packages",
          field: "NPGS",
          name: "Number of Packages",
          // inputType: "text",
          editor: Soho.Editors.Input,
          formatter: MyCustomFormatter,
          filterType: "decimal",
          maxLength:1,
          validate: "customWarningRule",
          resizable: false,
        },
         {
           width: 250,
           id: "col-Weight",
           field: "WGHT",
           name: "Weight",
           filterType: "decimal",
           editor: Soho.Editors.Input,
           formatter: MyCustomFormatter,
           resizable: false,
         },
         {
          width: "auto",
          id: "",
          field: "",
          name: "",
          sortable: true,
          align: "center",
          formatter: Soho.Formatters.Text,

          resizable: false,
        },
       ];
     }

    this.columns = [
      {
        width: 70,
        id: "selectionCheckbox",
        field: "",
        name: "",
        sortable: false,
        resizable: false,
        align: "center",
        formatter: Soho.Formatters.SelectionCheckbox,
      },
      {
        width: 150,
        id: "col-Carriers",
        field: "CARR",
        name: "Carrier",
        resizable: true,
        sortable: true,
        align: "center",
        formatter: Soho.Formatters.Text,
        filterType: "text",
      },
      {
        width: 200,
        id: "col-Service-Description",
        field: "SUFI",
        name: "Service Description",
        resizable: true,
        sortable: true,
        filterType: "text",
        formatter: Soho.Formatters.Text,
        filterFormatter: "text",
      },
      {
       width: 200,
       id: "col-Total-Rated-Amount",
       field: "FRET",
       name: "Total Rated Amount",
       align: "right",
       sortable: true,
       formatter: Soho.Formatters.Decimal,
       filterType: "decimal",
       resizable: false,
     },
     {
       width: 150,
       id: "col-Currency",
       field: "CRCY",
       name: "Currency",
       align: "center",
       sortable: true,
       formatter: Soho.Formatters.Text,
       filterType: "text",
       resizable: false,
     },
      {
        width: 200,
        id: "col-date",
        field: "DLDT",
        name: "Estimated Arrival Date",
        align: "left",
        sortable: true,
        formatter: Soho.Formatters.Date,
        filterType: "date",
        resizable: false,
      },
      {
       width: 150,
       id: "col-Days-In-Transit",
       field: "DITS",
       name: "Days In Transit",
       align: "right",
       sortable: true,
       formatter: Soho.Formatters.Integer,
       filterType: "Integer",
       resizable: false,
     },
     {
       width: 150,
       id: "col-Mode",
       field: "MODE",
       name: "Mode",
       sortable: true,
       align:"center",
       formatter: Soho.Formatters.Text,
       filterType: "text",
       resizable: false,
     },
     {
       width: 220,
       id: "col-Service-Level-Code",
       field: "SLCD",
       name: "Service Level Code",
       align:"right",
       sortable: true,
       formatter: Soho.Formatters.Text,
       filterType: "text",
       resizable: false,
     },
     {
       width: "auto",
       id: "col-Equipment",
       field: "EQMT",
       name: "Equipment",
       sortable: true,
       align: "center",
       formatter: Soho.Formatters.Text,
       filterType: "text",
       resizable: false,
     },

    ];
  }

  onParcel(event:any)
  {
   //  this.datagrid.dataset = [];

    console.log(event.data);

    console.log(event);


   if(!(event.data === "ALL"))
   {
      this.mode = [String(event.data)]
      // this.mode.push(String(event.data));
      console.log(this.mode);
      this.getRates();

   }
   // else if(event.data === "Select")
   // {

   // }
   else{
   this.mode = ['*'];
   this.getRates();
   // this.getRates();
   }


    if(event.data === "SMALL PARCEL" || event.data === "ALL")
    {
      this.packageGrid = true;
      this.packageDatagridOptions = this.packageInitDataGridOptions(this.packageColumns)
    }else{
      this.packageGrid = false;
    }

  }

//   onClick()
//   {
//     this.packageGrid = true;
//     this.packageDatagridOptions = this.packageInitDataGridOptions(this.packageColumns)
//   }
  onClose()
  {
     this.packageGrid = false;
  }
  packageInitDataGridOptions(

   columns: SohoDataGridColumn[],
   paging?: boolean,
   pageSize?: number
 ): SohoDataGridOptions {
   const options: SohoDataGridOptions = {
     alternateRowShading: false,
     isList: true,
     cellNavigation: false,
     clickToSelect: true,
     // disableRowDeactivation: true,
     editable: true,
     rowNavigation: false,
     indeterminate: false,
     filterWhenTyping: true,
      filterable: true,
   //   paging: true,
   //   pagesize: 5,
     rowHeight: "normal" as SohoDataGridRowHeight,
     selectable: "single" as SohoDataGridSelectable,
     showDirty: true,
     showFilterTotal: true,
     toolbar: {

       rowHeight: true,
       actions: true,
     },

     //toolbar: {title: 'Data Grid Header Title', results: true, dateFilter: false ,keywordFilter: true, actions: true, views: true, rowHeight: true},
     columns: columns,
     dataset: [
       {
         PTYPE: '01 - Letter',
         LNTH: '',
         WDTH: '',
         HGHT: '',
         NPGS: '',
         WGHT: ''
       }
     ],
     emptyMessage: {
       title: "No data available",
       icon: "icon-empty-no-data",
     },
   };
   return options;
 }

  initDataGridOptions(
    title: string,
    columns: SohoDataGridColumn[],
    paging?: boolean,
    pageSize?: number
  ): SohoDataGridOptions {
    const options: SohoDataGridOptions = {
      alternateRowShading: false,
      isList: true,
      cellNavigation: false,
      clickToSelect: true,
      // disableRowDeactivation: true,
      editable: true,
      rowNavigation: false,
      filterWhenTyping: true,
      filterable: true,

      indeterminate: false,
      paging: true,
      pagesize: 5,
      rowHeight: "normal" as SohoDataGridRowHeight,
      selectable: "single" as SohoDataGridSelectable,
      showDirty: true,
      showFilterTotal: true,
      toolbar: {
        results: true,
        title: title,
        rowHeight: true,
        actions: true,
      },

      //toolbar: {title: 'Data Grid Header Title', results: true, dateFilter: false ,keywordFilter: true, actions: true, views: true, rowHeight: true},
      columns: columns,
      dataset: [],
      emptyMessage: {
        title: "No data available",
        icon: "icon-empty-no-data",
      },
    };
    return options;
  }

  /**
   *    This method loads data when selectedParentRecord has been loaded / changed
   */
  ngOnChanges(changes: SimpleChanges) {
    if (changes.selectedParentRecord) {
      if (this.selectedParentRecord) {
         setTimeout(() => {
            this.getOrderDetails();

         }, 250);
      } else {
        this.clear();
      }
    }
  }


  getOrderDetails() {
   let record: MIRecord = new MIRecord;
   // record["OAORNO"] = this.selectedParentRecord["ORNO"];
   // this.callApi(record, "CMS100MI", "LstPrwCO");
   record["ORNO"] = this.selectedParentRecord["ORNO"];
   console.log(this.selectedParentRecord)
   this.orderNumber = record["ORNO"]
   this.callApi(record, "OIS100MI", "GetHead");
}

getOrderDetails1()
{
   let record: MIRecord = new MIRecord;
   // record["CUNO"] = this.customerNumber;
   // this.callApi(record, "CRS610MI", "GetBasicData");
   record["CUNO"] = this.customerNumber;
   this.callApi(record, "CRS610MI", "LstAddresses");
   // this.oNumber = true;
   this.getLines();
   this.itemBasic = 1;
}
getLines()
{
   let record: MIRecord = new MIRecord;
   record["ORNO"] = this.selectedParentRecord["ORNO"];
   console.log(this.daddressConstruct.daddressService);

   // record["PONR"] = 1;
   this.callApi(record, "OIS100MI", "LstCOLineInfo")




}
getItmBasic()
{
   let record: MIRecord = new MIRecord;
   record["ITNO"] = this.itemNumber;
   console.log(this.itemNumber);

   this.callApi(record, "MMS200MI", "GetItmBasic")
   console.log("get rates");
}
getetItmTrplnf()
{
   let record: MIRecord = new MIRecord;
   record["ITNO"] = this.itemNumber;
   console.log("MWS001");
   console.log(this.itemNumber);
   console.log(record['ITNO']);



   this.callApi(record, "MWS001MI", "GetItem")
}
getSourceAddress()
{
   let record: MIRecord = new MIRecord;
   record["ADTH"] = this.daddressConstruct.daddressService['ADRT'];
   this.callApi(record, "CRS235MI", "Lst")
}
protected onResponse(response: IMIResponse) {
   this.isBusy = false;
   this.visibility = false;
// console.log(response.item["CUNO"])
   this.customerNumber = response.item["CUNO"]
   // this.deliveryDate = response.item["RLDT"]
   console.log(response.item["RLDT"])
   // this.datePicker.setValue(response.item["RLDT"]);



   console.log(this.deliveryDate)

//   let record: MIRecord = new MIRecord;
//   record["CUA1"] = response.item['CUA1'];
//   record["CUA2"] = response.item['CUA2'];
//   record["CUA3"] = response.item['CUA3'];
//   record["CUA4"] = response.item['CUA4'];
//   this.address = record;
//   console.log(this.address)
//   this.address["CUA1"] =response.item["CUA1"]
//   this.address["CUA2"] =response.item["CUA2"]
//   this.address["CUA3"] =response.item["CUA3"]
//   this.address["CUA4"] =response.item["CUA4"]
  console.log(this.customerNumber)
  console.log(this.address  + "  this is address")

//   console.log(response.item["CUNM"])
//   this.customerName = response.item["CUNM"];

  console.log(this.name + "   true or false");
  console.log(this.orderNumber + "  order number")
  if(this.name == true)
  {
     console.log(this.name)


   this.selectedRecord = response.item;
   let record: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
   this.orderDetailsChanged.emit(record);
   this.name = false;
  }
  console.log(this.name);
  console.log()


//  this.getOrderDetails1();





   // this.customerName = response.item["OKCUNM"];
   // this.orderNumber = response.item["OAORNO"];
   // this.weight = response.item["OAGRWE"];

   // Set date picker value
   // this.datePicker.setValue(response.item["OARLDT"]);


}
protected onResponse1(response: IMIResponse) {
   this.isBusy = false;
   this.visibility = true;
//    console.log(response.item["CUNO"])

  this.customerNumber = response.item["CUNO"]
  this.orderNumber = this.OrderNumber;
  console.log(response.item)
//   let record: MIRecord = new MIRecord;
//   record["CUA1"] = response.item['CUA1'];
//   record["CUA2"] = response.item['CUA2'];
//   record["CUA3"] = response.item['CUA3'];
//   record["CUA4"] = response.item['CUA4'];
//   record["RLDT"] = this.deliveryDate;
//   this.address = record;
  console.log(this.address)
  console.log( "   this is Address")
//   this.selectedParentRecord['CUA1'] = response.item['CUA1'];
//   this.selectedParentRecord["CUA2"] = response.item['CUA2'];
//   this.selectedParentRecord["CUA3"] = response.item['CUA3'];
//   this.selectedParentRecord["CUA4"] = response.item['CUA4'];
//   this.selectedParentRecord["TOWN"] = response.item['TOWN'];
//   this.selectedParentRecord["PONO"] = response.item['PONO'];
  console.log(this.selectedParentRecord);

//   this.address["CUA1"] =response.item["CUA1"]
//   this.address["CUA2"] =response.item["CUA2"]
//   this.address["CUA3"] =response.item["CUA3"]
//   this.address["CUA4"] =response.item["CUA4"]
  console.log(this.customerNumber + "  customer number")


  console.log(response.item["CUNM"])
  console.log(this.deliveryDate);

//   this.customerName = response.item["CUNM"];

//   console.log(this.datePicker.setValue(this.deliveryDate));
  console.log(this.name);
//   console.log(this.datePicker.setValue(this.deliveryDate))
//   if(this.name == true)
//   {
//      console.log(this.name)
//      this.getOrderDetails1();

//    this.selectedRecord = response.item;
//    let record: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
//    this.orderDetailsChanged.emit(record);
//    this.name = false;
//   }
this.selectedRecord = response.item;
   let record1: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
   this.orderDetailsChanged.emit(record1);
  console.log(this.name);
  console.log()


//  this.getOrderDetails1();





   // this.customerName = response.item["OKCUNM"];
   // this.orderNumber = response.item["OAORNO"];
   // this.weight = response.item["OAGRWE"];

   // Set date picker value
   // this.datePicker.setValue(response.item["OARLDT"]);


}
dateConcat(dateF: Date)
{
   // dateFormat = new Date( "Tue May 20 2010 00:00:00 GMT+0530 ");
  console.log(dateF.getMonth())
  console.log(dateF.getDate())
  console.log(dateF.getFullYear())
      let year  = (dateF.getFullYear()).toString();
      let month = (dateF.getMonth() + 1).toString();
      month = month + '/'
      let date = dateF.getDate().toString();
       date = date + '/'
      // let finalDate = parseInt(month + date + year);
      // console.log(finalDate)
      // year = parseInt(dateFormat.substring(11,4));
      // console.log(year)
      // month = dateFormat.substring(4, 3) ;
      // day = parseInt(dateFormat.substring(8, 2));
      // const dtfm = this.userContext.DTFM;
      // Tue Apr 20 2010 00:00:00 GMT+0530

      return (month + date + year);

      // return new Date(year, month, day);

}

callApi(record: MIRecord, program?: string, transaction?: string) {
   if (this.isBusy) {
      return;
   }

   // this.isBusy = true;
   // this.visibility = true;

   const request: IMIRequest = {
      includeMetadata: true,
      program: program,
      transaction: transaction,
      record: record,
      maxReturnedRecords: 100,
      typedOutput: true
   };

   this.miService.execute(request).subscribe((response: IMIResponse) => {
      console.log(response + "hello");
      // console.log(response.item['ITNO']);

      // console.log(response.item);
      if(response.program === "OIS100MI" && response.transaction === "GetHead")
      {
         console.log(response);
         this.customerNumber = response.item['CUNO'];
         this
         this.daddressConstruct.deliveryDateService =  this.dateConcat(response.item["RLDZ"]);
         console.log(this.daddressConstruct.deliveryDateService);

         this.getOrderDetails1();
         // this.orderNumber
      }
     else if(response.program === "CRS610MI"){
         this.daddressConstruct.daddressService = response.item;
         // if(this.itemNumber === undefined)
         // {
         //    console.log("776");

         //    this.isLoading = false;
         //    this.onError("Item doesn't exist for this Order Number. Please add Item in MWS001 to proceed further.")
         //    this.disable = true;
         //    this.enable = false;
         // }
         this.customerName = response.item['CUNM']
         console.log(response);
         console.log(this.customerName);

         console.log(this.daddressConstruct.daddressService);
         this.getSourceAddress();


      }
     else if(response.program === "OIS100MI" && response.transaction === "LstCOLineInfo"){

      // console.log(response);

         if(!(response.item))
         {
            this.onError("Item doesn't exist for this Order Number")
            this.enable = false;
            this.isLoading = false;
         }
         else{
         this.itemNumber = response.item['ITNO']

         console.log(this.itemNumber);



            this.orderQuantity = response.item['ORQA']
            this.LineNumber = response.item['PONR']
            console.log(this.itemNumber + "  " + this.orderQuantity + "  " + this.LineNumber)
            this.getItmBasic();
         }


      }
     else if(response.program === "CRS235MI")
      {
         this.sourceAddressResponse = response.item
         this.daddressConstruct.saddressService = response.item;
         console.log(this.sourceAddressResponse);
         console.log(this.sourceAddressResponse['ADR1']);

      console.log(this.daddressConstruct.deliveryDateService)
      console.log(this.daddressConstruct.daddressService)
      this.address1 = this.daddressConstruct.daddressService["CUA1"];
      this.address2 = this.daddressConstruct.daddressService["CUA2"];
      this.address3 = this.daddressConstruct.daddressService["CUA3"];
      this.address4 = this.daddressConstruct.daddressService["CUA4"];
      this.sAddress1 = this.daddressConstruct.saddressService["ADR1"]
      this.sAddress2 = this.daddressConstruct.saddressService["ADR2"]
      this.sAddress3 = this.daddressConstruct.saddressService["ADR3"]
      this.sAddress4 = this.daddressConstruct.saddressService["ADR4"]
      this.padding = {'bottom': 30+'px'}
      this.isBusy = false;
      this.visibility = true;
      this.deliveryDate = this.daddressConstruct.deliveryDateService


      }
      // if(this.itemNumber != undefined && this.itemBasic === 1){

      // console.log("entered into getitmBasic");

      // this.itemBasic = 2;
      // }
     else if(response.program === "MMS200MI" && response.transaction === "GetItmBasic"){
      this.totalWeight = response.item["GRWE"];
      console.log(this.totalWeight);
      this.shipmentTotalWeight = (this.totalWeight) * (this.orderQuantity)
      // this.getRates();
      this.getetItmTrplnf();
      console.log(response);

      console.log(this.shipmentTotalWeight);
   }
      else
      {
         console.log(response);
         this.commodityCode = response.item["CMMC"];
         this.classCode = response.item["CMCL"]
         this.isLoading = false;

         // this.getRates();
      }
   //    if(!response.hasError() && this.name == false)
   //    {
   //     this.onResponse1(response);
   //    }
   //   else if (!response.hasError()) {
   //       this.onResponse(response);
   //       // this.getOrderDetails1();
   //    } else {
   //       this.onError('Failed to list transaction data');
   //    }

      this.isBusy = false;
      this.visibility = false;
   }, (error: MIResponse) => {
      this.isBusy = false;
      this.visibility = false;
      this.clear();
      if (error.errorCode != "XRE0103") {
         this.onError('Failed to list transaction data', error);
      }

      this.isLoading = false;
   });

}

protected onError(message: string, error?: any) {
   this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
   const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
   this.messageService.error()
      .title('An error occured')
      .message(message)
      .buttons(buttons)
      .open();
}
  clear() {
    if (this.datagrid) {
      this.datagrid.dataset = [];
    } else {
      this.datagridOptions.dataset = [
        {
          CARR: "Carrier",
          SUFI: "Service Description",
          DLDT: "Estimate Arrival Date",
          FRET: "Freight",
          CRCY: "Currency",
          DITS: "Days In Transit",
          MODE: "Mode",
          SERL: "Service Level",
          SLCD: "Service Level Code",
          EQMT: "Equipment"
        },
      ];
    }
  }

  // private checkIsAddressValid(): boolean {
  //    let shipFromZipcode: string;
  //    let shipFromState: string;
  //    let shipFromCountry: string;
  //    let shipToState: string;
  //    let shipToCountry: string;
  //    let shipToZipcode: string;

  //    // Ship from
  //    shipFromZipcode = this.selectedParentRecord["C1PONO"];
  //    shipFromState = this.selectedParentRecord["C1ECAR"];
  //    shipFromCountry = this.selectedParentRecord["C1CSCD"];

  //    // Ship to
  //    if (this.selectedParentRecord["OPPONO"]) {
  //       shipToState = this.selectedParentRecord["OPECAR"];
  //       shipToCountry = this.selectedParentRecord["OPCSCD"];
  //       shipToZipcode = this.selectedParentRecord["OPPONO"];
  //    } else {
  //       shipToState = this.selectedParentRecord["OKECAR"];
  //       shipToCountry = this.selectedParentRecord["OKCSCD"];
  //       shipToZipcode = this.selectedParentRecord["OKPONO"];
  //    }

  //    // Validate address fields
  //    if (shipFromZipcode && shipFromState && shipFromCountry &&
  //       shipToZipcode && shipToState && shipToCountry) {
  //       return true;
  //    } else {
  //       return false;
  //    }

  // }

  private createRequest(relativeUrl: string, headers?: object): IIonApiRequest {
    if (!headers) {
      headers = {
        Accept: "application/json",
      };
    }
    console.log("Now in createRequest");
    // Create the relative URL to the ION API
    const url = this.serviceUrl + "/" + relativeUrl;

    // Create the request
    let TmsRequest: IRootObject = {
      RateOwner: "",
      carrierCodes: [],
      ClientTransaction: {
        ReferenceNumber: "",
        SourceSystem: "",
      },
      Shipment: {
        Destination: {
          Address: {
            POBox: "",
            StreetNumber: "",
            AddressLine1: "",
            AddressLine2: "",
            AddressLine3: "",
            City: "",
            StateProvinceCode: "",
            PostalCode: "",
            CountryCode: "",
          },
        },
        Origin: {
          Address: {
            POBox: "",
            StreetNumber: "",
            AddressLine1: "",
            AddressLine2: "",
            AddressLine3: "",
            City: "",
            StateProvinceCode: "",
            PostalCode: "",
            CountryCode: "",
          },
        },
        ShipmentTotalWeight: {
          UOM: "",
          Value: 0,
        },
        Packages: [
          {
            PackagingType: {
              Code: "",
            },
            Dimensions: {
              UOM: "",
              Length: 0,
              Width: 0,
              Height: 0,
              Girth: 0,
            },
            PackageWeight: {
              UOM: "",
              Value: 0,
            },
            NumberOfPieces: 0,
            InsuredAmount: {
              Currency: "",
              Value: 0,
            },
          },
        ],
        TotalVolume: {
          UOM: "",
          Value: 0,
        },
        TotalQuantity: {
          UOM: "",
          Value: 0,
        },
        PickupDateTime: {
          Date: "",
          Time: "",
        },
        Commodities: [
          {
            Sequence: 0,
            Code: '',
            ClassCode: "",
            Weight: {
              UOM: "",
              Value: 0,
            },
            Volume: {
              UOM: "",
              Value: 0,
            },
            Quantity: {
              UOM: "",
              Value: 0,
            },
          },
        ],
      },
      Modes: [],
      EquipmentTypes: [],
      TripType: "",
      MovementDirection: "",
      RateType: "",
      ChargeTypes: [],
    };

    TmsRequest.RateOwner = "M3DEVAPPAIS_DEV";
    TmsRequest.carrierCodes = ["*"];
    TmsRequest.ClientTransaction.ReferenceNumber = "SXEDEV001";
    TmsRequest.ClientTransaction.SourceSystem = "M3DEVAPPAIS_DEV";
    // Shipment Destination Address
    TmsRequest.Shipment.Destination.Address.POBox = "";
    TmsRequest.Shipment.Destination.Address.AddressLine1 = this.daddressConstruct.daddressService['CUA1'];
    console.log( TmsRequest.Shipment.Destination.Address.AddressLine1);
    TmsRequest.Shipment.Destination.Address.AddressLine2 = this.daddressConstruct.daddressService['CUA2'];
    TmsRequest.Shipment.Destination.Address.AddressLine3 = this.daddressConstruct.daddressService['CUA3'];
    TmsRequest.Shipment.Destination.Address.City = this.daddressConstruct.daddressService['TOWN'];
    TmsRequest.Shipment.Destination.Address.CountryCode = this.daddressConstruct.daddressService['CSCD'];
    TmsRequest.Shipment.Destination.Address.PostalCode = this.daddressConstruct.daddressService['PONO'];
    TmsRequest.Shipment.Destination.Address.StateProvinceCode = this.daddressConstruct.daddressService['ECAR'];
    TmsRequest.Shipment.Destination.Address.StreetNumber = "";
    // Shipment Origin Address
    TmsRequest.Shipment.Origin.Address.POBox = "";
    TmsRequest.Shipment.Origin.Address.AddressLine1 = this.sourceAddressResponse['ADR1'];
    TmsRequest.Shipment.Origin.Address.AddressLine2 = this.sourceAddressResponse['ADR2'];
    console.log(TmsRequest.Shipment.Origin.Address.AddressLine2);

    TmsRequest.Shipment.Origin.Address.AddressLine3 = this.sourceAddressResponse['ADR3'];
    TmsRequest.Shipment.Origin.Address.City = this.sourceAddressResponse['TOWN'];
    TmsRequest.Shipment.Origin.Address.CountryCode = this.sourceAddressResponse['CSCD'];
    TmsRequest.Shipment.Origin.Address.PostalCode = this.sourceAddressResponse['PONO'];
    TmsRequest.Shipment.Origin.Address.StateProvinceCode = this.sourceAddressResponse['ECAR'];
    TmsRequest.Shipment.Origin.Address.StreetNumber = "";
    //Shipment Total Weight
    TmsRequest.Shipment.ShipmentTotalWeight.UOM = "KG";
    TmsRequest.Shipment.ShipmentTotalWeight.Value = this.shipmentTotalWeight;
    console.log(TmsRequest.Shipment.ShipmentTotalWeight.Value);

    // Total Volume
    TmsRequest.Shipment.TotalVolume.UOM = "E";
    TmsRequest.Shipment.TotalVolume.Value = 30;
    // Total Quantity
    TmsRequest.Shipment.TotalQuantity.UOM = "PCS";
    TmsRequest.Shipment.TotalQuantity.Value = this.orderQuantity;
    console.log(TmsRequest.Shipment.TotalQuantity.Value);

    // PickupDateTime
    TmsRequest.Shipment.PickupDateTime.Date = this.daddressConstruct.deliveryDateService;
    TmsRequest.Shipment.PickupDateTime.Time = "08:45:21";
    // Packages
    // Package Type
    TmsRequest.Shipment.Packages[0].PackagingType.Code = "02";
    // Package Dimention
    TmsRequest.Shipment.Packages[0].Dimensions.Girth = 22;
    TmsRequest.Shipment.Packages[0].Dimensions.Height = 5;
    TmsRequest.Shipment.Packages[0].Dimensions.Length = 10;
    TmsRequest.Shipment.Packages[0].Dimensions.Width = 7;
    TmsRequest.Shipment.Packages[0].Dimensions.UOM = "IN";
    // Insured Amount
    TmsRequest.Shipment.Packages[0].InsuredAmount.Currency = "USD";
    TmsRequest.Shipment.Packages[0].InsuredAmount.Value = 123.3;
    // Package Weight
    TmsRequest.Shipment.Packages[0].PackageWeight.UOM = "LB";
    TmsRequest.Shipment.Packages[0].PackageWeight.Value = 7;
    // Number of pieces
    TmsRequest.Shipment.Packages[0].NumberOfPieces = 1;
    // Commodities
    TmsRequest.Shipment.Commodities[0].ClassCode = this.classCode;
    TmsRequest.Shipment.Commodities[0].Code = this.commodityCode;
    TmsRequest.Shipment.Commodities[0].Sequence = 1;
    TmsRequest.Shipment.Commodities[0].Quantity.UOM = "PCS";
    TmsRequest.Shipment.Commodities[0].Quantity.Value = this.orderQuantity;
    TmsRequest.Shipment.Commodities[0].Volume.UOM = "E";
    TmsRequest.Shipment.Commodities[0].Volume.Value = 30;
    TmsRequest.Shipment.Commodities[0].Weight.UOM = "L";
    TmsRequest.Shipment.Commodities[0].Weight.Value = this.totalWeight;
    // Modes
    TmsRequest.Modes = this.mode;
    console.log(TmsRequest.Modes);

    // Equipment Type
    TmsRequest.EquipmentTypes = ["*"];
    // Movement Direction
    TmsRequest.MovementDirection = "O";
    // Trip Type
    TmsRequest.RateType = "AP";
    // Rate Type
    TmsRequest.TripType = "ONE WAY";
    // Charge Type
    TmsRequest.ChargeTypes = ["*"];

    let dateString: string;
    let pwDateString: string;

    // Delivery date (must be yyyy-mm-dd)
    // dateString = MIUtil.getDateFormatted(this.selectedParentRecord["OARLDT"]);
    // pwDateString = dateString.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
    // TmsRequest.RateAPI.DeliveryDate = pwDateString + "T00:00:00Z";

    // // Departure date (must be yyyy-mm-dd)
    // dateString = MIUtil.getDateFormatted(this.selectedParentRecord["OARLDT"]);
    // pwDateString = dateString.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
    // TmsRequest.RateAPI.Departuredate = pwDateString + "T00:00:00Z";

    // Create HTTP GET request object
    const request: IIonApiRequest = {
      method: "POST",
      url: url,
      headers: headers,
      body: TmsRequest,
      source: this.source,
    };

    return request;
  }

  public onDeliveryDateChanged(event: any) {
   if (event.data) {
      console.log(this.deliveryDate)
      this.address["RLDT"] = this.userContextService.getDate(this.deliveryDate);
      console.log("Delivary date is here" + this.deliveryDate);
      let record: MIRecord = this.utilService.getDuplicateRecord(this.address);
      this.orderDetailsChanged.emit(record);
      console.log(this.orderDetailsChanged);

   }
}

enableMarkUp()
{
  console.log(this.markUpFactor);
  this.markupService.markupfactor = this.markUpFactor;
  console.log(this.markupService.markupfactor);

}
  destinationAddress():boolean
  {
     console.log(this.daddressConstruct.daddressService);
    let dAddress1: string;
    if(!(this.daddressConstruct.daddressService))
    {
       console.log("717");

      setTimeout(() => {
         this.destinationAddress()
      }, 5000)
      //  dAddress1 = this.daddressConstruct.daddressService['CUA1']
   //    if(this.daddressConstruct.daddressService['CUA1']){
   //     console.log("717");
   //     return true;
   //    }
   //    else
   //    return false;
   console.log("729");

    }
    else{

       console.log("723");
       return true;

    }
   //  if(this.daddressConstruct.daddressService)
   //  return true;
   //  else
   //  return false;

   //  return true;

  }

  private getRates() {
    // Clear current records
   //  this.clear();
   console.log(this.daddressConstruct.daddressService);


    // Check from- and to-address  this.checkIsAddressValid();
   //  const isValid = this.destinationAddress();
   let isValid = true;
    console.log(isValid);

    console.log("Entered in the getRates");

    if (isValid) {
      // Set busy indicator
      this.isBusy = true;
      // Create request
      const request = this.createRequest("v1/ShopRate/shippingrate");
      // call ION Api
      console.log(request);

      console.log("Successfully fetch the request");
      this.ionApiService.execute(request).subscribe(
        (response: IIonApiResponse) => {
          this.isBusy = false;
          console.log("Response");
          console.log(response);
          console.log(response.body.rateRecords);
          if (!response.body.ErrorList) {
            let TmsResponse: ITmsResponse = response.body;
            this.count = TmsResponse.rateRecords.length;
            console.log(this.count);
            if (TmsResponse.rateRecords) {
              if (TmsResponse.rateRecords.Message) {
                this.onMessage(
                  TmsResponse.rateRecords.Message,
                  "Freight Rate Information"
                );
              } else if (TmsResponse.rateRecords) {
                console.log(
                  JSON.stringify(TmsResponse.rateRecords[0]) +
                    " in the else if with no edd"
                );
                console.log(TmsResponse.rateRecords + " in the else if");
                if (Array.isArray(TmsResponse.rateRecords)) {
                  console.log(TmsResponse.rateRecords + "in the final stage");

                  this.onMultipleRatesFound(TmsResponse.rateRecords);
                } else {
                  console.log(
                    TmsResponse.rateRecords + "in the final stage in else"
                  );
                  this.onSingleRateFound(TmsResponse.rateRecords[0]);
                }
              }
            }
          }
          // TODO Error
        },
        (response: IIonApiResponse) => {
          this.isBusy = false;
        }
      );
    } else {
      this.onMessage(
        "Please verify your ship-from address (CRS235) and ship-to address (OIS100/OIS300)",
        "Invalid Address"
      );
    }

  }

  /**
   *    A method for handling message from the API call
   */
  private onMessage(message: string, title?: string, error?: any) {
    this.logInfo(message);
    const buttons = [
      {
        text: "Ok",
        click: (e, modal) => {
          modal.close();
        },
      },
    ];
    this.messageService
      .message()
      .title(title)
      .message(message)
      .buttons(buttons)
      .open();
  }

  private onMultipleRatesFound(rates: IRate[]) {
    // Set records
    let records: MIRecord[] = [];
    for (let rate of rates) {
      let record: MIRecord = new MIRecord();
      console.log(rates);

      record["CARR"] = rate.carrierName;
      record["SUFI"] = rate.serviceLevel;
      record["DLDT"] = rate.estimatedArrivalDate;
      record["CRCY"] = rate.currencyCode
      record["FRET"] = rate.totalRatedAmount;
      record["MODE"] = rate.mode;
      record["SLCD"] = rate.serviceLevelCode;
      record["EQMT"] = rate.equipment;
      record["DITS"] = rate.daysInTransit;

      console.log(record["SLCD"]);
     console.log(record);


      records.push(record);
    }

    // Set data
    if (this.datagrid) {

      console.log(this.datagrid + "entered 666");

      // In case of refresh and the datagrid was sorted, re-apply sorting
      try {
        if (this.datagrid["datagrid"].sortColumn) {
          console.log("671");

          this.datagrid["datagrid"].restoreSortOrder = true;
        }
      } catch (err) {
        this.logError(err);
      }
      this.datagrid.dataset = records;
      console.log(records);

      console.log(this.datagrid.dataset);

    } else {
      this.datagridOptions.dataset = records;
      console.log(this.datagridOptions.dataset);
      console.log(this.datagridOptions);


    }
  }

  private onSingleRateFound(rate: IRate) {
    // Set records
    let records: MIRecord[] = [];
    let record: MIRecord = new MIRecord();
    record["CARR"] = rate.carrierName;
    record["SUFI"] = rate.serviceLevel;
    record["DLDT"] = rate.estimatedArrivalDate;
    record["FRET"] = rate.totalRatedAmount;
    record["MODE"] = rate.mode;
    record["SLCD"] = rate.serviceLevelCode;
    record["EQMT"] = rate.equipment;
    record["DITS"] = rate.daysInTransit;
    record["CRCY"] = rate.currencyCode
    records.push(record);

    // Set data
    if (this.datagrid) {
      // In case of refresh and the datagrid was sorted, re-apply sorting
      try {
        if (this.datagrid["datagrid"].sortColumn) {
          this.datagrid["datagrid"].restoreSortOrder = true;
        }
      } catch (err) {
        this.logError(err);
      }
      this.datagrid.dataset = records;
    } else {
      this.datagridOptions.dataset = records;
    }
  }

  public onSelected(event: any) {
    this.selectedRecord = null;
    if (event.rows) {
      if (event.rows.length > 0) {
        this.selectedRecord = event.rows[0].data;
        const record = this.utilService.getTrimmedRecord(this.selectedRecord);
        this.selectionChanged.emit(record);
      } else {
        this.selectionChanged.emit(null);
      }
    }
  }
}

 export interface IDAddress {
   CONO: number;
   DIVI: string;
   CUNO: string;
   CUNM: string;
   ADRT: number;
   ADID: string;
   CUA1: string;
   CUA2: string;
   CUA3: string;
   CUA4: string;
   PONO: string;

   PHNO: string;

   CSCD: string;


   TOWN: string;

 }

export interface IRootObject {
  RateOwner: string;
  carrierCodes: string[];
  ClientTransaction: IClientTransaction;
  Shipment: IShipment;
  Modes: string[];
  EquipmentTypes: string[];
  TripType: string;
  MovementDirection: string;
  RateType: string;
  ChargeTypes: string[];
}
export interface IShipment {
  Destination: IDestination;
  Origin: IDestination;
  ShipmentTotalWeight: IShipmentTotalWeight;
  Packages: IPackage[];
  TotalVolume: IShipmentTotalWeight;
  TotalQuantity: IShipmentTotalWeight;
  PickupDateTime: IPickupDateTime;
  Commodities: ICommodity[];
}

export interface ICommodity {
  Sequence: number;
  Code: string;
  ClassCode: string;
  Weight: IShipmentTotalWeight;
  Volume: IShipmentTotalWeight;
  Quantity: IShipmentTotalWeight;
}

export interface IPickupDateTime {
  Date: string;
  Time: string;
}

export interface IPackage {
  PackagingType: IPackagingType;
  Dimensions: IDimensions;
  PackageWeight: IShipmentTotalWeight;
  NumberOfPieces: number;
  InsuredAmount: IInsuredAmount;
}

export interface IInsuredAmount {
  Currency: string;
  Value: number;
}

export interface IDimensions {
  UOM: string;
  Length: number;
  Width: number;
  Height: number;
  Girth: number;
}

export interface IPackagingType {
  Code: string;
}

export interface IShipmentTotalWeight {
  UOM: string;
  Value: number;
}

export interface IDestination {
  Address: IAddress;
}

export interface IAddress {
  POBox: string;
  StreetNumber: string;
  AddressLine1: string;
  AddressLine2: string;
  AddressLine3: string;
  City: string;
  StateProvinceCode: string;
  PostalCode: string;
  CountryCode: string;
}

export interface IClientTransaction {
  ReferenceNumber: string;
  SourceSystem: string;
}

export interface ITmsRequest {
  RateOwner: string;
  carrierCodes: Array<string>;
  ClientTransaction: IClientTrans;
  // RateAPI: IRateAPIRequest;
}

export interface IClientTrans {
  ReferenceNumber: string;
  SourceSystem: string;
}

// export interface IRateAPIRequest {
//    ShipToCity?: string,
//    ShipToState: string,
//    ShipToCountry: string,
//    ShipToZipcode: string,
//    ShipFromCity?: string,
//    ShipFromState: string,
//    ShipFromCountry: string,
//    ShipFromZipcode: string,
//    TotalWeight: string,
//    DeliveryDate: string,
//    WeightUnits: string,
//    Departuredate: string
// }

export interface ITmsResponse {
  rateRecords: IrateRecords;
}

export interface IrateRecords {
  Message?: string;
  EDD?: IRate[];
  length: number;
}

export interface IRate {
  carrierName: string;
  serviceLevel: string;
  estimatedArrivalDate: Date;
  currencyCode: string;
  totalRatedAmount: string;
  mode: string;
  serviceLevelCode: string;
  equipment: string;
  daysInTransit: number;

  Error_Message: string;
}

function MyCustomFormatter(row, cell, value:number, col, item) {
  var opt = col.formatterOptions || {},
    format = function (s) {
      return (s || '').replace(/{(\w+)}/g, function (m, p) {
        return item[p];
      });
    },
    id = (opt.prefix || 'input') + row + '-' + cell,
    type = 'number', //opt.type ||
    beforeTemplate = format(opt.beforeTemplate),
    afterTemplate = format(opt.afterTemplate);

  return (
    '<input soho-dirtytrack type="' +
    type +
    '" id="' +
    id +
    '" name="' +
    id +
    '" value="' +
    value +
    '"/>'
  );
}
//  record["CARR"] = rate.carrierName;
//  record["SUFI"] = rate.serviceLevel;
//  record["DLDT"] = rate.estimatedArrivalDate;
//  record["CRCY"] = rate.currencyCode
//  record["FRET"] = rate.totalRatedAmount;
//  record["MODE"] = rate.mode;
//  record["SERL"] = rate.serviceLevel;
//  record["SLCD"] = rate.serviceLevelCode;
//  record["EQMT"] = rate.equipment;
//  record["DITS"] = rate.daysInTransit;
