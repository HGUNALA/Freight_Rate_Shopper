import { Component, ViewEncapsulation, Input, SimpleChanges, ViewChild, EventEmitter, Output } from '@angular/core';
import { MIRecord, CoreBase, IMIResponse, IMIRequest } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';

import { SohoDatePickerComponent, SohoMessageService } from 'ids-enterprise-ng';
import { DemoUserContextService } from 'src/app/demo/services/usercontext.service/usercontext.service';
import { DemoUtilService } from 'src/app/demo/services/util.service/util.service';
import { MarkUpFactor } from 'src/app/demo/services/markup.service/markupfactor.service';
import { DestinationAddress } from 'src/app/demo/services/daddress.service/daddress.service';
import { THROW_IF_NOT_FOUND } from '@angular/core/src/di/injector';
@Component({
   encapsulation: ViewEncapsulation.None,
   selector: 'delivery-address',
   styleUrls: ['./delivery-address.component.css'],
   templateUrl: './delivery-address.component.html'
})
export class DeliveryAddressComponent extends CoreBase {


   @Input() address: MIRecord;
   @Input() selectedParentRecord: MIRecord;
   // @ViewChild(SohoDatePickerComponent) datePicker: SohoDatePickerComponent;
   @Output() orderDetailsChanged = new EventEmitter<MIRecord>();
   isBusy: boolean = true;

   padding= {'bottom' : 70 +'px' };
   sAddress1: string = "";
   sAddress2: string = "";
   sAddress3: string = "";
   sAddress4: string = "";
   address1: string = "";
   address2: string = "";
   address3: string = "";
   address4: string = "";
   visibility: boolean = true;
   deliveryDate:any;
   selectedRecord: MIRecord;
   dateFormat: string;
   markUpFactor: number;
   height={
      'height': 20 + '%'
   }

   constructor(
      protected messageService: SohoMessageService,
      public userContextService: DemoUserContextService,
      protected utilService: DemoUtilService,
      protected miService: MIService,
      protected markupService: MarkUpFactor,
      protected daddressConstruct: DestinationAddress) {
      super("DeliveryAddressComponent");
   }

   ngOnInit(): void {
      // console.log(this.address)
      // setTimeout(() => { this.Address(); }, 10000);

   }
   Address()
   {


      console.log(this.daddressConstruct.deliveryDateService)
      console.log(this.daddressConstruct.daddressService)
      this.address1 = this.daddressConstruct.daddressService["CUA1"];
      this.address2 = this.daddressConstruct.daddressService["CUA2"];
      this.address3 = this.daddressConstruct.daddressService["CUA3"];
      this.address4 = this.daddressConstruct.daddressService["CUA4"];
      this.sAddress1 = this.daddressConstruct.saddressService["ADR1"]
      this.sAddress2 = this.daddressConstruct.saddressService["ADR2"]
      this.sAddress3 = this.daddressConstruct.saddressService["ADR3"]
      this.sAddress4 = this.daddressConstruct.saddressService["ADR4"]
      this.padding = {'bottom': 30+'px'}
      this.isBusy = false;
      this.visibility = true;
      this.deliveryDate = this.daddressConstruct.deliveryDateService
   }


   // ngAfterViewInit() {
   //    try {
   //       this.dateFormat = this.userContextService.getDateFormat();
   //       // Init Soho components
   //       this.initDatePicker(this.datePicker);
   //    } catch (err) {
   //       this.logError(err);
   //    }
   // }

   /**
    *    This method loads data when selectedParentRecord has been loaded / changed
   //  */
   // ngOnChanges(changes: SimpleChanges) {
   //    if (changes.selectedParentRecord) {
   //       if (this.selectedParentRecord) {
   //          setTimeout(() => {
   //             this.getAddress();
   //          }, 250);
   //       } else {
   //          this.clear();
   //       }
   //    }
   // }
   public onDeliveryDateChanged(event: any) {
      if (event.data) {
         console.log(this.deliveryDate)
         this.address["RLDT"] = this.userContextService.getDate(this.deliveryDate);
         console.log("Delivary date is here" + this.deliveryDate);
         let record: MIRecord = this.utilService.getDuplicateRecord(this.address);
         this.orderDetailsChanged.emit(record);
         console.log(this.orderDetailsChanged);

      }
   }
   clear() {

   }
   private initDatePicker(datePicker: SohoDatePickerComponent) {
      datePicker.dateFormat = this.dateFormat;
   }


   // getAddress() {
   //    let record: MIRecord = new MIRecord;
   //    record["ORNO"] = this.selectedParentRecord["ORNO"];
   //    record["ADRT"] = "1";
   //    this.callApi(record, "OIS100MI", "GetAddress");

   //    let record1: MIRecord = new MIRecord;
   //    record1["OAORNO"] = this.selectedParentRecord["ORNO"];
   //    this.callApi1(record1, "CMS100MI", "LstPrwCO");
   // }

   // getOrderDetails() {
   //    let record1: MIRecord = new MIRecord;
   //    record1["OAORNO"] = this.selectedParentRecord["ORNO"];
   //    this.callApi1(record1, "CMS100MI", "LstPrwCO");
   // }

   // protected callApi(record: MIRecord, program?: string, transaction?: string) {
   //    if (this.isBusy) {
   //       return;
   //    }

   //    this.isBusy = true;
   //    this.visibility = true;
   //    const request: IMIRequest = {
   //       includeMetadata: true,
   //       program: program,
   //       transaction: transaction,
   //       record: record,
   //       maxReturnedRecords: 100,
   //       typedOutput: true
   //    };

   //    this.miService.execute(request).subscribe((response: IMIResponse) => {
   //       if (!response.hasError()) {
   //          this.onResponse(response);
   //       } else {
   //          this.onError('Failed to list transaction data');
   //       }
   //       this.isBusy = false;
   //       this.visibility = false;
   //    }, (error: MIResponse) => {
   //       this.isBusy = false;
   //       this.visibility = false;
   //       this.clear();
   //       if (error.errorCode != "XRE0103") {
   //          this.onError('Failed to list transaction data', error);
   //       }
   //    });

   // }

//   protected callApi1(record: MIRecord, program?: string, transaction?: string) {
//       if (this.isBusy) {
//          return;
//       }

//       this.isBusy = true;
//       this.visibility = true;

//       const request: IMIRequest = {
//          includeMetadata: true,
//          program: program,
//          transaction: transaction,
//          record: record,
//          maxReturnedRecords: 100,
//          typedOutput: true
//       };

//       this.miService.execute(request).subscribe((response: IMIResponse) => {
//          if (!response.hasError()) {
//             this.onResponse1(response);
//          } else {
//             this.onError('Failed to list transaction data');
//          }
//          this.isBusy = false;
//          this.visibility = false;
//       }, (error: MIResponse) => {
//          this.isBusy = false;
//          this.visibility = false;
//          this.clear();
//          if (error.errorCode != "XRE0103") {
//             this.onError('Failed to list transaction data', error);
//          }
//       });

//    }
enableMarkUp()
{
  console.log(this.markUpFactor);
  this.markupService.markupfactor = this.markUpFactor;
  console.log(this.markupService.markupfactor);

}

   protected onError(message: string, error?: any) {
      this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('An error occured')
         .message(message + '. More details might be available in the browser console.')
         .buttons(buttons)
         .open();
   }

   // protected onResponse(response: IMIResponse) {
   //    this.isBusy = false;
   //    this.visibility = false;
   //    this.address1 = response.item["CUA1"];
   //    this.address2 = response.item["CUA2"];
   //    this.address3 = response.item["CUA3"];
   //    this.address4 = response.item["CUA4"];
   //    console.log(response);
   // }

   // protected onResponse1(response: IMIResponse) {
   //    this.isBusy = false;
   //    this.visibility = false;

   //    // Set date picker value
   //    this.datePicker.setValue(response.item["OARLDT"]);

   //    this.selectedRecord = response.item;
   //    let record: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
   //    this.orderDetailsChanged.emit(record);
   //    console.log(response)
   // }

}
