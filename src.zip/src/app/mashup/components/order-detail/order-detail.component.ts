import { ThrowStmt } from '@angular/compiler';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, EventEmitter, ViewEncapsulation, Input, SimpleChanges, Output, QueryList, ViewChildren, ViewChild } from '@angular/core';
import { StateKey } from '@angular/platform-browser';
import { MIRecord, CoreBase, IMIResponse, IMIRequest } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';

import { SohoMessageService, SohoDatePickerComponent } from 'ids-enterprise-ng';
import { DemoUserContextService } from 'src/app/demo/services/usercontext.service/usercontext.service';
import { DemoUtilService } from 'src/app/demo/services/util.service/util.service';
import { DestinationAddress } from 'src/app/demo/services/daddress.service/daddress.service';

@Component({
   encapsulation: ViewEncapsulation.None,
   selector: 'order-detail',
   styleUrls: ['./order-detail.component.css'],
   templateUrl: './order-detail.component.html'
})
export class OrderDetailComponent extends CoreBase {

   @Input() selectedParentRecord: MIRecord;
   @Output() orderDetailsChanged = new EventEmitter<MIRecord>();
   // @ViewChild(SohoDatePickerComponent) datePicker: SohoDatePickerComponent;

   isBusy: boolean;
   visibility:boolean ;

   deliveryDate: any;
   selectedRecord: MIRecord;
  oNumber:boolean;
   customerName: string;
   orderNumber: string;
   shipmentTotalWeight: number;
   customerNumber: any;
   name: boolean = true;
   address: MIRecord;
   dateFormat: string;
   OrderNumber: any;
   itemNumber: any;
   orderQuantity: any;
   totalWeight: any;
   itemBasic: number;
   LineNumber: any;
   destinationAddress: string;

   constructor(
      protected messageService: SohoMessageService,
      protected miService: MIService,
      public userContextService: DemoUserContextService,
      protected utilService: DemoUtilService,
      protected daddressConstruct: DestinationAddress) {
      super("OrderDetailComponent");
   }

   ngOnInit(): void {
   }

   // ngAfterViewInit() {
   //    try {
   //       // this.dateFormat = this.userContextService.getDateFormat();
   //       // Init Soho components
   //       // this.initDatePicker(this.datePicker );

   //       // console.log(this.datePicker +"  this is datepicker")
   //    } catch (err) {
   //       // console.log(this.datePicker +"  this is datepicker has error")
   //       this.logError(err);
   //    }
   // }

   /**
    *    This method loads data when selectedParentRecord has been loaded / changed //Y10005
    */
   ngOnChanges(changes: SimpleChanges) {
      if (changes.selectedParentRecord) {
         if (this.selectedParentRecord) {
            setTimeout(() => {
               this.getOrderDetails()

               console.log(this.selectedParentRecord)
            }, 250);
         } else {
            this.clear();
         }
      }
   }

   callApi(record: MIRecord, program?: string, transaction?: string) {
      if (this.isBusy) {
         return;
      }

      // this.isBusy = true;
      // this.visibility = true;

      const request: IMIRequest = {
         includeMetadata: true,
         program: program,
         transaction: transaction,
         record: record,
         maxReturnedRecords: 100,
         typedOutput: true
      };

      this.miService.execute(request).subscribe((response: IMIResponse) => {
         console.log(response);
         console.log(response.item);
         if(response.program === "CRS610MI"){
            this.daddressConstruct.daddressService = response.item;
            console.log(this.daddressConstruct.daddressService);

         }
         if(response.program === "OIS100MI" && response.transaction === "LstCOLineInfo"){
         this.itemNumber = response.item['ITNO'];
         this.orderQuantity = response.item['ORQA']
         this.LineNumber = response.item['PONR']
         console.log(this.itemNumber + "  " + this.orderQuantity + "  " + this.LineNumber)
         this.getItmBasic();
         }
         // if(this.itemNumber != undefined && this.itemBasic === 1){

         // console.log("entered into getitmBasic");

         // this.itemBasic = 2;
         // }
         if(response.program === "MMS200MI"){
         this.totalWeight = response.item["GRWE"];
         console.log(this.totalWeight);
         this.shipmentTotalWeight = (this.totalWeight) * (this.orderQuantity)
         console.log(this.shipmentTotalWeight);
      }

         if(!response.hasError() && this.name == false)
         {
          this.onResponse1(response);
         }
        else if (!response.hasError()) {
            this.onResponse(response);
            // this.getOrderDetails1();
         } else {
            this.onError('Failed to list transaction data');
         }

         this.isBusy = false;
         this.visibility = false;
      }, (error: MIResponse) => {
         this.isBusy = false;
         this.visibility = false;
         this.clear();
         if (error.errorCode != "XRE0103") {
            this.onError('Failed to list transaction data', error);
         }
      });

   }

   clear() {
      // Clear variables here
   }
   dateConcat(dateF: Date)
   {
      // dateFormat = new Date( "Tue May 20 2010 00:00:00 GMT+0530 ");
     console.log(dateF.getMonth())
     console.log(dateF.getDate())
     console.log(dateF.getFullYear())
         let year  = (dateF.getFullYear()).toString();
         let month = (dateF.getMonth() + 1).toString();
         month = month + '/'
         let date = dateF.getDate().toString();
          date = date + '/'
         // let finalDate = parseInt(month + date + year);
         // console.log(finalDate)
         // year = parseInt(dateFormat.substring(11,4));
         // console.log(year)
         // month = dateFormat.substring(4, 3) ;
         // day = parseInt(dateFormat.substring(8, 2));
         // const dtfm = this.userContext.DTFM;
         // Tue Apr 20 2010 00:00:00 GMT+0530

         return (month + date + year);

         // return new Date(year, month, day);

   }
   getLines()
   {
      let record: MIRecord = new MIRecord;
      record["ORNO"] = this.selectedParentRecord["ORNO"];
      // record["PONR"] = 1;
      this.callApi(record, "OIS100MI", "LstCOLineInfo")
   }
   getItmBasic()
   {
      let record: MIRecord = new MIRecord;
      record["ITNO"] = this.itemNumber;
      this.callApi(record, "MMS200MI", "GetItmBasic")
   }
   getOrderDetails() {
      let record: MIRecord = new MIRecord;
      // record["OAORNO"] = this.selectedParentRecord["ORNO"];
      // this.callApi(record, "CMS100MI", "LstPrwCO");
      record["ORNO"] = this.selectedParentRecord["ORNO"];
      console.log(this.selectedParentRecord)
      this.OrderNumber = record["ORNO"]
      this.callApi(record, "OIS100MI", "GetHead");
   }

   getOrderDetails1()
   {
      let record: MIRecord = new MIRecord;
      // record["CUNO"] = this.customerNumber;
      // this.callApi(record, "CRS610MI", "GetBasicData");
      record["CUNO"] = this.customerNumber;
      this.callApi(record, "CRS610MI", "LstAddresses");
      this.oNumber = true;
      this.getLines();
      this.itemBasic = 1;
   }

   // private initDatePicker(datePicker: SohoDatePickerComponent) {
   //    datePicker.dateFormat = this.dateFormat;
   //    console.log(datePicker.dateFormat + " this is datepicker.dateformat")
   // }

   protected onError(message: string, error?: any) {
      this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('An error occured')
         .message(message + '. More details might be available in the browser console.')
         .buttons(buttons)
         .open();
   }

   public onDeliveryDateChanged(event: any) {

      if (event.data) {
         // let newDeliveryDate =  (this.deliveryDate).toString();
         this.selectedRecord["RLDT"] = this.userContextService.getDate(this.deliveryDate);
         console.log(this.selectedRecord["RLDT"])
         let record: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
         this.orderDetailsChanged.emit(record);
         console.log(this.orderDetailsChanged);

      }
   }

   protected onResponse(response: IMIResponse) {
      this.isBusy = false;
      this.visibility = false;
   // console.log(response.item["CUNO"])
      this.customerNumber = response.item["CUNO"]
      // this.deliveryDate = response.item["RLDT"]
      console.log(response.item["RLDT"])
      // this.datePicker.setValue(response.item["RLDT"]);

     this.daddressConstruct.deliveryDateService =  this.dateConcat(response.item["RLDT"]);

      console.log(this.deliveryDate)

   //   let record: MIRecord = new MIRecord;
   //   record["CUA1"] = response.item['CUA1'];
   //   record["CUA2"] = response.item['CUA2'];
   //   record["CUA3"] = response.item['CUA3'];
   //   record["CUA4"] = response.item['CUA4'];
   //   this.address = record;
   //   console.log(this.address)
   //   this.address["CUA1"] =response.item["CUA1"]
   //   this.address["CUA2"] =response.item["CUA2"]
   //   this.address["CUA3"] =response.item["CUA3"]
   //   this.address["CUA4"] =response.item["CUA4"]
     console.log(this.customerNumber)
     console.log(this.address  + "  this is address")

   //   console.log(response.item["CUNM"])
   //   this.customerName = response.item["CUNM"];

     console.log(this.name + "   true or false");
     console.log(this.orderNumber + "  order number")
     if(this.name == true)
     {
        console.log(this.name)
        this.getOrderDetails1();

      this.selectedRecord = response.item;
      let record: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
      this.orderDetailsChanged.emit(record);
      this.name = false;
     }
     console.log(this.name);
     console.log()


   //  this.getOrderDetails1();





      // this.customerName = response.item["OKCUNM"];
      // this.orderNumber = response.item["OAORNO"];
      // this.weight = response.item["OAGRWE"];

      // Set date picker value
      // this.datePicker.setValue(response.item["OARLDT"]);


   }
   protected onResponse1(response: IMIResponse) {
      this.isBusy = false;
      this.visibility = true;
   //    console.log(response.item["CUNO"])

     this.customerNumber = response.item["CUNO"]
     this.orderNumber = this.OrderNumber;
     console.log(response.item)
     let record: MIRecord = new MIRecord;
     record["CUA1"] = response.item['CUA1'];
     record["CUA2"] = response.item['CUA2'];
     record["CUA3"] = response.item['CUA3'];
     record["CUA4"] = response.item['CUA4'];
     record["RLDT"] = this.deliveryDate;
     this.address = record;
     console.log(this.address)
     console.log( "   this is Address")
     this.selectedParentRecord['CUA1'] = response.item['CUA1'];
     this.selectedParentRecord["CUA2"] = response.item['CUA2'];
     this.selectedParentRecord["CUA3"] = response.item['CUA3'];
     this.selectedParentRecord["CUA4"] = response.item['CUA4'];
     this.selectedParentRecord["TOWN"] = response.item['TOWN'];
     this.selectedParentRecord["PONO"] = response.item['PONO'];
     console.log(this.selectedParentRecord);

   //   this.address["CUA1"] =response.item["CUA1"]
   //   this.address["CUA2"] =response.item["CUA2"]
   //   this.address["CUA3"] =response.item["CUA3"]
   //   this.address["CUA4"] =response.item["CUA4"]
     console.log(this.customerNumber + "  customer number")


     console.log(response.item["CUNM"])
     console.log(this.deliveryDate);

     this.customerName = response.item["CUNM"];

   //   console.log(this.datePicker.setValue(this.deliveryDate));
     console.log(this.name);
   //   console.log(this.datePicker.setValue(this.deliveryDate))
   //   if(this.name == true)
   //   {
   //      console.log(this.name)
   //      this.getOrderDetails1();

   //    this.selectedRecord = response.item;
   //    let record: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
   //    this.orderDetailsChanged.emit(record);
   //    this.name = false;
   //   }
   this.selectedRecord = response.item;
      let record1: MIRecord = this.utilService.getDuplicateRecord(this.selectedRecord);
      this.orderDetailsChanged.emit(record1);
     console.log(this.name);
     console.log()


   //  this.getOrderDetails1();





      // this.customerName = response.item["OKCUNM"];
      // this.orderNumber = response.item["OAORNO"];
      // this.weight = response.item["OAGRWE"];

      // Set date picker value
      // this.datePicker.setValue(response.item["OARLDT"]);


   }

}
// 0010000001 CO Number
