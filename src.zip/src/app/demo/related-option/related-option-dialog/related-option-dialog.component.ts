import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { CoreBase, MIRecord, IBookmark, Log } from '@infor-up/m3-odin';
import { DemoRelatedOptionService } from 'src/app/demo/services/relatedoption.service/relatedoption.service';
import { DemoPanelComponent, IDetailPanelMessage, PanelResult } from '../../bookmark/panel/panel/panel.component';
import { SohoToastService } from 'ids-enterprise-ng';
import { Subscription } from 'rxjs';

@Component({
   encapsulation: ViewEncapsulation.None,
   styleUrls: ['./related-option-dialog.component.css'],
   templateUrl: './related-option-dialog.component.html'
})
export class DemoRelatedOptionDialogComponent extends CoreBase implements OnInit {
   @ViewChild('detailPanel') detailPanel: DemoPanelComponent;
   bookmark: IBookmark;
   isBusy = false;
   isReady = false;
   selectedRecord: MIRecord;
   subscription: Subscription;

   constructor(protected relatedOptionService: DemoRelatedOptionService, private toastService: SohoToastService) {
      super('DemoRelatedOptionDialogComponent');
   }

   ngOnInit(): void {
      this.isBusy = true;
      this.selectedRecord = this.relatedOptionService.selectedRecord;
      let bookmark: IBookmark = this.relatedOptionService.selectedAction.bookmark;

      // Get bookmark values
      let keyNames = bookmark.keyNames.split(",");
      let fieldNames = bookmark.fieldNames.split(",");
      let values: MIRecord = new MIRecord();

      for (let key of keyNames) {
         if (this.selectedRecord[key]) {
            values[key] = this.selectedRecord[key];
            // Special check for blank value
         } else if (this.selectedRecord[key] === "") {
            values[key] = this.selectedRecord[key];
            // Special check for zero value
         } else if (this.selectedRecord[key] === 0) {
            values[key] = this.selectedRecord[key];
         } else {
            const shortKey = key.substr(key.length - 4);
            if (this.selectedRecord[shortKey]) {
               values[key] = this.selectedRecord[shortKey];
               // Special check for blank value
            } else if (this.selectedRecord[shortKey] === "") {
               values[key] = this.selectedRecord[shortKey];
               // Special check for zero value
            } else if (this.selectedRecord[shortKey] === 0) {
               values[key] = this.selectedRecord[shortKey];
            } else {
               Log.error("Key value not found. Stop executing bookmark");
               return;
            }
         }
      }

      for (let field of fieldNames) {
         if (this.selectedRecord[field]) {
            values[field] = this.selectedRecord[field];
         } else if (this.selectedRecord[field] === "") {
            // Special check for blank value
            values[field] = this.selectedRecord[field];
         } else if (this.selectedRecord[field] === 0) {
            // Special check for zero value
            values[field] = this.selectedRecord[field];
         } else {
            const shortKey = field.substr(field.length - 4);
            if (this.selectedRecord[shortKey]) {
               values[field] = this.selectedRecord[shortKey];
            } else if (this.selectedRecord[shortKey] === "") {
               // Special check for blank value
               values[field] = this.selectedRecord[shortKey];
            } else if (this.selectedRecord[shortKey] === 0) {
               // Special check for zero value
               values[field] = this.selectedRecord[shortKey];
            } else {
               Log.error("Field value not found");
            }
         }
      }

      // Set bookmark
      bookmark.values = values;
      this.bookmark = bookmark;

      this.isReady = true;
   }

   ngAfterViewInit() {
      /**
       *    Subscribe to the detail panels updateCompleteEmitter, so we know when the
       *    bookmark update has completed
       */
      this.subscription = this.detailPanel.updateCompleteEmitter.subscribe((response) => {
         this.onUpdateComplete(response);
      });
   }

   ngOnDestroy() {
      // Unsubscribe
      if (this.subscription) {
         this.subscription.unsubscribe();
      }
      // this.detailPanel.updateCompleteEmitter.unsubscribe();
   }

   /**
    *    This method closes the contextual action panel
    */
   onCancel() {
      this.relatedOptionService.panelRef.close(true);
   }

   /**
    *    This method is called to save data from the detail panel
    */
   onSave() {
      this.detailPanel.onSave();
   }

   /**
    *    This method is called from the detail panel updateCompleteEmitter set in
    *    ngAfterViewInit
    */
   onUpdateComplete(response: IDetailPanelMessage) {
      if (response.type == PanelResult.Finished) {
         this.toastService.show({
            title: 'Action Completed',
            message: this.relatedOptionService.selectedAction.messageComplete,
            position: SohoToastService.TOP_RIGHT
         });
         this.relatedOptionService.panelRef.close(true);
      } else if (response.type == PanelResult.Exit) {
         this.relatedOptionService.panelRef.close(true);
      }
   }

   showBusyindicator(value: boolean) {
      this.isBusy = value;
   }

}
