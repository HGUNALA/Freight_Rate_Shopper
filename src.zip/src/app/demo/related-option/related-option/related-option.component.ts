import { Component, OnInit, ViewEncapsulation, Input, EventEmitter } from '@angular/core';
import { CoreBase, IMIRequest, IMIResponse, MIRecord, Log, IBookmark } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { SohoContextualActionPanelService, SohoToastService } from 'ids-enterprise-ng';
import { DemoRelatedOptionService } from '../../services/relatedoption.service/relatedoption.service';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';
import { DemoLaunchService } from '../../services/launch.service/launch.service';
import { DemoRelatedOptionDialogComponent } from '../related-option-dialog/related-option-dialog.component';
import { DemoUserContextService } from '../../services/usercontext.service/usercontext.service';

@Component({
   encapsulation: ViewEncapsulation.Emulated,
   selector: 'related-option',
   styleUrls: ['./related-option.component.css'],
   templateUrl: './related-option.component.html'
})
export class DemoRelatedOptionComponent extends CoreBase implements OnInit {

   @Input() actionsHeader: string;
   @Input() customActionsHeader: string;
   @Input() drillBacksHeader: string;

   aliases = [
      {
         field: "ITNO",
         aliasFields: ["PRNO", "MTNO"]
      }
      // {
      //    field: "ITNO",
      //    aliasFields: ["PRNO", "MTNO"]
      // }
   ];

   heading: string;

   actions: IAction[] = [];
   customActions: ICustomAction[] = [];
   drillBacks: IDrillBack[] = [];
   relateds: IRelated[] = [];
   selectedRecord: MIRecord = null;

   constructor(private miService: MIService,
      private userContextService: DemoUserContextService,
      private panelService: SohoContextualActionPanelService,
      private toastService: SohoToastService,
      private launchService: DemoLaunchService,
      private relatedOptionService: DemoRelatedOptionService) {
      super('DemoRelatedOptionsComponent');
   }

   /**
    *    This method implements the following functionality
    *
    *    Actions. This observable is used to set the actions defined in, and passed
    *    from, an M3 demo list component
    *
    *    Custom Actions. This observable is used to set the custom actions defined in,
    *    and passed from, an M3 demo list component
    *    Custom actions are used when you cannot use regular actions. In this case we
    *    we emit an event that the M3 demo list component subscribes to.
    *    The M3 demo list component is responsible for implementing the functionality
    *    that should take place when the custom action is clicked
    *
    *    Drillbacks. This observable is used to set the drillbacks defined in, and passed
    *    from, an M3 demo list component
    *
    *    Selected record. This observable is used to set the selected record in an
    *    M3 demo list component. When we have a selected record, any actions and drillbacks
    *    are enabled
    *
    */
   ngOnInit(): void {
      // Set heading
      const lang = this.userContextService.userContext.language;

      switch (lang) {
         case "FR":
            this.heading = "Liens";
            break;
         case "GB":
            this.heading = "Links";
            break;
         case "SE":
            this.heading = "L�nkar";
            break;
         default:
            this.heading = "Links";
            break;
      }

      // Relateds
      this.relatedOptionService.relatedsChangedEvent.subscribe((relateds: IRelated[]) => {
         this.relateds = relateds;
      });

      // Selected record
      this.relatedOptionService.recordSelectedEvent.subscribe((related: IRelated) => {
         try {
            if (related) {
               if (this.relateds.length > 0) {
                  const index = this.relateds.map(e => e.name).indexOf(related.name);
                  if (index >= 0) {
                     this.relateds[index].record = related.record;
                  }
               }
            }
         } catch (err) {
            this.logError(err);
         }
      });
   }

   /**
    *    Unsubscribe observables and event emitters here
    */
   ngOnDestroy() {
      // this.relatedOptionService.actionsInitializedEvent.unsubscribe();
      // this.relatedOptionService.drillBacksInitializedEvent.unsubscribe();
      this.relatedOptionService.recordSelectedEvent.unsubscribe();
   }

   /**
    *    This method is called when the user clicks an action
    */
   executeAction(action: IAction, related: IRelated) {
      this.relatedOptionService.selectedAction = action;
      const selectedRecord: MIRecord = related.record;

      // Stop execution if no record has been selected
      if (!selectedRecord) {
         this.toastService.show({
            title: 'No record selected',
            message: "Please select a record before clicking on the link",
            position: SohoToastService.TOP_RIGHT
         });
         return;
      }

      this.relatedOptionService.selectedRecord = related.record;

      this.relatedOptionService.panelRef = this.panelService
         .contextualactionpanel(DemoRelatedOptionDialogComponent, this.relatedOptionService.placeHolder)
         .title(action.name)
         .initializeContent(true)
         .trigger('immediate')
         .open()
   }

   /**
    *    This method is called when the user clicks a custom action
    */
   executeCustomAction(customAction: ICustomAction, related: IRelated) {
      this.relatedOptionService.customActionClickedEvent.emit(customAction);
   }

   /**
    *    This method is called when the user clicks a drillback
    */
   executeDrillBack(drillBack: IDrillBack, related: IRelated) {
      let record: MIRecord = new MIRecord();
      let selectedRecord = new MIRecord();

      record["FILE"] = drillBack.bookmark.table;
      // record["PGNM"] = drillBack.bookmark.program;

      selectedRecord = related.record;

      // Stop execution if no record has been selected
      if (!selectedRecord) {
         this.toastService.show({
            title: 'No record selected',
            message: "Please select a record before clicking on the link",
            position: SohoToastService.TOP_RIGHT
         });
         return;
      }

      const request: IMIRequest = {
         includeMetadata: true,
         program: "BOOKMKMI",
         transaction: "GetParByTable",
         record: record,
         maxReturnedRecords: 1,
         typedOutput: true
      };

      this.miService.execute(request).subscribe((response: IMIResponse) => {
         if (!response.hasError()) {

            const keys = Object.keys(response.item);
            // Get bookmark key names
            let keyNames: string[] = [];
            for (let i = 2; i < 17; i++) {
               const key = keys[i];
               const keyValue = response.item[key];
               if (keyValue) {
                  keyNames.push(keyValue);
               }
            }

            // Get bookmark values
            let values: MIRecord = new MIRecord();
            for (let key of keyNames) {
               if (selectedRecord[key]) {
                  values[key] = selectedRecord[key];
               } else {
                  const shortKey = key.substr(key.length - 4);
                  if (selectedRecord[shortKey]) {
                     values[key] = selectedRecord[shortKey];
                     // Special check for zero value
                  } else if (selectedRecord[shortKey] === 0) {
                     values[key] = selectedRecord[shortKey];
                  } else {
                     // Special check for alias fields
                     const aliasField = this.getAliasField(shortKey, selectedRecord);
                     if (aliasField) {
                        values[key] = selectedRecord[aliasField];
                     } else {
                        Log.warning("Bookmark key value not found, setting value to blank");
                        values[key] = " ";
                     }
                  }
               }
            }

            const bookmark: IBookmark = {
               program: drillBack.bookmark.program,
               table: drillBack.bookmark.table,
               keyNames: keyNames.toString(),
               startPanel: drillBack.bookmark.startPanel ? drillBack.bookmark.startPanel : "B",
               includeStartPanel: drillBack.bookmark.includeStartPanel ? true : false,
               sortingOrder: drillBack.bookmark.sortingOrder ? drillBack.bookmark.sortingOrder : "1",
               option: drillBack.bookmark.option,
               view: drillBack.bookmark.view ? drillBack.bookmark.view : null,
               values: values
            };
            this.launchService.launchBookmark(bookmark);
         }
      }, (error: MIResponse) => {
         Log.error(error.errorMessage);
      });
   }

   getAliasField(key: string, record: MIRecord): string {
      for (let alias of this.aliases) {
         if (alias.field == key) {
            for (let aliasField of alias.aliasFields) {
               if (record[aliasField]) {
                  return aliasField;
               }
            }
         }
      }
      return null;
   }

}

export interface IAction {
   bookmark: IBookmark,
   messageComplete: string,
   name: string
}

export interface ICustomAction {
   id: string,
   bookmark?: IBookmark,
   messageComplete?: string,
   name: string
}

export interface IDrillBack {
   bookmark: IBookmark,
   name: string,
}

export interface IRelated {
   actions: IAction[],
   customActions: ICustomAction[],
   drillBacks: IDrillBack[],
   name: string,
   record: MIRecord
}
