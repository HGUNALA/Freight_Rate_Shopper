import { Input, ViewChild, ElementRef, NgZone, ViewChildren, QueryList, SimpleChange, EventEmitter, Output, SimpleChanges } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { CoreBase, IMIRequest, IMIResponse, MIRecord, IMIMetadataInfo } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { SohoDataGridComponent, SohoMessageService, SohoDatePickerComponent } from 'ids-enterprise-ng';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';
import { DemoBusinessContextService } from 'src/app/demo/services/businesscontext.service/businesscontext.service';
import { DemoInitService } from 'src/app/demo/services/initialize.service/initialize.service';
import { DemoPersonalizationService } from 'src/app/demo/services/personalization.service/personalization.service';
import { DemoUserContextService } from 'src/app/demo/services/usercontext.service/usercontext.service';
import { DemoRelatedOptionService } from '../services/relatedoption.service/relatedoption.service';
import { IDrillBack, IAction, ICustomAction, IRelated } from 'src/app/demo/related-option/related-option/related-option.component';
import { TranslateService } from '@ngx-translate/core';
import { DemoUtilService } from '../services/util.service/util.service';
import { DemoBookmarkService } from '../services/bookmark.service/bookmark.service';

/**
 *
 *    This is a base class for showing M3 data in a list.
 *
 *    It can optionally show a search input box (as defined by the isSearchable decorator),
 *    where the user can key in a value and search for data. This require that a search
 *    api transaction has been defined.
 *
 *    The child class should call the ngOnInit method where the following variables must
 *    be set.
 *
 *    1. apiProgram
 *    2. apiTransaction
 *
 *    The following variables should optionally be set if applicable.
 *
 *    1. apiSearchProgram
 *    2. apiSearchTransaction
 *    3. personalizationProgram
 *    4. relatedOptions, actions and custom actions
 *
 */

export abstract class DemoListComponent extends CoreBase {
   @Input() header: string;
   @Input() isDateRange: boolean;
   @Input() isDrillable: boolean;
   @Input() isMaxRecordCounter: boolean;
   @Input() isSearchable: boolean;
   @Input() dateRangeField: string;
   @Input() navigateTo: string;
   @Input() personalizationProgram: string;
   @Input() selectedParentRecord: MIRecord;
   @Output() selectionChanged = new EventEmitter<MIRecord>();
   @ViewChild(SohoDataGridComponent) datagrid: SohoDataGridComponent;
   @ViewChildren(SohoDatePickerComponent) datePickers: QueryList<SohoDatePickerComponent>;

   maxRecords = 100;
   pageSize = 25;
   columns: SohoDataGridColumn[] = [];
   datagridOptions: SohoDataGridOptions;
   searchOptions: SohoSearchFieldOptions;

   apiInputRecord: MIRecord;

   apiProgram: string;
   apiTransaction: string;
   apiSearchProgram: string;
   apiSearchTransaction: string;

   dateFormat: string;
   fromDate: any;
   toDate: any;

   private intersectionObserver: IntersectionObserver;

   isBusy: boolean;
   isReady: boolean;
   isDataLoaded: boolean;
   isOptionsLoaded: boolean;
   isPersonalizationReady: boolean;

   personalization: any;
   personalizationFieldAlias: MIRecord = new MIRecord();
   personalizationCellTemplate: any;

   actions: IAction[] = [];
   customActions: ICustomAction[] = [];
   drillBacks: IDrillBack[] = [];
   related: IRelated;

   searchQuery: string = "";
   selectedRecord: MIRecord;

   constructor(
      protected elementRef: ElementRef,
      protected miService: MIService,
      protected messageService: SohoMessageService,
      protected route: ActivatedRoute,
      protected router: Router,
      protected translate: TranslateService,
      protected zone: NgZone,
      protected bookmarkService: DemoBookmarkService,
      protected businessContextService: DemoBusinessContextService,
      protected initService: DemoInitService,
      protected personalizationService: DemoPersonalizationService,
      protected relatedOptionService: DemoRelatedOptionService,
      protected userContextService: DemoUserContextService,
      protected utilService: DemoUtilService) {
      super('DemoListComponent');
   }

   /**
    *    Unsubscribe observables and event emitters here
    */
   ngOnDestroy() {
      this.intersectionObserver.unobserve(<Element>(this.elementRef.nativeElement));
   }

   /**
    *    This method loads data when selectedParentRecord has been loaded / changed
    */
   ngOnChanges(changes: SimpleChanges) {
      if (changes.selectedParentRecord) {
         if (this.selectedParentRecord) {
            setTimeout(() => {
               this.onApply();
            }, 250);
         } else {
            this.clear();
         }
      }
   }

   /**
    *    This method is responsible for initializing Soho components
    */
   ngAfterViewInit() {
      // Init Soho components
      this.datePickers.forEach(datePicker => this.initDatePicker(datePicker));

      if (this.actions.length > 0 || this.customActions.length > 0 || this.drillBacks.length > 0) {

         // Create related object containing actions, customActions and drillbacks
         this.related = {
            actions: this.actions,
            customActions: this.customActions,
            drillBacks: this.drillBacks,
            name: this.header,
            record: null
         }

      }

      // Add IntersectionObserver
      this.intersectionObserver = new IntersectionObserver(elements => {
         for (let element of elements) {
            if (element.target == this.elementRef.nativeElement) {
               if (element.isIntersecting) {
                  this.loadDataAndOptions();
               } else {
                  this.unloadDataAndOptions();
               }
            }
         }
      }, {});
      this.intersectionObserver.observe(<Element>(this.elementRef.nativeElement));

      // Custom Actions
      this.relatedOptionService.customActionClickedEvent.subscribe((customAction: ICustomAction) => {
         this.onCustomAction(customAction);
      });
   }

   /**
    *    This method calls the API
    */
   protected callApi(record: MIRecord, program?: string, transaction?: string) {
      if (this.isBusy) {
         return;
      }

      this.isBusy = true;

      const request: IMIRequest = {
         includeMetadata: true,
         program: program,
         transaction: transaction,
         record: record,
         maxReturnedRecords: this.maxRecords,
         typedOutput: true
      };

      this.miService.execute(request).subscribe((response: IMIResponse) => {
         if (!response.hasError()) {
            this.onResponse(response);
            this.isDataLoaded = true;
         } else {
            this.onError('Failed to list transaction data');
         }
         this.isBusy = false;
      }, (error: MIResponse) => {
         this.isBusy = false;
         this.clear();
         if (error.errorCode != "XRE0103") {
            this.onError('Failed to list transaction data', error);
         }
      });

   }

   /**
    *    A method that clears class variables
    */
   protected clear() {
      if (this.datagrid) {
         this.datagrid.dataset = [];
      }
      if (this.datagridOptions) {
         this.datagridOptions.dataset = [];
      }
      // this.isReady = false;
      this.isDataLoaded = false;
      this.isOptionsLoaded = false;
      this.searchQuery = "";
      this.selectedRecord = null;
   }

   /**
    *    Create record with fields without prefix. Take values from selectedRecord
    *    and selectedParentRecord
    */
   protected getTrimmedSelectedRecord(isGetSelectedRecord: boolean, isGetSelectedParentRecord: boolean): MIRecord {
      let fields: string[];
      let record: MIRecord;

      record = new MIRecord();
      record["CONO"] = this.userContextService.userContext.currentCompany;

      // SelectedParentRecord
      if (isGetSelectedParentRecord) {
         if (this.selectedParentRecord) {
            fields = Object.keys(this.selectedParentRecord);
            for (let field of fields) {
               if (field.length == 6) {
                  const shortField = field.substring(2);
                  record[shortField] = this.selectedParentRecord[field];
               } else {
                  record[field] = this.selectedParentRecord[field];
               }
            }
         }
      }

      // SelectedRecord
      if (isGetSelectedRecord) {
         if (this.selectedRecord) {
            fields = Object.keys(this.selectedRecord);
            for (let field of fields) {
               if (field.length == 6) {
                  const shortField = field.substring(2);
                  record[shortField] = this.selectedRecord[field];
               } else {
                  record[field] = this.selectedRecord[field];
               }
            }
         }
      }

      return record;
   }

   /**
    *    This method must be defined in the child class and make a super call to
    *    the parent class (this class). It is called by the onRouteNavigation
    *    method and initializes
    *
    *    1. columns
    *    2. searchOptions
    *    3. datagridOptions
    *    4. Api input record
    *
    */
   protected init() {
      this.clear();
      this.initColumns();
      this.dateFormat = this.userContextService.getDateFormat();
      if (this.isSearchable) {
         this.searchOptions = this.initService.initSearchOptions();
      }
   }

   /**
    *    This method is called from the parent class init method. It contains the
    *    function for handling conditional styles for datagrid cells.
    *
    *    The programmer can override this method in the child class if desired. If
    *    that is the case, the overriding child method should do a super call to the
    *    parent method.
    *
    *    If the programmer does not override this method, the columns will be set in
    *    the on response method.
    *
    */
   protected initColumns() {
      this.personalizationCellTemplate = (row, cell, value, col, record) => {
         let field: string = col.field;
         let shortField: string = field.length == 4 ? field : field.substring(2);
         let alias: string = this.personalizationFieldAlias[shortField];
         let keyName: string = alias ? alias : shortField;

         // Get personalizations
         const cssClass = this.personalizationService.getConditionalStyle(this.personalization, keyName, value, record);
         const replacementText = this.personalizationService.getReplacementText(this.personalization, keyName, value, record);

         // Set personalizations
         const cellValue = replacementText ? replacementText : value;
         if (cssClass) {
            return `<div title="` + value + `" class="` + cssClass + `"><div><div style="max-height:30px;padding: 0 5px">` + cellValue + `</div></div></div>`
         } else {
            return `<span>` + cellValue + `</span>`
         }
      };
      this.columns = [];
      this.columns.push({
         width: 'auto', id: 'col-last', field: 'last', name: '', resizable: true, sortable: false
      });
   }

   /**
    *    This method sets the date format for any datepickers used by the component
    */
   protected initDatePicker(datePicker: SohoDatePickerComponent) {
      datePicker.dateFormat = this.dateFormat;
   }

   /**
    *    This method retrieves personalizations and calls the api method
    *    for data retrieval
    */
   protected listData(record: MIRecord) {
      if (this.personalizationProgram && !this.isPersonalizationReady) {
         this.personalizationService.getPersonalization(this.personalizationProgram).subscribe((response) => {
            this.personalization = response;
            this.isPersonalizationReady = true;
            this.callApi(record, this.apiProgram, this.apiTransaction);
         });
      } else {
         this.callApi(record, this.apiProgram, this.apiTransaction);
      }
   }

   /**
    *    This method is called by the IntersectionObserver and is responsible
    *    for lazy loading of data and related options
    */
   protected loadDataAndOptions() {
      if (!this.isOptionsLoaded) {
         /**
          *    Load related object, containing actions, customActions and drillbacks.
          *    Wait for other components to clear their options
          */

         setTimeout(() => {
            if (this.related) {
               this.relatedOptionService.setRelated(this.related);
            }
            this.isOptionsLoaded = true;
         }, 250);
      }
   }

   /**
    *    This method is called when the apply button is pressed.
    *
    *    If the @isDateRange variable is set to true, it automatically adds data
    *    filter fields, as defined by variable @dateRangeField to the API transaction
    *    call. All other API transaction fields must be set in the child method
    */
   protected onApply() {

      // Clear dirty array when reloading data
      try {
         if (this.datagrid) {
            this.datagrid["datagrid"].dirtyArray = [];
         }
      } catch (err) {
         this.logError(err);
      }

      // Set apiInputRecord
      if (this.searchQuery.length > 0) {
         if (this.isDateRange) {
            if (this.fromDate || this.toDate) {
               this.apiInputRecord["SQRY"] += " " + this.dateRangeField + ":";
               this.apiInputRecord["SQRY"] += "[";
               if (this.fromDate) {
                  this.apiInputRecord["SQRY"] += this.userContextService.getDateFormatted(this.fromDate);
               } else {
                  this.apiInputRecord["SQRY"] += "*";
               }
               this.apiInputRecord["SQRY"] += " TO ";
               if (this.toDate) {
                  this.apiInputRecord["SQRY"] += this.userContextService.getDateFormatted(this.toDate);
               } else {
                  this.apiInputRecord["SQRY"] += "*";
               }
               this.apiInputRecord["SQRY"] += "]";
            }
         }
         this.searchData(this.apiInputRecord);
      } else {
         if (this.isDateRange) {
            if (this.fromDate) {
               this.apiInputRecord["F_" + this.dateRangeField] = this.userContextService.getDateFormatted(this.fromDate);
            }
            if (this.toDate) {
               this.apiInputRecord["T_" + this.dateRangeField] = this.userContextService.getDateFormatted(this.toDate);
            }
         }
         this.listData(this.apiInputRecord);
      }
      this.isDataLoaded = true;
   };

   /**
    *    This method when a custom action is clicked. It is called by the
    *    customActionClickedEvent in the ngAfterViewInit method.
    *
    *    Custom actions are used when you cannot use regular actions. Therefore
    *    the M3 demo list component is responsible for implementing the
    *    functionality that should take place when the custom action is clicked.
    *
    *    The custom action functionality should be defined in the child class. A
    *    check should be made of the custom action id so that the correct M3 demo list
    *    component is handling the custom action
    *
    *    Example:
    *    if (customAction == "releasePopLine") {
    *       ...
    *    }
    *
    */
   protected onCustomAction(customAction: ICustomAction) { }

   /**
    *    An error handling method for the API transaction call
    */
   protected onError(message: string, error?: any) {
      this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('An error occured')
         .message(message + '. More details might be available in the browser console.')
         .buttons(buttons)
         .open();
   }

   /**
    *    This method is called when the from date is changed
    */
   protected onFromDateChanged(event: any) {
   }

   /**
    *    This method is called when pressing Enter in the search query input field
    */
   protected onKey(event: KeyboardEvent) {
      if (event.code == "Enter") {
         this.onApply();
      }
   }

   /**
    *    This method is called when the max records dropdown value is changed
    */
   public onMaxRecordsChange() {
      this.onApply();
   }

   /**
    *    This method is called by the
    *    drill down button in the datagrid
    */
   protected onNavigateTo(args: any) {
      this.preNavigateTo(args);
      if (this.selectedRecord) {
         const record = this.getTrimmedSelectedRecord(true, true);
         this.postNavigateTo(record);
      }
   };

   /**
    *    This method is called once the API transaction call has completed.
    *    The data returned by the API is added to the dataset on the datagrid
    */
   protected onResponse(response: IMIResponse) {
      try {

         /**
          *    If we have more than 2 columns it means that they have been
          *    set in the initColumns method. Otherwise set the columns based
          *    on the fields returned from the API transaction
          */
         if (this.columns.length <= 1) {

            this.columns = [];
            const fieldNames = Object.keys(response.metadata);

            /**
             *    Drill enabled
             */
            if (this.isDrillable) {
               this.columns.push({
                  id: 'drilldown', field: 'button', name: '', sortable: false,
                  resizable: false, align: 'center', formatter: Soho.Formatters.Drilldown, click: (e, args) => {
                     this.onNavigateTo(args);
                  }
               });
            }

            for (let fieldName of fieldNames) {
               let column: SohoDataGridColumn;
               let fieldMetadata: IMIMetadataInfo = response.metadata[fieldName];

               // Field width calculation formula
               let fieldWidth: number = fieldMetadata.length * 11;

               // Min field width should be 110 and max should be 300
               fieldWidth = fieldWidth < 110 ? 110 : fieldWidth;
               fieldWidth = fieldWidth > 300 ? 300 : fieldWidth;

               const shortFieldName: string = fieldName.length == 4 ? fieldName : fieldName.substring(2);
               const alias: string = this.personalizationFieldAlias[shortFieldName];
               const keyName: string = alias ? alias : shortFieldName;

               /**
                *    Field is a date
                */
               if (fieldMetadata.isDate()) {
                  this.columns.push({
                     width: 120, id: 'col-' + fieldName, field: fieldName, name: fieldMetadata.description,
                     resizable: true, sortable: true, formatter: Soho.Formatters.Date,
                     dateFormat: this.dateFormat, align: 'right'
                  });
                  continue;
               }

               /**
                *    Field has a personalization
                */
               if (this.personalizationService.fieldHasPersonalization(this.personalization, keyName)) {
                  this.columns.push({
                     width: 175, id: 'col-' + fieldName, field: fieldName,
                     name: fieldMetadata.description, resizable: true, filterType: 'text',
                     sortable: true, formatter: this.personalizationCellTemplate
                  });
                  continue;
               }

               /**
                *    Field is a string
                */
               if (fieldMetadata.isString()) {
                  this.columns.push({
                     width: fieldWidth, id: 'col-' + fieldName, field: fieldName,
                     name: fieldMetadata.description, filterType: 'text',
                     resizable: true, sortable: true
                  });
                  continue;
               }

               /**
                *    Field is a number
                */
               if (fieldMetadata.isNumeric()) {

                  // Amount and quantity fields - 120px
                  if (this.utilService.isAmount(keyName) || this.utilService.isQuantity(keyName)) {
                     this.columns.push({
                        width: 120, id: 'col-' + fieldName, field: fieldName,
                        name: fieldMetadata.description, resizable: true,
                        sortable: false, formatter: Soho.Formatters.Decimal, align: 'right'
                     });

                     // Order line fields - 50px
                  } else if (this.utilService.isOrderLine(keyName)) {
                     this.columns.push({
                        width: 50, id: 'col-' + fieldName, field: fieldName,
                        name: fieldMetadata.description, resizable: true,
                        sortable: false, align: 'right'
                     });

                     // All other numeric fields - 110px
                  } else {
                     this.columns.push({
                        width: 110, id: 'col-' + fieldName, field: fieldName,
                        name: fieldMetadata.description, filterType: 'text',
                        resizable: true, sortable: true, align: 'right'
                     });
                  }

                  continue;
               }
            }

            /**
             *    Last column
             */
            this.columns.push({
               width: 'auto', id: 'col-last', field: 'last', name: '', resizable: true, sortable: false
            });

            // Add the columns to the datagrid
            if (this.datagrid) {
               this.datagrid.columns = this.columns;
            } else {
               this.datagridOptions.columns = this.columns;
            }

         }

         // Save any existing filter conditions
         let filterConditions: any;

         try {
            if (this.datagrid) {
               if (this.datagrid["datagrid"]) {
                  filterConditions = this.datagrid["datagrid"].filterConditions();
               }
            }
         } catch (err) {
            this.logError(err);
         }

         // Set data
         if (this.datagrid) {
            // In case of refresh and the datagrid was sorted, re-apply sorting
            try {
               if (this.datagrid["datagrid"].sortColumn) {
                  this.datagrid["datagrid"].restoreSortOrder = true;
               }
            } catch (err) {
               this.logError(err);
            }
            this.datagrid.dataset = response.items;
         } else {
            this.datagridOptions.dataset = response.items;
         }

         // Restore filterconditions
         if (filterConditions) {
            // this.datagrid.setFilterConditions(filterConditions);
            this.datagrid.applyFilter(filterConditions);
         }

         this.selectionChanged.emit(null);

      } catch (err) {
         this.logError(err);
      }
   }

   /**
    *    This method sets the selected record. If no line/record is
    *    selected it clears the related options.
    *
    *    If a line/record is selected, the related options, and the
    *    business context are loaded by the onSelected method in the
    *    child class.
    */
   public onSelected(event: any) {
      this.selectedRecord = null;
      if (event.rows) {
         if (event.rows.length > 0) {
            this.selectedRecord = event.rows[0].data;
            const record = this.getTrimmedSelectedRecord(true, false);
            this.businessContextService.triggerContext(record);
            if (this.related) {
               this.related.record = record;
               this.relatedOptionService.setSelectedRecord(this.related);
            }
            this.selectionChanged.emit(record);
         } else {
            if (this.related) {
               this.related.record = null;
               this.relatedOptionService.setSelectedRecord(this.related);
            }
            this.selectionChanged.emit(null);
         }
      }
   }

   /**
    *    This method is called when the to date is changed
    */
   protected onToDateChanged(event: any) {
   }

   /**
    *    This method sets the selected record in preparation for the route
    *    navigation. It also clears the related option actions and drillbacks
    *    as we are about to navigate to another page.
    */
   protected preNavigateTo(args: any) {
      this.selectedRecord = null;
      if (args.length) {
         const arg = args[args.length - 1];
         this.selectedRecord = arg["item"];
      }
      this.isOptionsLoaded = false;
   }

   /**
    *    This method is responsible for the final route navigation. It also
    *    triggers the business context
    */
   protected postNavigateTo(record: MIRecord, navigateUrl?: string) {
      let nav: NavigationExtras = {
         relativeTo: this.route,
         skipLocationChange: true,
         queryParams: record
      }
      const url: string = navigateUrl ? navigateUrl : this.navigateTo;
      this.zone.run(() => {
         this.router.navigate([url], nav);
      });
      this.businessContextService.triggerContext(record);
   }

   /**
    *    This method calls the api method for data retrieval
    */
   protected searchData(record: MIRecord) {
      this.callApi(record, this.apiSearchProgram, this.apiSearchTransaction);
   }

   /**
    *    This method is called by the IntersectionObserver and is responsible
    *    for unloading of related options as well as resetting of variables
    */
   protected unloadDataAndOptions() {
      // Clear related actions, customActions and drillbacks
      if (this.related) {
         this.relatedOptionService.removeRelated(this.related);
      }
      this.isOptionsLoaded = false;
   }

}
