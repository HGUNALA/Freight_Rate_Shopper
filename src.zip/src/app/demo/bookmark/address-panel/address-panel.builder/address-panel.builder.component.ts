import { Component, Input, OnInit, QueryList, ViewChild, ViewChildren, ViewEncapsulation, ElementRef, Output, EventEmitter } from '@angular/core';
import { CoreBase, IFormControlInfo, IBookmark, IMIRequest } from '@infor-up/m3-odin';
import { DemoPagingService, IPagingResult } from '../../../services/paging.service/paging.service';
import { SohoLookupComponent, SohoDatePickerComponent } from 'ids-enterprise-ng';
import { MIUtil, MIRecord } from '@infor-up/m3-odin/dist/mi/runtime';
import { DemoBrowseService } from '../../../services/browse.service/browse.service';
import { DemoUserContextService } from '../../../services/usercontext.service/usercontext.service';
import { Subscription } from 'rxjs';

@Component({
   selector: 'demo-address-panel-builder',
   templateUrl: './address-panel.builder.component.html',
   styleUrls: ['./address-panel.builder.component.css'],
   encapsulation: ViewEncapsulation.None
})

export class DemoAddressPanelBuilderComponent extends CoreBase implements OnInit {
   @ViewChild('AddressPanelBuilder') panelBuilder: ElementRef;
   @ViewChildren(SohoLookupComponent) lookups: QueryList<SohoLookupComponent>
   @ViewChildren(SohoDatePickerComponent) datePickers: QueryList<SohoDatePickerComponent>
   @Input() bookmark: IBookmark;
   @Input() columns: number;
   @Input() formControls: IFormControlInfo[];
   @Input() searchField: string;
   @Output() visibleElementChanged: EventEmitter<any> = new EventEmitter();

   currentBrowseField: string;
   dateFormat: string;
   isBusy: boolean;
   rowCounter: number[];
   subscription: Subscription;
   visibleChildren: number = null;

   constructor(private demoBrowseService: DemoBrowseService,
      private demoPagingService: DemoPagingService,
      private userContextService: DemoUserContextService) {
      super('PanelBuilderComponent');
   }

   ngAfterViewInit(): void {
      try {
         this.lookups.forEach(lookup => {
            this.initGrid(lookup)
         });
         this.datePickers.forEach(datePicker => this.initDatePicker(datePicker));
      } catch (err) {
         this.logError(err);
      }
   }

   ngOnChanges(): void {
      setTimeout(() => {
         this.visibleChildren = $(this.panelBuilder.nativeElement).children(":visible").length;
         if (this.searchField && this.searchField.length > 0) {
            this.visibleElementChanged.emit(this.visibleChildren);
         }
      });
   }

   ngOnInit(): void {
      this.dateFormat = this.userContextService.userContext.dateFormat.substr(0, 2);
      this.dateFormat += "/";
      this.dateFormat = this.dateFormat + this.userContextService.userContext.dateFormat.substr(2, 2);
      this.dateFormat += "/";
      this.dateFormat = this.dateFormat + this.userContextService.userContext.dateFormat.substr(4, 2);
   }

   /**
    *    This method returns the columns that is to be used in the datagrid when
    *    browsing a lookup field
    */
   public getColumnFields(lookup: SohoLookupComponent, browseFields: any[], formControl: IFormControlInfo): SohoDataGridColumn[] {
      let columns: SohoDataGridColumn[] = [];
      for (let browseField of browseFields) {
         columns.push({
            width: 'auto',
            id: 'col-key',
            field: browseField.field,
            name: browseField["isAdditionalInfo"] ? browseField.displayName : formControl.label.value,
            resizable: false,
            filterType: 'text',
            sortable: false
         })
         if (browseField.isReturnValue) {
            lookup["lookup"].settings.field = browseField.field;
         }
      }
      return columns;
   }

   /**
    *    This method gets a string date and returns a Date object. It is used by
    *    the initDatePicker method which initializes the datepicker object
    */
   public getDate(val: string, dtfm: string): Date {
      let year: string;
      let month: string;
      let day: string;

      switch (dtfm.toLocaleLowerCase()) {
         case "yymmdd":
            year = val.substr(0, 2);
            month = val.substr(2, 2);
            day = val.substr(4, 2);
            break;
         case "mmddyy":
            month = val.substr(0, 2);
            day = val.substr(2, 2);
            year = val.substr(4, 2);
            break;
         case "ddmmyy":
            day = val.substr(0, 2);
            month = val.substr(2, 2);
            year = val.substr(4, 2);
            break;
      }

      // Return date
      return MIUtil.getDate("20" + year + month + day);
   }

   /**
    *    This method retrieves a specific formControl by name
    */
   private getFormControl(name: string): IFormControlInfo {
      try {
         for (let form of this.formControls) {
            if (form.control.name == name) {
               return form;
            }
         }
         return null;
      } catch (err) {
         this.logError(err);
      }
      return null;
   }

   /**
    *    This method initializes date picker fields
    */
   private initDatePicker(datePicker: SohoDatePickerComponent) {
      let bookmark: IBookmark = this["bookmark"];
      let id = datePicker["element"].nativeElement.id;
      let info: IFormControlInfo;

      // Find control
      for (let i = 0; i < this.formControls.length; i++) {
         const item = this.formControls[i];
         if (item) {
            if (item["control"].id === id) {
               info = item;
               break;
            }
         }
      }

      // Set date
      if (info) {
         const dtfm: string = info.control["dateFormat"];
         const val: string = info.control.value;
         // const readonly: boolean = info.control.readOnly;

         // Get date
         if (val) {
            let date: Date = this.getDate(val, dtfm);
            // datePicker.dateFormat = dtfm;
            datePicker.setValue(date);
         }
         // datePicker.readonly = readonly;
         datePicker.readonly = !info.control.isEnabled;
      }
   }

   /**
    *    This method initializes the browse datagrid for lookup fields
    */
   private initGrid(lookup: SohoLookupComponent) {
      let bookmark: IBookmark = this["bookmark"];
      let field = lookup.name;
      if (field) {
         let formControl = this.getFormControl(field);
         let browseFields = this.demoBrowseService.getBrowseFields(field);
         // Create columns
         let columns: SohoDataGridColumn[] = this.getColumnFields(lookup, browseFields, formControl);
         // Set datagrid options
         const options: SohoDataGridOptions = {
            alternateRowShading: false,
            cellNavigation: false,
            columns: columns,
            dataset: [],
            emptyMessage: {
               title: 'No records available',
               icon: 'icon-empty-no-data'
            },
            idProperty: 'col-key',
            indeterminate: true,
            paging: true,
            pagesize: 50,
            rowHeight: 'medium' as SohoDataGridRowHeight,
            selectable: 'single',
            showPageSizeSelector: false,
            toolbar: {
               actions: true,
               advancedFilter: false,
               dateFilter: false,
               keywordFilter: true,
               results: true,
               rowHeight: true,
               views: false,
            },
            source: (request: SohoDataGridSourceRequest, response: SohoDataGridResponseFunction) => {
               this.onBrowse(request, response, field);
            }
         }
         // Update lookup settings
         lookup["lookup"].settings.options = options;
      }
   }

   /**
    *    This method is called when browsing a lookup field
    */
   onBrowse(request: SohoDataGridSourceRequest, response: SohoDataGridResponseFunction, field: string) {
      /**
       *    Set current browse field so we can update additionalInfo later on
       */
      this.currentBrowseField = field;

      /**
       *    Check and set search variables
       */
      let isSearch: boolean;
      let searchFilter: string = null;
      if (request.type == "searched") {
         isSearch = true;
         searchFilter = request.filterExpr[0].value;
      }

      /**
       *    Check for for browsing data dependency. For example, to browse for lot
       *    number (BANO) you need to know which item (ITNO) it is for
       */
      let record: MIRecord;
      const dependencyFields: string[] = this.demoBrowseService.getBrowseDependencyFields(field);
      if (dependencyFields) {
         record = this.setDependencyRecord(dependencyFields);
         if (record) {
            this.logError("Browse dependency field not found. Exiting method");
            return;
         }
      }

      /**
       *    Browse
       */
      const miRequest: IMIRequest = this.demoBrowseService.getMIRequest(field, record, isSearch, searchFilter);

      let self = this;

      this.subscription = this.demoPagingService.getData(request, miRequest).subscribe(
         (result: IPagingResult) => {
            response(result.items, request);
            if (self.subscription) {
               self.subscription.unsubscribe();
            }
         });

   }

   /**
    *    This method is called when a date field has changed value
    */
   onDateChange(event: SohoDatePickerEvent) {
      let formControl = this.getFormControl(event.currentTarget["name"]);
      if (formControl) {
         const dateString = event.data;
         const date = new Date(dateString);
         formControl.control.value = this.setDate(date);
      }
   }

   /**
    *    This method is called when a lookup field has changed value. It updates the
    *    corresponding form control value
    */
   onChange(event?: SohoLookupChangeEvent[]) {
      for (let formControl of this.formControls) {
         if (formControl.control.name == this.currentBrowseField) {
            let ctrl: string;
            let ai: string;
            const columns = this.demoBrowseService.getBrowseFields(this.currentBrowseField);
            for (let column of columns) {
               // Find additionalInfo
               if (formControl["additionalInfo"]) {
                  if (column["isAdditionalInfo"]) {
                     ai = event[0].data[column.field];
                     formControl.additionalInfo.value = ai;
                  }
                  // Find returnValue
                  if (column["isReturnValue"]) {
                     ctrl = event[0].data[column.field];
                     formControl.control.value = ctrl;
                  }
               }
            }
            break;
         }
      }
   }

   /**
    *    This method is called by the onDateChange method
    */
   setDate(date: Date): string {
      let dateString: string;
      let day: string = date.getDate() < 10 ? ("0" + date.getDate()).toString() : date.getDate().toString();
      let month: string = (date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)).toString() : (date.getMonth() + 1).toString();
      let year: string = (date.getFullYear() - 2000).toString();
      switch (this.userContextService.userContext.DTFM) {
         case "YMD":
            dateString = year + month + day;
            break;
         case "DMY":
            dateString = day + month + year;
            break;
         case "MDY":
            dateString = month + day + year;
            break;
      }
      return dateString;
   }

   /**
    *    This method method returns an MIRecord containing browse data dependency
    *    fields. Said fields are retrieved from the FormControl array
    */
   public setDependencyRecord(dependencyFields: string[]): MIRecord {
      let record: MIRecord = new MIRecord();
      const bookmarkFieldNames: string[] = this.bookmark.fieldNames.split(",");
      for (let df of dependencyFields) {
         for (let bfn of bookmarkFieldNames) {
            if (bfn.indexOf(df) > - 1) {
               record[df] = this.getFormControl(bfn).control.value;
            }
         }
      }
      return record;
   }

}
