import { Component, Input, DoCheck, SimpleChange, ViewChild, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CoreBase, IBookmark, IFormControlInfo, IFormResponse, ArrayUtil, IFormRequest, Log } from '@infor-up/m3-odin';
import { FormService } from '@infor-up/m3-odin-angular';
import { SohoMessageService, SohoMessageRef } from 'ids-enterprise-ng';
import { DemoBrowseService } from '../../../services/browse.service/browse.service';
import { DemoPanelBuilderComponent } from '../panel.builder/panel.builder.component';
import { DemoUserContextService } from '../../../services/usercontext.service/usercontext.service';
import { DemoLaunchService } from '../../../services/launch.service/launch.service';
import { DemoUtilService } from 'src/app/demo/services/util.service/util.service';
import { IXmlCustomization, IPersonalization, DemoPersonalizationService } from 'src/app/demo/services/personalization.service/personalization.service';

@Component({
   templateUrl: './panel.component.html',
   selector: 'demo-panel',
   styleUrls: ['./panel.component.css'],
   encapsulation: ViewEncapsulation.None
})

export class DemoPanelComponent extends CoreBase implements DoCheck {
   @Input() header: string;
   @Input() bookmark: IBookmark;
   @Input() editableFields: string[];
   @Input() isEditable: boolean;
   @Input() isDrillEnabled: boolean;
   @Input() isUsedInDialog: boolean;
   @Input() isSort: boolean;
   @Input() searchField: string;
   @Output() bookmarkLoaded: EventEmitter<any> = new EventEmitter();
   @Output() updateCompleteEmitter: EventEmitter<IDetailPanelMessage> = new EventEmitter();

   @ViewChild('PanelBuilder') panelBuilder: DemoPanelBuilderComponent;

   private canExecute = true;
   private personalization: IPersonalization;
   private originalControlInfos: IFormControlInfo[];
   private commandCounter: number;
   private currentMsgid: string;
   controlInfos: IFormControlInfo[];

   isBusy: boolean = false;
   isDirty: boolean = false;
   isHideHeader: boolean = false;

   // Error dialog variables
   dialog: SohoMessageRef;

   constructor(private formService: FormService,
      private userContextService: DemoUserContextService,
      private messageService: SohoMessageService,
      private demoBrowseService: DemoBrowseService,
      private personalizationService: DemoPersonalizationService,
      private launchService: DemoLaunchService,
      private utilService: DemoUtilService) {
      super('PanelComponent');
   }

   /**
    *    This method is responsible for dirty checking
    */
   ngDoCheck(): void {
      if (JSON.stringify(this.controlInfos) != JSON.stringify(this.originalControlInfos)) {
         this.isDirty = true;
      } else {
         this.isDirty = false;
      }
   }

   ngOnChanges(changes: { [propName: string]: SimpleChange }) {
      if (changes.bookmark) {
         if (this.bookmark) {
            this.openBookmark();
         }
      }
   }

   /**
    *    This method clears the controlInfo variables
    */
   clearControl() {
      this.originalControlInfos = null;
      this.controlInfos = null;
   }

   indexOfControlName(tmpInfos: IFormControlInfo[], name: string): number {
      for (let i = 0; i < tmpInfos.length; i++) {
         if (tmpInfos[i].control.name == name) {
            return i;
         }
      }
      return -1;
   }

   isEnabled(): boolean {
      return this.canExecute;
   }

   /**
    *    This method is called when you want to cancel the bookmark processing
    */
   public cancelUpdate(response: IFormResponse, bookmark: IBookmark) {
      let sid = response.sessionId;
      let iid = response.instanceId;

      let request: IFormRequest = {
         commandType: "KEY",
         commandValue: "F3",
         params: {
            SID: sid,
            IID: iid,
         },
         sessionId: sid,
      }

      this.formService.executeRequest(request).subscribe((response) => {
         if (response.panel) {
            this.processPanelResponse(response, bookmark);
         }
      });
   }

   /**
    *    This method is called by the updatePressNext to retrieve the current values
    *    from the detail panel
    */
   private getCurrentPanelFields(response: IFormResponse, bookmark: IBookmark): string[] {
      try {
         let fieldsToUpdate: string[] = [];
         if (response.panel) {
            for (let field of bookmark.fieldNames.split(',')) {
               let panelField = response.panel.controls[field];
               if (panelField) {
                  fieldsToUpdate.push(field);
               }
            }
         }
         return fieldsToUpdate;
      } catch (err) {
         this.logError(err);
         return [];
      }
   }

   /**
    *    This method is called by the onSave. It gets the infoControl field values
    */
   private getFieldValues(bookmark: IBookmark): string {
      let fieldValues: string[] = [];
      for (let fieldName of this.bookmark.fieldNames.split(",")) {
         for (let info of this.controlInfos) {
            if (info.control.name == fieldName) {
               fieldValues.push(info.control.value);
               break;
            }
         }
      }
      return fieldValues.join("|");
   }

   private getPersonalization(response: IFormResponse) {
      try {

         // Get customization from document
         let xmlCustomization: IXmlCustomization = ({
            xmlConditionalStyles: [],
            xmlHyperLinks: [],
            xmlReplacementTexts: []
         });

         let custElements: any[] = [].slice.call(response.document.getElementsByTagName("Cust"));
         if (custElements.length > 0) {

            for (let custElement of custElements) {
               if (custElement.hasChildNodes()) {
                  for (let custString of custElement.childNodes) {
                     let custXml = (new DOMParser()).parseFromString(custString.data, "text/xml");
                     xmlCustomization.xmlConditionalStyles = [].slice.call(custXml.getElementsByTagName("ConditionalStyle"));
                     xmlCustomization.xmlHyperLinks = [].slice.call(custXml.getElementsByTagName("HyperLink"));
                     xmlCustomization.xmlReplacementTexts = [].slice.call(custXml.getElementsByTagName("ReplacementText"));
                  }
               }
            }
         }

         // Parse customization
         this.personalization = this.personalizationService.parseCustomization(this.bookmark.program, xmlCustomization);

      } catch (err) {
         this.logError(err);
      }
   }

   /**
    *    This method is used to make a drillback to M3 using the detail panel
    *    bookmark
    */
   onDrillClick() {
      let bookmark = JSON.parse(JSON.stringify(this.bookmark))
      bookmark.fieldNames = null;
      const keys = bookmark.keyNames.split(',');
      const values = bookmark.values;
      bookmark.option = "2";
      bookmark.includeStartPanel = false;
      bookmark.requirePanel = false;
      bookmark.panelSequence = bookmark.panelSequence ? bookmark.panelSequence : bookmark.panel;
      this.launchService.launchBookmark(bookmark);
   }

   /**
    *    An error handling method for the bookmark
    */
   private onError(response: IFormResponse): void {
      const message = response.message || 'Unable to open bookmark';
      const buttons = [{ text: 'OK', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('Bookmark error')
         .message(message)
         .buttons(buttons)
         .open()
         .beforeClose(() => {
            this.updateCompleteEmitter.emit({
               type: PanelResult.Exit,
               message: "High level M3 BE error message. Bookmark processing cancelled"
            });
            return true;
         });

      this.canExecute = true;
   }

   /**
    *    This method is called after succefully executing the bookmark. It takes
    *    the returned panel(s) and stores the included panel fields in an
    *    IFormControlInfo array
    */
   private onResponse(response: IFormResponse): void {
      if (response.result !== 0) {
         this.onError(response);
         return;
      }

      // Get personalization
      this.getPersonalization(response);

      // Clear arrays
      this.controlInfos = this.originalControlInfos = [];

      let tempInfos: IFormControlInfo[] = [];

      const panels = response.panels;
      for (let panel of panels) {
         if (panel) {
            tempInfos = tempInfos.concat(panel.getControlInfos(this.bookmark.fieldNames.split(',')));
         }
      }

      /**
       *    Readonly - use isEnabled from the form control object
       */
      for (let info of tempInfos) {

         /**
          *    Check personalizations
          */
         if (this.personalization) {
            // Get conditional style and replacement texts
            let keyName: string = info.control.name;
            const cssClass = this.personalizationService.getConditionalStyle(this.personalization, keyName, info.control.value);
            const replacementText = this.personalizationService.getReplacementText(this.personalization, keyName, info.control.value);
            if (cssClass) {
               info.control["cssClass"] = cssClass;
            }
            if (replacementText) {
               info.control.value = replacementText;
            }
         }

         /**
          *    Option 5 - display mode. All fields should be readonly
          */
         if (this.bookmark.option == "5") {
            info.control.isEnabled = false;
            continue;
         }

         /**
          *    Option 2 - edit mode
          */
         if (this.bookmark.option == "2") {

            /**
             *    If option 2 is used in the bookmark and
             *
             *    1. The component is editable, or
             *    2. The utilService.isEditEnabled() method returns true
             *
             *    then exit the for-loop, meaning the controls will use their
             *    default value from the panel
             */
            if (this.isEditable || this.utilService.isEditEnabled()) {
               break;
            }

            /**
             *    if editable fields have been provided, set non-applicable fields to readonly
             */
            if (!ArrayUtil.contains(this.editableFields, info.control.name)) {
               info.control.isEnabled = false;
            }
         }

      }

      // Sort alphabetically by label...
      if (this.isSort) {
         tempInfos.sort((a, b) => {
            try {
               if (a.label.value < b.label.value) {
                  return -1;
               } else if (a.label.value > b.label.value) {
                  return 1;
               } else {
                  return 0;
               }
            } catch (err) {
               return 0;
            }
         });
         this.controlInfos = tempInfos;
      } else {
         // ...else sort by bookmark fieldName
         for (let name of this.bookmark.fieldNames.split(',')) {
            const index = this.indexOfControlName(tempInfos, name);
            if (index > -1) {
               this.controlInfos.push(tempInfos[index]);
            }
         }
      }

      this.originalControlInfos = JSON.parse(JSON.stringify(this.controlInfos));
      this.canExecute = true;
   }

   /**
    *    This method is called when you have change a value on the panel and
    *    you want to update the value to M3.
    */
   onSave() {
      if (true) {
         this.commandCounter = 0;
         this.currentMsgid = "";
         let bookmark = JSON.parse(JSON.stringify(this.bookmark))
         bookmark.fields = this.getFieldValues(bookmark);
         this.updateViaBookmark(bookmark);
      }
   }

   onVisibleElementChanged(count: number) {
      // this.isHideHeader = count ? false : true;
      if (count) {
         this.isHideHeader = false;
      } else {
         this.isHideHeader = true;
      }
   }

   /**
    *    This method executes the detail panel bookmark
    */
   private openBookmark(): void {
      this.clearControl();

      // Check if edit mode has manually been enabled in the mashup
      if (this.utilService.isEditEnabled()) {
         this.bookmark.option = "2";
      } else if (this.isEditable) {
         // Check if isEditable property has been set on the component in the HTML
         this.bookmark.option = "2";
      } else if (this.editableFields && this.editableFields.length > 0) {
         // Check if editableFields property has been set on the component in the HTML
         this.bookmark.option = "2";
      } else {
         // Open bookmark as readonly
         this.bookmark.option = "5";
      }

      this.formService.executeBookmark(this.bookmark).subscribe((r) => {
         this.onResponse(r);
         this.bookmarkLoaded.emit();
      }, (r) => {
         this.onError(r);
      });
   }

   /**
    *    This method is called by the updateViaBookmark method. It handles the
    *    panel response.
    *
    *    1. It shows warning messages, if any.
    *    2. It shows dialog messages, if any.
    *    3. It calls the updatePressNext method.
    *
    */
   private processPanelResponse(response: IFormResponse, bookmark: IBookmark) {

      /**
       *
       * Below we are handling the possible responses from M3
       *
       * 1. M3 error/warning message. Show message in dialog.
       * 2. M3 dialog. Show dialog message with action buttons.
       * 3. All went well. Press enter again
       *
       */

      try {

         this.commandCounter++;

         /**
          *    In case we have missed to handle a scenario, to avoid infinite loops, cancel
          *    update after 10 iterations
          */
         if (this.commandCounter > 10) {
            Log.error("Too many iterations. Closing bookmark program");
            this.cancelUpdate(response, bookmark);
            this.updateCompleteEmitter.emit({
               type: PanelResult.Exit,
               message: "A loop occurred. Please contact your developer. Bookmark processing cancelled"
            });
            return;
         }

         /**
          *    If other programs are being called (i.e. ATS101), cancel update (i.e press F3)
          */
         if (!response.isDialog) {
            if (response.panel.header.indexOf(bookmark.program) == -1) {
               // Special handling for program PPS170, which opens program PPS171 in detail mode
               if (bookmark.program != "PPS170") {
                  this.cancelUpdate(response, bookmark);
                  this.updateCompleteEmitter.emit({
                     type: PanelResult.Exit,
                     message: "Another program was called. This is not supported by the component. Bookmark processing cancelled"
                  });
                  return;
               }
            }
         }

         /**
          *
          * Error / Warning messages
          *
          * */

         if (response.messageId) {

            this.isBusy = false;

            let msg: string = response.message;
            let msgid: string = response.messageId;

            /**
             *    If msgid equals currentMsgid it means that the same message is being
             *    displayed again. Cancel processing and wait for user to provide more
             *    input to the panel
             */
            if (msgid == this.currentMsgid) {
               this.cancelUpdate(response, bookmark);
               this.updateCompleteEmitter.emit({
                  type: PanelResult.Input,
                  message: "Input required on the panel"
               });
               return;
            }

            // Set current message id
            this.currentMsgid = msgid;

            /**
             *    Show error message and cancel
             */
            if (response.messageLevel > "10" || this.utilService.isErrorMessage(msgid)) {
               const buttons = [
                  {
                     text: 'OK',
                     click: (e, modal) => {
                        modal.close(true);
                        this.dialog = null;
                        this.cancelUpdate(response, bookmark);
                        this.updateCompleteEmitter.emit({
                           type: PanelResult.Exit,
                           message: "High level M3 BE error message. Bookmark processing cancelled"
                        });
                     },
                     isDefault: true
                  }
               ];
               // Show error / warning message
               let options: SohoMessageOptions = {
                  title: "Error",
                  message: msg,
                  buttons: buttons
               }
               this.messageService.message(options).open();

            } else {

               /**
                *    Show warning message and process response
                */

               const buttons = [
                  {
                     text: 'OK',
                     click: (e, modal) => {
                        this.isBusy = true;
                        modal.close(true);
                        this.dialog = null;
                        this.updatePressNext(response, bookmark);
                     },
                     isDefault: false
                  },
                  {
                     text: 'Cancel',
                     click: (e, modal) => {
                        this.isBusy = true;
                        modal.close(true);
                        this.dialog = null;
                        this.cancelUpdate(response, bookmark);
                        this.updateCompleteEmitter.emit({
                           type: PanelResult.Exit,
                           message: "Low level M3 BE error message, bookmark processing cancelled by the user"
                        });
                     },
                     isDefault: false
                  }
               ];
               let options: SohoMessageOptions = {
                  title: "Warning",
                  message: msg,
                  buttons: buttons
               }
               this.messageService.message(options).open();
            }

            /**
             *
             * Dialog
             *
             * */

         } else if (response.isDialog) {

            this.isBusy = false;

            let dialogMessage: string;

            if (response.dialogType == "1") {

               // Parse dialog message
               try {
                  let panel: HTMLCollectionOf<Element> = response.document.getElementsByTagName("Panel");
                  if (panel.length > 0) {

                     // Dialog message
                     let caption: HTMLCollectionOf<Element> = panel[0].getElementsByTagName("Cap");
                     if (caption.length > 0) {
                        dialogMessage = caption[0].textContent;
                     } else {
                        dialogMessage = "Unable to parse dialog message, please contact your developer to investigate";
                     }

                     // Buttons
                     let buttons: any[] = [];

                     // OK
                     if (response.panel.controls.dbtnok) {
                        buttons.push({
                           text: 'Ok',
                           click: (e, modal) => {
                              this.isBusy = true;
                              modal.close(true);
                              this.dialog = null;
                              this.updatePressNext(response, bookmark);
                           },
                           isDefault: false
                        });
                     }

                     // Yes
                     if (response.panel.controls.dbtnyes) {
                        buttons.push({
                           text: 'Yes',
                           click: (e, modal) => {
                              this.isBusy = true;
                              modal.close(true);
                              this.dialog = null;
                              this.updateFromDialog(response, bookmark, "KEY", "1");
                           },
                           isDefault: false
                        },
                        );
                     }

                     // No
                     if (response.panel.controls.dbtnno) {
                        buttons.push({
                           text: 'No',
                           click: (e, modal) => {
                              this.isBusy = true;
                              modal.close(true);
                              this.dialog = null;
                              this.updateFromDialog(response, bookmark, "KEY", "0");
                           },
                           isDefault: false
                        });
                     }

                     // Cancel
                     if (response.panel.controls.dbtncnl) {
                        buttons.push({
                           text: 'Cancel',
                           click: (e, modal) => {
                              this.isBusy = true;
                              modal.close(true);
                              this.dialog = null;
                              this.cancelUpdate(response, bookmark);
                              this.updateCompleteEmitter.emit({
                                 type: PanelResult.Exit,
                                 message: "Dialog message, bookmark processing cancelled by the user"
                              });
                           },
                           isDefault: false
                        });
                     }

                     // Show dialog message
                     let options: SohoMessageOptions = {
                        title: "M3",
                        message: dialogMessage,
                        buttons: buttons
                     }
                     this.messageService.message(options).open();

                  }
               } catch (ignore) { }

            } else {
               const msg = "Dialog not supported. Please implement functionality for dialog type " + response["dialogType"];
               Log.error(msg);
               this.cancelUpdate(response, bookmark);
               this.updateCompleteEmitter.emit({
                  type: PanelResult.Exit,
                  message: msg
               });
            }

            /**
             *
             * All else
             *
             * */

         } else {
            this.updatePressNext(response, bookmark);
         }

      } catch (err) {
         this.logError(err);
      }

   }

   /**
    *    This method handles responses from dialogs. It is called by the processPanelResponse
    *    method.
    */
   private updateFromDialog(response: IFormResponse, bookmark: IBookmark, cType?: string, cValue?: string) {
      let sid = response.sessionId;
      let iid = response.instanceId;

      let request: IFormRequest = {
         commandType: cType ? cType : "KEY",
         commandValue: cValue ? cValue : "ENTER",
         params: {
            SID: sid,
            IID: iid,
         },
         sessionId: sid,
      }

      this.formService.executeRequest(request).subscribe((response) => {
         if (response.panel) {
            this.processPanelResponse(response, bookmark);
         } else {
            this.updateCompleteEmitter.emit({
               type: PanelResult.Finished,
               message: "Bookmark processing finished successfully"
            });
            this.originalControlInfos = JSON.parse(JSON.stringify(this.controlInfos));
            this.isDirty = false;
            this.isBusy = false;
         }
      });

   }

   /**
    *    This method is responsible for setting the form panel with the corresponding
    *    values from the detail panel component. After doing so, it "presses Enter" on
    *    the bookmark panel.
    *    If there is another panel in the panel sequence the processPanelResponse method
    *    is called, otherwise the originalControlInfos array is updated, and the isDirty
    *    variable is reset.
    */
   private updatePressNext(response: IFormResponse, bookmark: IBookmark, cType?: string, cValue?: string) {
      let sid = response.sessionId;
      let iid = response.instanceId;

      let request: IFormRequest = {
         commandType: cType ? cType : "KEY",
         commandValue: cValue ? cValue : "ENTER",
         params: {
            SID: sid,
            IID: iid,
         },
         sessionId: sid,
      }

      let fieldsToUpdate: string[] = this.getCurrentPanelFields(response, bookmark);
      let fields: string[] = bookmark.fields.split('|');
      let fieldNames: string[] = bookmark.fieldNames.split(',');

      for (let field of fieldsToUpdate) {
         let index: number = fieldNames.indexOf(field);
         request.params[field] = fields[index];
      }

      this.formService.executeRequest(request).subscribe((response) => {
         if (response.panel) {
            this.processPanelResponse(response, bookmark);
         } else {
            this.updateCompleteEmitter.emit({
               type: PanelResult.Finished,
               message: "Bookmark processing finished successfully"
            });
            this.originalControlInfos = JSON.parse(JSON.stringify(this.controlInfos));
            this.isDirty = false;
            this.isBusy = false;
         }
      });

   }

   /**
    *    This method is called by the onSave method. It starts the bookmark update
    *    sequence. It works as follows
    *
    *    1. The bookmark is executed with option 2.
    *    2. The returned program (and panel is) is processed by programatically
    *       pressing Enter through the bookmark panel sequence, updating the panel
    *       form fields with the changed values.
    */
   private updateViaBookmark(bookmark: IBookmark) {
      this.isBusy = true;
      const keys = bookmark.keyNames.split(',');
      const values = bookmark.values;

      /**
       *
       * Need good validation of bookmark and fields. Must:
       * 1. Be able to handle typos
       * 2. Duplicate fields
       * 3.
       *
       */

      bookmark.option = "2";
      bookmark.includeStartPanel = false;
      bookmark.requirePanel = false;
      bookmark.panelSequence = bookmark.panelSequence ? bookmark.panelSequence : bookmark.panel;

      let keyFields = "";
      for (let key of keys) {
         keyFields += key;
         keyFields += ",";
         if (key.indexOf("CONO") > -1) {
            keyFields += this.userContextService.userContext.currentCompany;
         } else {
            keyFields += values[key];
         }
         keyFields += ",";
      }

      let startPanelFields = "";
      if (bookmark["startPanelFieldNames"]) {
         const spfNames = bookmark["startPanelFieldNames"].split(',');
         const spfValues = bookmark["startPanelFieldValues"].split(',');
         for (let j in spfNames) {
            startPanelFields += spfNames[j];
            startPanelFields += ",";
            startPanelFields += spfValues[j];
            startPanelFields += ",";
         }
      }

      let request: IFormRequest = {
         commandType: "RUN",
         commandValue: "BOOKMARK",
         params: {
            BM_PROGRAM: bookmark.program,
            BM_TABLE_NAME: bookmark.table,
            BM_OPTION: bookmark.option,
            BM_KEY_FIELDS: keyFields,
            BM_SOURCE: "H5",
            BM_REQUIRE_PANEL: bookmark.requirePanel.toString(),
            BM_INCLUDE_START_PANEL: bookmark.includeStartPanel.toString(),
            BM_PANEL: bookmark.panel,
            BM_PANEL_SEQUENCE: bookmark.panelSequence,
            // BM_START_PANEL: bookmark.startPanel,
            // BM_START_PANEL_FIELDS: startPanelFields
         },
      }

      this.formService.executeRequest(request).subscribe((response) => {
         if (response.panel) {
            this.processPanelResponse(response, bookmark);
         }
      });
   }

}

export interface IDetailPanelMessage {
   type: number,
   message: string
}

export enum PanelResult {
   Cancel,
   Exit,
   Finished,
   Input
}
