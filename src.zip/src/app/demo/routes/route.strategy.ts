import { Router, RouteReuseStrategy, DetachedRouteHandle, ActivatedRouteSnapshot } from '@angular/router';

export class DemoRouteReuseStrategy implements RouteReuseStrategy {

   handlers: { [key: string]: DetachedRouteHandle } = {};

   retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle {
      if (!route.routeConfig) return null;
      return this.handlers[route.routeConfig.path];
   }

   shouldAttach(route: ActivatedRouteSnapshot): boolean {
      return !!route.routeConfig && !!this.handlers[route.routeConfig.path];
   }

   shouldDetach(route: ActivatedRouteSnapshot): boolean {
      if (route.component["isDetach"] != undefined && route.component["isDetach"] != null) {
         return route.component["isDetach"];
      } else {
         return true;
      }
   }

   shouldReuseRoute(future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot): boolean {
      return future.routeConfig === curr.routeConfig;
   }

   store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
      this.handlers[route.routeConfig.path] = handle;
   }

}
