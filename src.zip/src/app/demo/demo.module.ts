import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouteReuseStrategy } from '@angular/router';
import { M3OdinModule } from '@infor-up/m3-odin-angular';
import { SohoComponentsModule } from 'ids-enterprise-ng';

// import ngx-translate and the http loader
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { DemoBrowseService } from '../demo/services/browse.service/browse.service';
import { DemoBusinessContextService } from '../demo/services/businesscontext.service/businesscontext.service';
import { DemoInitService } from '../demo/services/initialize.service/initialize.service';
import { DemoLaunchService } from '../demo/services/launch.service/launch.service';
import { DemoPagingService } from '../demo/services/paging.service/paging.service';
import { DemoPersonalizationService } from '../demo/services/personalization.service/personalization.service';
import { DemoRelatedOptionService } from '../demo/services/relatedoption.service/relatedoption.service';
import { DemoRoutingStateService } from '../demo/services/routingstate.service/routingstate.service';
import { DemoUserContextService } from '../demo/services/usercontext.service/usercontext.service';

import { DemoMiDropdownComponent } from '../demo/mi/mi.dropdown/mi.dropdown.component';
import { DemoMiLookupComponent } from '../demo/mi/mi.lookup/mi.lookup.component';
import { DemoAddressPanelBuilderComponent } from './bookmark/address-panel/address-panel.builder/address-panel.builder.component';
import { DemoPanelBuilderComponent } from '../demo/bookmark/panel/panel.builder/panel.builder.component';
import { DemoPanelComponent } from '../demo/bookmark/panel/panel/panel.component';
import { DemoRouteReuseStrategy } from '../demo/routes/route.strategy';
import { DemoRelatedOptionComponent } from './related-option/related-option/related-option.component';
import { DemoRelatedOptionDialogComponent } from './related-option/related-option-dialog/related-option-dialog.component';
import { DemoAddressPanelComponent } from './bookmark/address-panel/address-panel/address-panel.component';

@NgModule({
   declarations: [
      DemoMiDropdownComponent,
      DemoMiLookupComponent,
      DemoAddressPanelBuilderComponent,
      DemoAddressPanelComponent,
      DemoPanelBuilderComponent,
      DemoPanelComponent,
      DemoRelatedOptionComponent,
      DemoRelatedOptionDialogComponent
   ],
   exports: [
      DemoMiDropdownComponent,
      DemoMiLookupComponent,
      DemoAddressPanelBuilderComponent,
      DemoAddressPanelComponent,
      DemoPanelBuilderComponent,
      DemoPanelComponent,
      DemoRelatedOptionComponent,
      DemoRelatedOptionDialogComponent,
      HttpClientModule,
      TranslateModule
   ],
   imports: [
      CommonModule,
      FormsModule,
      M3OdinModule,
      SohoComponentsModule,
      // ngx-translate and the loader module
      HttpClientModule,
      TranslateModule.forRoot({
         loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
         }
      })

   ],
   providers: [
      DemoBrowseService,
      DemoBusinessContextService,
      DemoInitService,
      DemoLaunchService,
      DemoPagingService,
      DemoPersonalizationService,
      DemoRelatedOptionService,
      DemoRoutingStateService,
      DemoUserContextService,
      { provide: RouteReuseStrategy, useClass: DemoRouteReuseStrategy }
   ],
   entryComponents: [
      DemoRelatedOptionDialogComponent
   ]

})
export class DemoModule { }

// Required for AOT compilation
export function HttpLoaderFactory(http: HttpClient) {
   return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
}
