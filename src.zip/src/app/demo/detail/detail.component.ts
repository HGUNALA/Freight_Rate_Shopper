import { ElementRef, Input, SimpleChange } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { CoreBase, MIRecord } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { SohoMessageService } from 'ids-enterprise-ng';
import { IDrillBack, IAction, IRelated, ICustomAction } from 'src/app/demo/related-option/related-option/related-option.component';
import { DemoRelatedOptionService } from '../services/relatedoption.service/relatedoption.service';
import { DemoBusinessContextService } from '../services/businesscontext.service/businesscontext.service';
import { TranslateService } from '@ngx-translate/core';
import { DemoRoutingStateService } from '../services/routingstate.service/routingstate.service';

export abstract class DemoDetailComponent extends CoreBase {

   @Input() header: string;
   @Input() searchField: string;
   @Input() selectedRecord: MIRecord;

   private intersectionObserver: IntersectionObserver;

   isBusy: boolean;
   isReady: boolean;
   isDataLoaded: boolean;
   isOptionsLoaded: boolean;

   actions: IAction[] = [];
   customActions: ICustomAction[] = [];
   drillBacks: IDrillBack[] = [];
   related: IRelated;

   constructor(
      protected activatedRoute: ActivatedRoute,
      protected elementRef: ElementRef,
      protected miService: MIService,
      protected location: Location,
      protected messageService: SohoMessageService,
      protected router: Router,
      protected translate: TranslateService,
      protected businessContextService: DemoBusinessContextService,
      protected relatedOptionService: DemoRelatedOptionService,
      protected routingStateService: DemoRoutingStateService) {
      super('DemoDetailComponent');
   }

   /**
    *    Unsubscribe observables and event emitters here
    */
   ngOnDestroy() {
      this.intersectionObserver.unobserve(<Element>(this.elementRef.nativeElement));
   }

   /**
    *    This method loads the bookmark once the selectedRecord has been set
    */
   ngOnChanges(changes: { [propName: string]: SimpleChange }) {
      if (changes.selectedRecord) {
         if (this.selectedRecord) {
            const record = this.getTrimmedSelectedRecord();
            this.initBookmark(record);
         }
      }
   }

   /**
    *    This method is responsible for initializing Soho components
    */
   ngAfterViewInit() {

      if (this.actions.length > 0 || this.customActions.length > 0 || this.drillBacks.length > 0) {

         // Create related object containing actions, customActions and drillbacks
         this.related = {
            actions: this.actions,
            customActions: this.customActions,
            drillBacks: this.drillBacks,
            name: this.header,
            record: this.selectedRecord
         }

      }

      // Add IntersectionObserver
      this.intersectionObserver = new IntersectionObserver(elements => {
         for (let element of elements) {
            if (element.target == this.elementRef.nativeElement) {
               if (element.isIntersecting) {
                  this.loadDataAndOptions();
               } else {
                  this.unloadDataAndOptions();
               }
            }
         }
      }, {});
      this.intersectionObserver.observe(<Element>(this.elementRef.nativeElement));

      // Custom Actions
      this.relatedOptionService.customActionClickedEvent.subscribe((customAction: ICustomAction) => {
         this.onCustomAction(customAction);
      });
   }

   /**
    *    A method that clears class variables
    */
   protected clear() {
   }

   /**
    *    A method that returns the selected MIRecord with out field prefixes
    */
   protected getTrimmedSelectedRecord(): MIRecord {
      let fields: string[];
      let record: MIRecord = new MIRecord();

      if (this.selectedRecord) {
         fields = Object.keys(this.selectedRecord);
         for (let field of fields) {
            if (field.length == 6) {
               const shortField = field.substring(2);
               record[shortField] = this.selectedRecord[field];
            } else {
               record[field] = this.selectedRecord[field];
            }
         }
      }

      return record;
   }

   /**
    *    This method must be defined in the child class. It defines the
    *    bookmark, or bookmarks, that should be displayed by the detail
    *    component
    */
   protected abstract initBookmark(record: MIRecord): void;

   /**
    *    This method is called by the IntersectionObserver and is responsible
    *    for lazy loading of data and related options
    */
   protected loadDataAndOptions() {
      if (!this.isOptionsLoaded) {
         /**
          *    Load related object, containing actions, customActions and drillbacks.
          *    Wait for other components to clear their options
          */

         setTimeout(() => {
            if (this.related) {
               this.relatedOptionService.setRelated(this.related);
            }
            this.isOptionsLoaded = true;
         }, 250);
      }
   }

   /**
    *    This method when a custom action is clicked. It is called by the
    *    customActionClickedEvent in the ngAfterViewInit method.
    *
    *    Custom actions are used when you cannot use regular actions. Therefore
    *    the M3 demo list component is responsible for implementing the
    *    functionality that should take place when the custom action is clicked.
    *
    *    The custom action functionality should be defined in the child class. A
    *    check should be made of the custom action id so that the correct M3 demo list
    *    component is handling the custom action
    *
    *    Example:
    *    if (customAction == "releasePopLine") {
    *       ...
    *    }
    *
    */
   protected onCustomAction(customAction: ICustomAction) { }

   /**
    *    This method shows and hides the busy indicator
    */
   public showBusyindicator(value: boolean) {
      this.isBusy = value;
   }

   /**
    *    This method is called by the IntersectionObserver and is responsible
    *    for unloading of related options as well as resetting of variables
    */
   protected unloadDataAndOptions() {
      // Clear related actions, customActions and drillbacks
      if (this.related) {
         this.relatedOptionService.removeRelated(this.related);
      }
      this.isOptionsLoaded = false;
   }

}
