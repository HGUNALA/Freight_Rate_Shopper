import { ElementRef, NgZone } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { CoreBase, MIRecord } from '@infor-up/m3-odin';
import { Subscription } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { DemoRoutingStateService } from '../services/routingstate.service/routingstate.service';

/**
 *
 *
 */

export class DemoNavigationComponent extends CoreBase {

   qryParamsSubscription: Subscription;
   selectedRecord: MIRecord;
   searchField: string;

   constructor(
      protected activatedRoute: ActivatedRoute,
      protected router: Router,
      protected routingStateService: DemoRoutingStateService,
      protected translate: TranslateService,
      protected zone: NgZone) {
      super('DemoNavigationComponent');
   }

   ngOnInit(): void {
   }

   /**
    * Unsubscribe observables and event emitters here
    */
   ngOnDestroy() {
      this.qryParamsSubscription.unsubscribe();
   }

   /**
    * Subscribe to queryparams here
    */
   protected init() {
      this.qryParamsSubscription = this.activatedRoute.queryParams.subscribe((param: any) => {
         this.onRouteNavigation(param);
      });
   }

   /**
    *    This method is called when navigating away from the detail panel
    */
   public onNavigateBackClick() {
      // Navigate back
      const navigateBackTo: string = this.routingStateService.getPreviousUrl();
      let nav: NavigationExtras = {
         relativeTo: this.activatedRoute
      }
      this.router.navigate([navigateBackTo], nav);
   }

   /**
    *    This method is called by the route params observable in the
    *    ngOnInit lifecycle method
    */
   protected onRouteNavigation(param: any) {
      if (Object.keys(param).length !== 0) {
         /**
          *    If TMTS is included we should refresh the component data...
          */
         if (param["TMTS"]) {
            // if (this.apiInputRecord) {
            //    this.onApply();
            // }
         } else {
            /**
             *    ...else we should set the record
             */
            this.selectedRecord = param;
         }
      }
   }

}
