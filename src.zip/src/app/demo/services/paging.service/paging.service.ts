import { Injectable, OnDestroy } from '@angular/core';
import { ArrayUtil, CoreBase, IMIRequest, IMIResponse, Log } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';

export interface IPagingResult {
   items: any[];
   request?: SohoDataGridSourceRequest;
}

export interface IBrowseItem {
   items: { [index: number]: any[] };
   lastRecord: string;
   endOfRecords: boolean;
}

@Injectable()
export class DemoPagingService extends CoreBase implements OnDestroy {
   private dataSubject = new BehaviorSubject<IPagingResult>({
      items: [],
      request: {
         filterExpr: undefined, preserveSelected: false, hideDisabledPagers: true
      }
   });
   private loadingSubject = new BehaviorSubject<boolean>(false);
   private browseItems: IBrowseItem[] = [];
   private currentBrowseItem: IBrowseItem;
   private currentBrowseKey: string;
   private currentPage = 0;
   private endOfRecords = false;
   private readonly maxRecords = 50;

   isLoading = this.loadingSubject.asObservable();

   constructor(private miService: MIService) {
      super('PagingService');
   }

   ngOnDestroy() {
      this.dataSubject.complete();
      this.loadingSubject.complete();
   }

   getData(request: SohoDataGridSourceRequest, miRequest: IMIRequest): Observable<any> {
      let browseKey: string = miRequest.program + miRequest.transaction;

      // BrowseKey must include field key for general code records
      if (miRequest.transaction == "LstGeneralCode") {
         browseKey += miRequest.record["STCO"];
         miRequest.division = "";
      } else if (miRequest.transaction == "LstGdeGenCode") {
         browseKey += miRequest.record["CTSTCO"];
         miRequest.division = "";
      }

      // Check if we are browsing for new data
      if (browseKey != this.currentBrowseKey) {
         this.currentPage = 0;
         this.currentBrowseKey = browseKey;
         // Clear existing data
         try {
            this.dataSubject.value.items = [];
         } catch (err) {
            // Do nothing
         }

         // Get browseItem
         if (this.browseItems[this.currentBrowseKey]) {
            this.currentBrowseItem = this.browseItems[this.currentBrowseKey];
         } else {
            this.currentBrowseItem = { items: [], lastRecord: "", endOfRecords: false }
         }
      }
      switch (request.type) {
         case 'initial':
            this.getPage(this.currentPage, request, miRequest);
            break;
         case 'next':
            this.getPage(this.currentPage + 1, request, miRequest);
            break;
         case 'prev':
            this.getPage(this.currentPage - 1, request, miRequest);
            break;
         case 'searched':
            this.currentPage = 0;
            this.browseItems = [];
            this.currentBrowseItem = { items: [], lastRecord: "", endOfRecords: false };
            this.searchData(request, miRequest);
            break;
         default:
            this.logInfo('Unsupported request type: ' + request.type);
      }
      return this.dataSubject.asObservable();
   }

   private getPage(index: number, request?: SohoDataGridSourceRequest, miRequest?: IMIRequest) {
      const nextBatch = this.currentBrowseItem ? this.currentBrowseItem.items[index] : undefined;
      const needMoreRecords = nextBatch === undefined;
      if (index > 0) {
         request.firstPage = false;
      } else {
         request.firstPage = true;
      }
      if (needMoreRecords) {
         this.loadData(request, miRequest);
      } else {
         request.lastPage = this.endOfRecords;
         request.total = this.currentBrowseItem.items[this.currentPage].length;
         this.dataSubject.next({ items: nextBatch, request: request });
      }
      this.currentPage = index;
   }

   private loadData(request?: SohoDataGridSourceRequest, miRequest?: IMIRequest) {
      if (this.currentBrowseItem.endOfRecords) {
         this.logInfo('No more records to fetch');
         return;
      }
      this.loadingSubject.next(true);
      // Set last record as starting point for MI-call
      miRequest.record[miRequest.tag] = this.currentBrowseItem ? this.currentBrowseItem.lastRecord : undefined;
      this.miService.execute(miRequest)
         .pipe(
            catchError((error) => of([])),
            finalize(() => this.loadingSubject.next(false))
         )
         .subscribe((response: IMIResponse) => {
            const items = response.items;
            // Update current browse item with data from MIResponse
            this.currentBrowseItem.items[this.currentPage] = items;
            this.currentBrowseItem.lastRecord = ArrayUtil.last(items)[response.tag];
            this.currentBrowseItem.endOfRecords = items.length === 0 || items.length === 1 || items.length < this.maxRecords;

            this.browseItems[this.currentBrowseKey] = this.currentBrowseItem;
            request.lastPage = this.endOfRecords;
            request.total = this.currentBrowseItem.items[this.currentPage].length;
            this.dataSubject.next({ items: items, request: request });
         }, (error: IMIResponse) => {
            this.logError("Error", error);
         });
   }

   private searchData(request?: SohoDataGridSourceRequest, miRequest?: IMIRequest) {
      this.loadingSubject.next(true);
      // Set field value as starting point for MI-call
      // miRequest.record[miRequest.tag] = fieldValue;
      this.miService.execute(miRequest)
         .pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
         )
         .subscribe((response: IMIResponse) => {
            const items = response.items;
            request.total = response.items.length;
            this.dataSubject.next({ items: items, request: request });
         }, (error: IMIResponse) => {
            this.logError("Error", error);
         });
   }

}
