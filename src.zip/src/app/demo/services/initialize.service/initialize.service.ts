import { Injectable } from '@angular/core';

@Injectable({
   providedIn: 'root',
})

export class DemoInitService {

   constructor() {
   }

   initDataGridOptions(title: string, columns: SohoDataGridColumn[], paging?: boolean, pageSize?: number): SohoDataGridOptions {
      const options: SohoDataGridOptions = {
         alternateRowShading: false,
         cellNavigation: false,
         clickToSelect: true,
         disableRowDeactivation: true,
         filterable: true,
         indeterminate: false,
         paging: paging != null ? paging : true,
         pagesize: pageSize ? pageSize : 25,
         rowHeight: 'short' as SohoDataGridRowHeight,
         selectable: 'single' as SohoDataGridSelectable,
         showFilterTotal: true,
         toolbar: {
            // actions: true,
            // advancedFilter: true,
            // collapsibleFilter: true,
            // dateFilter: false,
            // filterRow: true,
            // keywordFilter: true,
            results: true,
            title: title,
            // views: true,
            // rowHeight: true,
         },
         columns: columns,
         dataset: [],
         emptyMessage: {
            title: 'No data available',
            icon: 'icon-empty-no-data'
         }
      };
      return options;
   }

   initSearchOptions(): SohoSearchFieldOptions {
      const options: SohoSearchFieldOptions = {
      }
      return options;
   }

}
