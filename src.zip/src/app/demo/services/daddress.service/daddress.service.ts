

import { Injectable, OnDestroy } from '@angular/core';
import { MIRecord } from '@infor-up/m3-odin';


@Injectable({
    providedIn: 'root',
 })
export class DestinationAddress {

  public daddressService: MIRecord;
  public deliveryDateService: any;
  public saddressService: MIRecord



   constructor() {
   }

}
