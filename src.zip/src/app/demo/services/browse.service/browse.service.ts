import { Injectable } from '@angular/core';
import { MIService } from '@infor-up/m3-odin-angular';
import { IMIRequest, MIRecord } from '@infor-up/m3-odin';
import { DemoUserContextService } from '../usercontext.service/usercontext.service';

@Injectable({
   providedIn: 'root',
})

export class DemoBrowseService {

   CMS100MI_LstGdeGenCode_Browse_Fields: string[] = [
      "BUAR", "CFI1", "CFI2", "CFI3", "CFI4", "CFI5", "CSCD", "CUCD", "CUCS", "CUCL", "DIGC", "ECAR",
      "EDES", "HAFE", "ITCL", "ITGR", "LNCD", "MODL", "ORCO", "PYCD", "PYME", "SDST", "SMCD", "TAXC",
      "TEAF", "TECD", "TEDL", "TEPA", "TEPY", "UNMS", "VTCD"
   ];

   CRS008MI_ListFacility_Browse_Fields: string[] = [
      "FACI"
   ];

   CRS137MI_LstGeoCodes_Browse_Fields: string[] = [
      "GEOC"
   ];

   CRS610MI_LstByNumber_Browse_Fields: string[] = [
      "CUNO", "PYNO"
   ];

   CRS620MI_LstByNumber_Browse_Fields: string[] = [
      "SUNO"
   ];

   MMS005MI_LstWarehouses_Browse_Fields: string[] = [
      "REWH", "SUWH", "WHLO"
   ];

   MMS010MI_ListLocations_Browse_Fields: string[] = [
      "WHSL"
   ];

   MMS021MI_LstItmHierarchy_Browse_Fields: string[] = [
      "HIE1", "HIE2", "HIE3", "HIE4", "HIE5"
   ];

   MMS050MI_LstPackaging_Browse_Fields: string[] = [
      "PACT"
   ];

   MMS200MI_LstItmByItm_Browse_Fields: string[] = [
      "ITNO"
   ];

   MMS235MI_LstItmLot_Browse_Fields: string[] = [
      "BANO"
   ];

   MNS150MI_LstUserData_Browse_Fields: string[] = [
      "BUYE", "PURC", "RESP", "USID"
   ];

   LanguageDependent: string[] = [
      "MODL", "TEDL", "TEAF", "TEPA", "TEPY"
   ]

   private apiProgram: string;
   private apiTransaction: string;
   private field: string;
   private inputRecord: MIRecord;
   private isSearch: boolean;
   private returnField: string;
   private searchFilter: string;

   constructor(private miService: MIService, private userContextService: DemoUserContextService) {
   }

   /**
    *    This method decides which column fields that should be displayed when
    *    browsing a field
    */
   getBrowseFields(field: string, fieldDescription?: string) {
      const shortField: string = field.substr(field.length - 4);

      if (this.CMS100MI_LstGdeGenCode_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'CTSTKY', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'CTTX15', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.CRS008MI_ListFacility_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'FACI', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'FACN', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.CRS137MI_LstGeoCodes_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'GEOC', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'TAJ1', displayName: 'Jurisdiction 1' },
            { field: 'TAJ2', displayName: 'Jurisdiction 2' },
            { field: 'TAJ3', displayName: 'Jurisdiction 3' }
         ];
      }

      if (this.CRS610MI_LstByNumber_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'CUNO', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'CUNM', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.CRS620MI_LstByNumber_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'SUNO', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'SUNM', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.MMS005MI_LstWarehouses_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'WHLO', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'WHNM', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.MMS010MI_ListLocations_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'WHSL', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'SLDS', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.MMS021MI_LstItmHierarchy_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'HIE0', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'TX15', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.MMS050MI_LstPackaging_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'PACT', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'PANM', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.MMS200MI_LstItmByItm_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'ITNO', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'ITDS', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

      if (this.MMS235MI_LstItmLot_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'BANO', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'BREF', displayName: 'Lot reference', isAdditionalInfo: "true" },
            { field: 'BRE2', displayName: 'Lot reference 2', isAdditionalInfo: "true" }
         ];
      }

      if (this.MNS150MI_LstUserData_Browse_Fields.indexOf(shortField) >= 0) {
         return [
            { field: 'USID', displayName: fieldDescription, isReturnValue: "true" },
            { field: 'TX40', displayName: 'Description', isAdditionalInfo: "true" }
         ];
      }

   }

   /**
    *    This method returns browse dependency fields. For example, to browse for lot
    *    number (BANO) you need to know which item (ITNO) it is for
    */
   getBrowseDependencyFields(field: string): string[] {
      const shortField: string = field.substr(field.length - 4);

      if (this.MMS010MI_ListLocations_Browse_Fields.indexOf(shortField) >= 0) {
         return ["WHLO"];
      }

      if (this.MMS235MI_LstItmLot_Browse_Fields.indexOf(shortField) >= 0) {
         return ["ITNO"];
      }

      return null;
   }

   /**
    *    This method initializes the variables that used for the MIRequest. It returns an MIRequest
    *    object. The returned MIRequest is used by the infinite paging service
    */
   getMIRequest(field: string, inputRecord?: MIRecord, isSearch?: boolean, searchFilter?: string): IMIRequest {
      this.field = field.substr(field.length - 4);
      this.inputRecord = inputRecord;
      this.isSearch = isSearch;
      this.searchFilter = searchFilter;

      // Set record
      let record: MIRecord = this.inputRecord ? this.inputRecord : new MIRecord();
      let searchRecord: MIRecord = new MIRecord();

      if (this.CMS100MI_LstGdeGenCode_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "CMS100MI";
         this.apiTransaction = "LstGdeGenCode";
         this.returnField = "CTSTKY";

         // Set input for list transaction
         record["CTDIVI"] = "";
         record["CTSTCO"] = this.field;
         if (this.LanguageDependent.indexOf(this.field) >= 0) {
            record["CTLNCD"] = this.userContextService.userContext.currentLanguage;
         } else {
            record["CTLNCD"] = "";
         }

         // Set input for search transaction, if any
         if (this.isSearch) {
            this.apiTransaction = "LstGdeGenCodeSe";
            searchRecord["SQRY"] = "STCO:" + this.field + " AND " + this.searchFilter;
            record = searchRecord;
         }

         return this.createRequest(record, this.returnField);
      }

      if (this.CRS008MI_ListFacility_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "CRS008MI";
         this.apiTransaction = "ListFacility";
         this.returnField = "FACI";

         // Set input for list transaction
         record["FACI"] = "";

         // Set input for search transaction, if any
         if (this.isSearch) {
            // No search transaction - use list transaction
         }

         return this.createRequest(record, this.returnField);
      }

      if (this.CRS137MI_LstGeoCodes_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "CRS137MI";
         this.apiTransaction = "LstGeoCodes";
         this.returnField = "GEOC";
         // Set input for list transaction
         record["GEOC"] = "";
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.CRS610MI_LstByNumber_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "CRS610MI";
         this.apiTransaction = "LstByNumber";
         this.returnField = "CUNO";

         // Set input for list transaction
         record["CUNO"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            this.apiTransaction = "SearchCustomer";
            searchRecord["SQRY"] = searchFilter + "*";
            record = searchRecord;
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.CRS620MI_LstByNumber_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "CRS620MI";
         this.apiTransaction = "LstByNumber";
         this.returnField = "SUNO";

         // Set input for list transaction
         record["CUNO"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            this.apiTransaction = "SearchSupplier";
            searchRecord["SQRY"] = searchFilter + "*";
            record = searchRecord;
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MMS005MI_LstWarehouses_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MMS005MI";
         this.apiTransaction = "LstWarehouses";
         this.returnField = "WHLO";

         // Set input for list transaction
         record["FWHL"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MMS010MI_ListLocations_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MMS010MI";
         this.apiTransaction = "ListLocations";
         this.returnField = "WHSL";

         // Set input for list transaction
         record["WHSL"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MMS021MI_LstItmHierarchy_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MMS021MI";
         this.apiTransaction = "LstItmHierarchy";
         this.returnField = "HIE0";

         switch (field) {
            case "HIE1":
               record["HLVL"] = "1";
               break;
            case "HIE2":
               record["HLVL"] = "2";
               break;
            case "HIE3":
               record["HLVL"] = "3";
               break;
            case "HIE4":
               record["HLVL"] = "4";
               break;
            case "HIE5":
               record["HLVL"] = "5";
               break;
         }

         // Set input for list transaction
         record["HIE0"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MMS050MI_LstPackaging_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MMS050MI";
         this.apiTransaction = "LstPackaging";
         this.returnField = "PACT";

         // Set input for list transaction
         record["PACT"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MMS200MI_LstItmByItm_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MMS200MI";
         this.apiTransaction = "LstItmByItm";
         this.returnField = "ITNO";

         // Set input for list transaction
         record["ITNO"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            this.apiTransaction = "SearchItem";
            searchRecord["SQRY"] = searchFilter + "*";
            record = searchRecord;
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MMS235MI_LstItmLot_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MMS235MI";
         this.apiTransaction = "LstItmLot";
         this.returnField = "WHSL";

         // Set input for list transaction
         record["BANO"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

      if (this.MNS150MI_LstUserData_Browse_Fields.indexOf(this.field) >= 0) {
         this.apiProgram = "MNS150MI";
         this.apiTransaction = "LstUserData";
         this.returnField = "USID";

         // Set input for list transaction
         record["USID"] = "";

         // Set input for list transaction
         if (this.isSearch) {
            // No search transaction - use list transaction
         }
         return this.createRequest(record, this.returnField);
      }

   }

   /**
    *    This method creates the MIRrequest
    */
   private createRequest(record: MIRecord, returnField: string): IMIRequest {
      let request: IMIRequest = {
         program: this.apiProgram,
         transaction: this.apiTransaction,
         maxReturnedRecords: 50,
         typedOutput: true,
         record: record,
         tag: returnField
      };
      return request;
   }

}
