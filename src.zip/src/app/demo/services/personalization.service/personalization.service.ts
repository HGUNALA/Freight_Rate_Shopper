import { Injectable } from '@angular/core';
import { MIService, FormService, UserService, } from '@infor-up/m3-odin-angular';
import { ArrayUtil, IFormRequest, IFormResponse, Log, MIRecord } from '@infor-up/m3-odin';
import { Observable, Subject } from 'rxjs';

@Injectable({
   providedIn: 'root',
})

export class DemoPersonalizationService {

   constructor(private miService: MIService, private userService: UserService, private formService: FormService) {
   }

   /**
    *    Public methods
    *
    */

   public getPersonalization(program: string): Observable<IPersonalization> {
      let subject = new Subject<IPersonalization>();
      this.runProgram(program, true).subscribe((response: IFormResponse) => {
         if (response) {

            // Get customization from document
            let xmlCustomization: IXmlCustomization = ({
               xmlConditionalStyles: [],
               xmlHyperLinks: [],
               xmlReplacementTexts: []
            });

            let custElements: any[] = [].slice.call(response.document.getElementsByTagName("Cust"));
            if (custElements.length > 0) {

               for (let custElement of custElements) {
                  if (custElement.hasChildNodes()) {
                     for (let custString of custElement.childNodes) {
                        let custXml = (new DOMParser()).parseFromString(custString.data, "text/xml");
                        xmlCustomization.xmlConditionalStyles = [].slice.call(custXml.getElementsByTagName("ConditionalStyle"));
                        xmlCustomization.xmlHyperLinks = [].slice.call(custXml.getElementsByTagName("HyperLink"));
                        xmlCustomization.xmlReplacementTexts = [].slice.call(custXml.getElementsByTagName("ReplacementText"));
                     }
                  }
               }
            }

            // Parse customization
            const customization: IPersonalization = this.parseCustomization(program, xmlCustomization);

            // Close program
            const sid: string = response.sessionId;
            const iid: string = response.instanceId;
            this.closeProgram(sid, iid, program).subscribe((response: IFormResponse) => {
               if (response) {
                  Log.debug("Personalization for program " + program + " retrieved. Program closed");
               }
            });
            subject.next(customization);
         }
      });
      return subject.asObservable();
   }

   public getConditionalStyle(personalization: IPersonalization, field: string, value: any, record?: MIRecord): string {
      if (personalization) {
         try {
            let conditionalStyle: IConditionalStyle;
            if (ArrayUtil.itemByProperty(personalization.conditionalStyles, "field", field)) {
               conditionalStyle = this.trySetConditionalStyle(personalization, field, value, record);
               if (conditionalStyle) {
                  return this.getClassName(personalization.program, conditionalStyle, false);
               }
            }
            return null;
         } catch (err) {
            Log.error(err);
            return null;
         }
      }
   }

   public getReplacementText(personalization: IPersonalization, field: string, value: any, record?: MIRecord): string {
      if (personalization) {
         try {
            let conditionalStyle: IConditionalStyle;
            let replacementText: string;

            conditionalStyle = this.trySetConditionalStyle(personalization, field, value, record);
            if (conditionalStyle) {
               if (conditionalStyle.attributes.text) {
                  return conditionalStyle.attributes.text;
               }
            }

            return null;
         } catch (err) {
            Log.error(err);
            return null;
         }
      }
   }

   public fieldHasPersonalization(personalization: IPersonalization, field: string): boolean {
      if (personalization) {
         try {
            let conditionalStyle: IConditionalStyle;
            if (ArrayUtil.itemByProperty(personalization.conditionalStyles, "field", field)) {
               return true;
            } else {
               return false;
            }
         } catch (err) {
            Log.error(err);
            return false;
         }
      }
   }

   public parseCustomization(program: string, xmlCustomization: IXmlCustomization): IPersonalization {
      if (xmlCustomization) {
         try {
            let conditionalStyles: IConditionalStyle[] = this.parseConditionalStyle(xmlCustomization);
            let hyperLinks: IHyperLink[] = this.parseHyperLinks(xmlCustomization);
            let replacementTexts: IReplacementText[] = this.parseReplacementText(xmlCustomization);
            let personalization: IPersonalization = {
               conditionalStyles: conditionalStyles,
               hyperLinks: hyperLinks,
               replacementTexts: replacementTexts,
               program: program
            }
            if (personalization.conditionalStyles.length > 0 ||
               personalization.hyperLinks.length > 0 ||
               personalization.replacementTexts.length > 0) {
               if (!document.getElementById(program)) {
                  this.createStyleSheet(program, personalization);
               }
            }
            return personalization;
         } catch (err) {
            Log.error(err);
         }
      }
   }

   /**
    *    Private methods
    *
    */

   private createStyleSheet(program: string, personalization: IPersonalization) {
      let sheet = document.createElement('style');
      sheet.setAttribute("id", program);
      sheet.innerHTML = "";
      for (let conditionalStyle of personalization.conditionalStyles) {
         let styleClass: string = this.getClassName(program, conditionalStyle, true);
         let styleAttributes: string = this.getClassAttributes(conditionalStyle);
         sheet.innerHTML += styleClass;
         // Conditional styles for detail fields (that has length 6) do not have children of type div
         if (!conditionalStyle.field || conditionalStyle.field.length != 6) {
            sheet.innerHTML += " > div > div ";
         }
         sheet.innerHTML += styleAttributes;
         sheet.innerHTML += " ";
      }
      document.body.appendChild(sheet);
   }

   private getClassAttributes(conditionalStyle: IConditionalStyle): string {
      let attributes: string = " { ";
      if (conditionalStyle.attributes.background) {
         attributes += "background: " + conditionalStyle.attributes.background;
         attributes += "!important;"
      }
      if (conditionalStyle.attributes.foreground) {
         attributes += "color: " + conditionalStyle.attributes.foreground;
         attributes += "!important;"
      }
      attributes += " }";
      return attributes;
   }

   private getClassName(program: string, conditionalStyle: IConditionalStyle, includeDot: boolean): string {
      let name: string;
      name = includeDot ? "." : "";
      name += program;
      name += "-";
      name += conditionalStyle.condition.field;
      name += "-";
      name += conditionalStyle.condition.operand;
      name += "-";
      name += conditionalStyle.condition.operator;
      name += "-";
      name += conditionalStyle.condition.type;
      name += "-";
      if (conditionalStyle.condition.operator.toString() === "6") {
         //Range
         name += conditionalStyle.condition.from;
         name += "-";
         name += conditionalStyle.condition.to;
      } else {
         name += conditionalStyle.condition.value;
      }
      return name;
   }

   private getCondition(conditionArray: any[]): IConditionalStyleCondition {
      let field: string = null;
      let operand: number = null;
      let operator: number = null;
      let value: string = null;
      let from: string = null;
      let to: string = null;
      let type: number = null;

      for (let condition of conditionArray) {
         switch (condition["name"]) {
            case "field":
               field = condition["value"];
               break;
            case "operand":
               operand = condition["value"];
               break;
            case "operator":
               operator = condition["value"];
               break;
            case "value":
               value = condition["value"];
               break;
            case "from":
               from = condition["value"];
               break;
            case "to":
               to = condition["value"];
               break;
            case "type":
               type = condition["value"];
               break;
         }
      }
      let condition: IConditionalStyleCondition = {
         field: field,
         operand: operand,
         operator: operator,
         value: value,
         from: from,
         to: to,
         type: type
      }
      return condition;
   }

   private getConditionalStyleAttributes(attributeArray: any[]): IConditionalStyleAttributes {
      let alignment: string = null;
      let background: string = null;
      let enabled: boolean = null;
      let foreground: string = null;
      let hasbackground: boolean = null;
      let hasforeground: boolean = null;
      let name: string = null;
      let target: string = null;
      let text: string = null;
      let tooltip: string = null;
      let type: number = null;
      let version: number = null;

      for (let attribute of attributeArray) {
         switch (attribute["name"]) {
            case "alignment":
               alignment = attribute["value"];
               break;
            case "background":
               background = "#" + attribute["value"].toString().substring(3);
               break;
            case "enabled":
               enabled = attribute["value"];
               break;
            case "foreground":
               foreground = "#" + attribute["value"].toString().substring(3);
               break;
            case "hasbackground":
               hasbackground = attribute["value"];
               break;
            case "hasforeground":
               hasforeground = attribute["value"];
               break;
            case "name":
               name = attribute["value"];
               break;
            case "target":
               target = attribute["value"];
               break;
            case "text":
               text = attribute["value"];
               break;
            case "tooltip":
               tooltip = attribute["value"];
               break;
            case "type":
               type = attribute["value"];
               break;
            case "version":
               version = attribute["value"];
               break;
         }
      }

      let attributes: IConditionalStyleAttributes = {
         alignment: alignment,
         background: background,
         enabled: enabled,
         foreground: foreground,
         hasbackground: hasbackground,
         hasforeground: hasforeground,
         name: name,
         target: target,
         text: text,
         tooltip: tooltip,
         type: type,
         version: version
      }
      return attributes;
   }

   private getHyperLinkAttributes(attributeArray: any[]): IHyperLinkAttributes {
      let column: string = null;
      let externalbrowser: string = null;
      let id: string = null;
      let option: number = null;
      let text: string = null;
      let tooltip: string = null;
      let url: string = null;

      for (let attribute of attributeArray) {
         switch (attribute["name"]) {
            case "column":
               column = attribute["value"];
               break;
            case "externalbrowser":
               externalbrowser = attribute["value"];
               break;
            case "id":
               id = attribute["value"];
               break;
            case "option":
               option = attribute["value"];
               break;
            case "text":
               text = attribute["value"];
               break;
            case "tooltip":
               tooltip = attribute["value"];
               break;
            case "url":
               url = attribute["value"];
               break;
         }
      }

      let attributes: IHyperLinkAttributes = {
         column: column,
         externalBrowser: externalbrowser,
         id: id,
         option: option,
         text: text,
         tooltip: tooltip,
         url: url
      }
      return attributes;
   }

   private getReplacementTextAttributes(attributeArray: any[]): IReplacementTextAttributes {
      let column: string = null;
      let originaltext: string = null;
      let text: string = null;

      for (let attribute of attributeArray) {
         switch (attribute["name"]) {
            case "column":
               column = attribute["value"];
               break;
            case "originalText":
               originaltext = attribute["value"];
               break;
            case "text":
               text = attribute["value"];
               break;
         }
      }

      let attributes: IReplacementTextAttributes = {
         column: column,
         originaltext: originaltext,
         text: text
      }
      return attributes;
   }

   private closeProgram(sid: string, iid: string, program: string): Observable<IFormResponse> {
      const programrequest = {
         commandType: "FNC",
         commandValue: "ENDPGM",
         params: {
            SID: sid,
            IID: iid
         },
         sessionId: sid
      }
      const request: IFormRequest = programrequest;
      return this.formService.executeRequest(request);
   }

   private parseConditionalStyle(xmlCustomization: IXmlCustomization) {
      try {
         let conditionalStyles: IConditionalStyle[] = [];
         if (xmlCustomization.xmlConditionalStyles) {
            let xmlCSArray = Array.prototype.slice.call(xmlCustomization.xmlConditionalStyles);
            for (let xmlCS of xmlCSArray) {
               let attributes: IConditionalStyleAttributes;
               let condition: IConditionalStyleCondition;
               let xmlCSAttributesArray = Array.prototype.slice.call(xmlCS.attributes);
               let xmlCSConditionArray = Array.prototype.slice.call(xmlCS.firstElementChild.attributes);
               attributes = this.getConditionalStyleAttributes(xmlCSAttributesArray);
               condition = this.getCondition(xmlCSConditionArray);
               let conditionalStyle: IConditionalStyle = {
                  field: attributes.target,
                  attributes: attributes,
                  condition: condition
               }
               conditionalStyles.push(conditionalStyle);
            }
         }
         return conditionalStyles;
      } catch (err) {
         Log.error(err);
      }
   }

   private parseHyperLinks(xmlCustomization: IXmlCustomization) {
      try {
         let hyperLinks: IHyperLink[] = [];
         if (xmlCustomization.xmlReplacementTexts) {
            let xmlHLArray = Array.prototype.slice.call(xmlCustomization.xmlHyperLinks);
            for (let xmlHL of xmlHLArray) {
               let attributes: IHyperLinkAttributes;
               let xmlHLAttributesArray = Array.prototype.slice.call(xmlHL.attributes);
               attributes = this.getHyperLinkAttributes(xmlHLAttributesArray);
               let hyperLink: IHyperLink = {
                  field: attributes.column,
                  attributes: attributes
               }
               hyperLinks.push(hyperLink);
            }
         }
         return hyperLinks;
      } catch (err) {
         Log.error(err);
      }
   }

   private parseReplacementText(xmlCustomization: IXmlCustomization) {
      try {
         let replacementTexts: IReplacementText[] = [];
         if (xmlCustomization.xmlReplacementTexts) {
            let xmlRTArray = Array.prototype.slice.call(xmlCustomization.xmlReplacementTexts);
            for (let xmlRT of xmlRTArray) {
               let attributes: IReplacementTextAttributes;
               let xmlRTAttributesArray = Array.prototype.slice.call(xmlRT.attributes);
               attributes = this.getReplacementTextAttributes(xmlRTAttributesArray);
               let replacementText: IReplacementText = {
                  field: attributes.column,
                  attributes: attributes
               }
               replacementTexts.push(replacementText);
            }
         }
         return replacementTexts;
      } catch (err) {
         Log.error(err);
      }
   }

   private runProgram(program: string, isLoadCst?: boolean): Observable<IFormResponse> {
      const cstload = isLoadCst ? 1 : 2;
      const programrequest = {
         commandType: "RUN",
         commandValue: program,
         params: {
            CSTLOAD: cstload
         },
      }
      const request: IFormRequest = programrequest;
      return this.formService.executeRequest(request);
   }

   private trySetConditionalStyle(personalization: IPersonalization, field: string, value: any, record?: MIRecord): IConditionalStyle {
      let isFound: boolean;
      for (let conditionalStyle of personalization.conditionalStyles) {
         if (conditionalStyle.field == field) {
            isFound = this.validateConditionalStyle(conditionalStyle, value, record);
            if (isFound) {
               return conditionalStyle;
            }
         }
      }
      return null;
   }

   private validateConditionalStyle(conditionalStyle: IConditionalStyle, value: any, record?: MIRecord): boolean {

      // let fieldValue = value;

      try {

         let fieldValue = null;

         // The conditional style is based on the current field
         if (conditionalStyle.field == conditionalStyle.condition.field) {
            fieldValue = value;
         } else {
            // The conditional style is based on another field
            const keys = Object.keys(record);
            for (let key of keys) {
               const shortKey = key.substr(key.length - 4);
               if (shortKey == conditionalStyle.condition.field) {
                  fieldValue = record[key];
                  break;
               }
            }
         }

         // Return false if we do not have a field value
         if (fieldValue == null) {
            return false;
         }


         /**
          *    Check the conditions of the conditional
          */


         // Equals
         if (conditionalStyle.condition.operator == 0) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue == conditionalStyle.condition.value) {
                  return true;
               }
            }

            // Does not equal
         } else if (conditionalStyle.condition.operator == 1) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue != conditionalStyle.condition.value) {
                  return true;
               }
            }

            // Greater than
         } else if (conditionalStyle.condition.operator == 2) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue > conditionalStyle.condition.value) {
                  return true;
               }
            }

            // Greater than or equal
         } else if (conditionalStyle.condition.operator == 3) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue >= conditionalStyle.condition.value) {
                  return true;
               }
            }

            // Less than
         } else if (conditionalStyle.condition.operator == 4) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue < conditionalStyle.condition.value) {
                  return true;
               }
            }

            // Less than or equal
         } else if (conditionalStyle.condition.operator == 5) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue <= conditionalStyle.condition.value) {
                  return true;
               }
            }

            // Range
         } else if (conditionalStyle.condition.operator == 6) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue >= conditionalStyle.condition.from && fieldValue <= conditionalStyle.condition.to) {
                  return true;
               }
            }

            // Contains
         } else if (conditionalStyle.condition.operator == 7) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue.indexOf(conditionalStyle.condition.value) > -1) {
                  return true;
               }
            }

            // Starts with
         } else if (conditionalStyle.condition.operator == 8) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue.indexOf(conditionalStyle.condition.value) == 0) {
                  return true;
               }
            }

            // Ends with
         } else if (conditionalStyle.condition.operator == 9) {
            // Specific value
            if (conditionalStyle.condition.operand == 1) {
               if (fieldValue.match(/conditionalStyle.condition.value$/)) {
                  return true;
               }
            }
         }

         // If we end up here then return false
         return false;

      } catch (err) {
         // Something went wrong, return false
         return false;
      }

   }

}

export interface IConditionalStyle {
   field: string,
   attributes: IConditionalStyleAttributes,
   condition: IConditionalStyleCondition
}

export interface IConditionalStyleAttributes {
   alignment: string,
   background: string,
   enabled: boolean,
   foreground: string,
   hasbackground: boolean,
   hasforeground: boolean,
   name: string,
   target: string,
   text: string,
   tooltip: string,
   type: number,
   version: number
}

export interface IConditionalStyleCondition {
   field: string,
   from: string,
   operand: number,
   operator: number,
   to: string,
   type: number,
   value: string
}

export interface IPersonalization {
   conditionalStyles: IConditionalStyle[],
   hyperLinks: IHyperLink[],
   replacementTexts: IReplacementText[],
   program?: string
}

export interface IHyperLink {
   field: string,
   attributes: IHyperLinkAttributes
}

export interface IHyperLinkAttributes {
   column: string,
   externalBrowser: string,
   id: string,
   option: number,
   text: string,
   tooltip: string,
   url: string
}

export interface IReplacementText {
   field: string,
   attributes: IReplacementTextAttributes,
}

export interface IReplacementTextAttributes {
   column: string,
   originaltext: string,
   text: string
}

export interface IXmlCustomization {
   xmlConditionalStyles: HTMLCollection[],
   xmlHyperLinks: HTMLCollection[],
   xmlReplacementTexts: HTMLCollection[]
}
