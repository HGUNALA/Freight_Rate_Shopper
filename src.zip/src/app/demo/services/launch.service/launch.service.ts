import { Injectable } from '@angular/core';
import { MIService, FormService, ApplicationService, } from '@infor-up/m3-odin-angular';
import { IBookmark } from '@infor-up/m3-odin';
import { DemoUserContextService } from '../usercontext.service/usercontext.service';


@Injectable({
   providedIn: 'root',
})

export class DemoLaunchService {

   constructor(private userContextService: DemoUserContextService, private appService: ApplicationService, private miService: MIService, private formService: FormService) {
   }

   public launchBookmark(bookmark: IBookmark) {
      let frameElement = (window.self !== window.top);
      let prefix: string = frameElement ? "mforms://" : "mforms%3A%2F%2F";

      let task: string;
      let query: string;
      let fields: string[];
      let fieldNames: string[];

      fields = bookmark.fields ? bookmark.fields.split(",") : undefined;
      fieldNames = bookmark.fieldNames ? bookmark.fieldNames.split(",") : undefined;

      query = "";
      query += "bookmark?program=" + bookmark.program;
      query += "&tablename=" + bookmark.table;
      query += "&keys=";

      const keys = bookmark.keyNames.split(',');
      const values = bookmark.values;

      let keyFieldsValues = "";
      for (let key of keys) {
         keyFieldsValues += key;
         keyFieldsValues += ",";
         const shortKey = key.substr(key.length - 4);
         if (shortKey == "CONO") {
            keyFieldsValues += this.userContextService.userContext.currentCompany;
         } else {
            keyFieldsValues += values[key] ? values[key] : values[shortKey];
         }
         keyFieldsValues += ",";
      }

      query += keyFieldsValues;

      bookmark.sortingOrder ? query += "&sortingorder=" + bookmark.sortingOrder : null;
      bookmark.view ? query += "&view=" + bookmark.view : null;
      bookmark.startPanel ? query += "&startpanel=" + bookmark.startPanel : "B";
      bookmark.includeStartPanel != undefined ? query += "&includestartpanel=" + bookmark.includeStartPanel : null;
      bookmark.option ? query += "&option=" + bookmark.option : null;
      bookmark.panel ? query += "&panel=" + bookmark.panel : null;
      bookmark.panelSequence ? query += "&panelsequence=" + bookmark.panelSequence : null;
      bookmark.requirePanel != undefined ? query += "&requirepanel=" + bookmark.requirePanel : null;

      task = query;

      if (frameElement) {
         return this.appService.launch(task);
      }
   }

   public launchProgram(program: string) {
      const frameElement = (window.self !== window.top);
      const prefix: string = frameElement ? "mforms://" : "mforms%3A%2F%2F";
      const task = prefix + program;
      if (frameElement) {
         return this.appService.launch(task);
      }
   }

   private addComma(element: any) {
      if (frameElement) {
         return ",";
      } else {
         return "%2C";
      }

   }

}
