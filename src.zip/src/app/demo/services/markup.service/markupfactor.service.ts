import { Injectable, OnDestroy } from '@angular/core';


@Injectable({
    providedIn: 'root',
 })
export class MarkUpFactor {

  public markupfactor: number;



   constructor() {
   }

}
