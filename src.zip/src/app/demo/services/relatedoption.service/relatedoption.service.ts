import { Injectable, EventEmitter, ViewContainerRef } from '@angular/core';
import { IDrillBack, IAction, ICustomAction, IRelated } from 'src/app/demo/related-option/related-option/related-option.component';
import { MIRecord, IBookmark, Log } from '@infor-up/m3-odin';
import { SohoContextualActionPanelRef } from 'ids-enterprise-ng';

@Injectable({
   providedIn: 'root',
})

export class DemoRelatedOptionService {

   actions: IAction[] = [];
   customActions: ICustomAction[] = [];
   bookmark: IBookmark;
   drillBacks: IDrillBack[] = [];
   relateds: IRelated[] = [];

   selectedAction: IAction;
   selectedRecord: MIRecord;

   /**
    *    These variables are used to show a contextual dialog
    */
   panelRef: SohoContextualActionPanelRef<any>;
   placeHolder: ViewContainerRef;

   /**
    *    Event emitters
    */
   customActionClickedEvent: EventEmitter<ICustomAction> = new EventEmitter();
   relatedsChangedEvent: EventEmitter<IRelated[]> = new EventEmitter();
   recordSelectedEvent: EventEmitter<IRelated> = new EventEmitter();

   constructor() {
   }

   customActionClicked(customAction: ICustomAction) {
      this.customActionClickedEvent.emit(customAction);
   }

   removeRelated(related: IRelated) {
      try {
         const index = this.relateds.map(e => e.name).indexOf(related.name);
         if (index >= 0) {
            this.relateds.splice(index, 1);
            this.relatedsChangedEvent.emit(this.relateds);
         }
      } catch (err) {
         Log.info("The related object is invalid");
      }
   }

   setRelated(related: IRelated) {
      try {
         const index = this.relateds.map(e => e.name).indexOf(related.name);
         if (index == -1) {
            this.relateds.push(related);
            // Sort alphanumerically
            this.relateds.sort((a, b) => {
               if (a.name > b.name) {
                  return 1;
               } else {
                  return -1;
               }
            })
            this.relatedsChangedEvent.emit(this.relateds);
         }
      } catch (err) {
         Log.info("The related object is invalid");
      }
   }

   setSelectedRecord(related: IRelated) {
      this.recordSelectedEvent.emit(related);
   }

}
