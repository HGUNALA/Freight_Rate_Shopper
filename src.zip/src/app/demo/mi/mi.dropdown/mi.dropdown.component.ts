import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { CoreBase, IMIRequest, IMIResponse, MIRecord, ArrayUtil } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { SohoMessageService } from 'ids-enterprise-ng';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';

@Component({
   selector: 'demo-drop-down',
   styleUrls: ['./mi.dropdown.component.css'],
   templateUrl: './mi.dropdown.component.html'
})
export class DemoMiDropdownComponent extends CoreBase implements OnInit {

   // Additional info such as description or name
   @Input() additionalInfoField: string;

   // MIRecord that is used to retrieve the data for the dropdown
   @Input() apiInputRecord: MIRecord;

   // The API program used to retrieve the data for the dropdown
   @Input() apiProgram: string;

   // The API transaction used to retrieve the data for the dropdown
   @Input() apiTransaction: string;

   // Field to be displayed in the dropdown
   @Input() field: string;

   // Heading
   @Input() heading: string;

   // Disabled / readonly
   @Input() disabled: boolean;

   // MIRecord that can be set at startup (for example default user warehouse)
   @Input() initialRecord: MIRecord;

   /**
    *    Value that can be set at startup (for example default user warehouse)
    */
   @Input() initialValue: string;

   // Event emitter when the selected value changes
   @Output() recordChanged: EventEmitter<MIRecord> = new EventEmitter<MIRecord>();

   isBusy = false;
   isReady = false;
   record: MIRecord;
   records: MIRecord[] = [];
   selectedIndex: number;

   private maxRecords = 999;

   constructor(private miService: MIService, private messageService: SohoMessageService) {
      super('DemoMiDropdownComponent');
   }

   ngOnInit(): void {
      this.callApi(this.apiProgram, this.apiTransaction, this.apiInputRecord);
   }

   private callApi(program: string, transaction: string, record?: MIRecord) {
      if (this.isBusy) {
         return;
      }

      this.isBusy = true;

      const request: IMIRequest = {
         includeMetadata: true,
         program: program,
         transaction: transaction,
         record: record,
         maxReturnedRecords: this.maxRecords,
         typedOutput: true
      };

      this.miService.execute(request).subscribe((response: IMIResponse) => {
         if (!response.hasError()) {
            this.onResponse(response);
         } else {
            this.onError('Failed to list transaction data');
         }
         this.isBusy = false;
      }, (error: MIResponse) => {
         this.isBusy = false;
         if (error.errorCode != "XRE0103") {
            this.onError('Failed to list transaction data', error);
         }
      });

   }

   onChange() {
      this.recordChanged.emit(this.record);
   }

   private onError(message: string, error?: any) {
      this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('An error occured')
         .message(message + '. More details might be available in the browser console.')
         .buttons(buttons)
         .open();
   }

   private onResponse(response: IMIResponse) {
      this.records = response.items;
      if (this.initialRecord) {
         if (ArrayUtil.containsByProperty(this.records, this.field, this.initialRecord[this.field])) {
            this.record = ArrayUtil.itemByProperty(this.records, this.field, this.initialRecord[this.field])
            this.onChange();
         }
      }
      if (this.initialValue) {
         if (ArrayUtil.containsByProperty(this.records, this.field, this.initialValue)) {
            this.record = ArrayUtil.itemByProperty(this.records, this.field, this.initialValue)
            this.onChange();
         }
      }
      this.isReady = true;
   }

}
