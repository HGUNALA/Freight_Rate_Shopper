import { Component, Input, Output, EventEmitter, ViewChild, AfterViewInit, ViewEncapsulation, SimpleChanges } from '@angular/core';
import { CoreBase, IMIRequest, IMIResponse, MIRecord, ArrayUtil, Log } from '@infor-up/m3-odin';
import { MIService } from '@infor-up/m3-odin-angular';
import { SohoMessageService, SohoLookupComponent } from 'ids-enterprise-ng';
import { MIResponse } from '@infor-up/m3-odin/dist/mi/runtime';
import { DemoBrowseService } from '../../services/browse.service/browse.service';
import { DemoPagingService, IPagingResult } from '../../services/paging.service/paging.service';

@Component({
   encapsulation: ViewEncapsulation.None,
   selector: 'demo-lookup',
   styleUrls: ['./mi.lookup.component.css'],
   templateUrl: './mi.lookup.component.html'
})
export class DemoMiLookupComponent extends CoreBase implements AfterViewInit {


   // Additional info such as description or name
   @Input() additionalInfoField: string;

   // MIRecord that is used to retrieve the data for the dropdown
   @Input() apiInputRecord: MIRecord;

   // The API program used to retrieve the data for the dropdown
   @Input() apiProgram: string;

   // The API transaction used to retrieve the data for the dropdown
   @Input() apiTransaction: string;

   // Field to be displayed in the lookup
   @Input() field: string;

   // Heading
   @Input() heading: string;

   // Readonly
   @Input() readonly: boolean;

   // MIRecord that can be set at startup
   @Input() initialRecord: MIRecord;

   /**
    *    Value that can be set at startup (for example default user warehouse). An API call
    *    will be done to retrieve any additional info (for example warehouse name).
    */
   @Input() initialValue: string;

   // Event emitter when the selected value changes
   @Output() recordChanged: EventEmitter<MIRecord> = new EventEmitter<MIRecord>();

   @ViewChild(SohoLookupComponent) lookup: SohoLookupComponent;

   // Local variables
   _value: string;
   currentBrowseField: string;
   isBusy: boolean = false;
   isReady: boolean = false;
   record: MIRecord;
   private maxRecords = 200;

   constructor(private miService: MIService,
      private messageService: SohoMessageService,
      private demoBrowseService: DemoBrowseService,
      private demoPagingService: DemoPagingService) {
      super('DemoMiLookupComponent');
   }

   ngAfterViewInit() {
      this.initGrid(this.lookup);

      /**
       *    Set initial record or value
       */

      if (this.initialRecord) {
         this.initRecord();
      } else if (this.initialValue) {
         this.initValue();
      }

      // Don't set focus
      this.lookup["element"].nativeElement.blur();
   }

   onBrowse(request: SohoDataGridSourceRequest, response: SohoDataGridResponseFunction, field: string) {

      // Initialize variables
      let currentValue: string;
      let rcd: MIRecord = new MIRecord();

      if (this.apiInputRecord) {
         rcd = this.apiInputRecord;
      }

      // Set current browse field so we can update additionalInfo later on
      this.currentBrowseField = field;

      // Check and set search variables
      if (request.type == "searched") {
         const searchFilter = request.filterExpr[0].value.toLocaleUpperCase();
         rcd[this.field] = searchFilter;
      }

      if (this.isBusy) {
         return;
      }

      this.isBusy = true;

      const miRequest: IMIRequest = {
         includeMetadata: true,
         program: this.apiProgram,
         transaction: this.apiTransaction,
         record: rcd,
         maxReturnedRecords: this.maxRecords,
         typedOutput: true
      };

      this.miService.execute(miRequest).subscribe((miResponse: IMIResponse) => {
         if (!miResponse.hasError()) {
            // Set total items found
            request.total = miResponse.items.length;

            // Save current value
            try {
               currentValue = this.lookup["element"].nativeElement.value;
               // ...and clear current value to avoid autoselect in Soho datagrid
               this.lookup["element"].nativeElement.value = "";
            } catch (err) {
               Log.error(err);
            }

            // Handle lookup datagrid
            response(miResponse.items, request)

            // Restore current value
            try {
               this.lookup["element"].nativeElement.value = currentValue;
            } catch (err) {
               Log.error(err);
            }

         } else {
            this.onError('Failed to list transaction data');
         }
         this.isBusy = false;
      }, (error: MIResponse) => {
         this.isBusy = false;
         if (error.errorCode != "XRE0103") {
            this.onError('Failed to list transaction data', error);
         }
      });
   }

   onChange(event: any) {

      // Initialize variables
      let currentValue: string;
      let rcd: MIRecord = new MIRecord();

      try {
         if (event.length) {
            if (event[0].data) {

               /**
                *    If we have selected a record in the lookup browse datagrid we will
                *    get an object back. Set the record and exit method.
                */

               if (typeof (event[0].data) == "object") {
                  this.record = event[0].data;
                  this.recordChanged.emit(this.record);
                  return;

               } else {
                  currentValue = event[0].data;
               }
            }

         } else {

            /**
             *    If we have keyed in a value manually in the lookup we end up here. Set
             *    the value and then make an API call below to retrieve the record
             */

            currentValue = event.target.value.toLocaleUpperCase();
         }

         /**
          *    If value is blank, then clear record and exit method
          */
         if (currentValue == "") {
            this.record = null;
            this.recordChanged.emit(this.record);
            return;
         }

         /**
          *    Get MI record
          */

         // let request: IMIRequest = this.demoBrowseService.getMIRequest(this.field, this.apiInputRecord, false, null);
         // request.maxReturnedRecords = 1;

         if (this.apiInputRecord) {
            rcd = this.apiInputRecord;
         }

         if (currentValue) {
            rcd[this.field] = currentValue;
         }

         const request: IMIRequest = {
            includeMetadata: true,
            program: this.apiProgram,
            transaction: this.apiTransaction,
            record: rcd,
            maxReturnedRecords: 1,
            typedOutput: true
         };

         this.miService.execute(request).subscribe((response: IMIResponse) => {
            if (!response.hasError()) {
               if (response.item) {
                  let responseValue = response.item[this.field];

                  /**
                   *    If we have match then set the record
                   */

                  if (responseValue == currentValue) {
                     this.record = response.item;
                     this.recordChanged.emit(this.record);
                  } else {
                     let message: string = this.heading + " " + currentValue + " does not exist";
                     const buttons = [{
                        text: 'OK',
                        click: (e, modal) => {
                           modal.close();
                        }
                     }];
                     this.messageService.error()
                        .title('Error')
                        .message(message)
                        .buttons(buttons)
                        .open();
                  }
               } else {
                  const message = this.heading + " " + currentValue + " not found";
                  this.showErrorMessage(message);
               }
            }
         }, (errorResponse: MIResponse) => {
            this.showErrorMessage(errorResponse.errorMessage);
         });
      } catch (err) {
         Log.error(err);
      }
   }

   private onError(message: string, error?: any) {
      this.logError(message, error ? '- Error: ' + JSON.stringify(error) : '');
      const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
      this.messageService.error()
         .title('An error occured')
         .message(message + '. More details might be available in the browser console.')
         .buttons(buttons)
         .open();
   }

   private initRecord() {
      const event: SohoLookupChangeEvent = {
         elem: null,
         data: this.initialRecord,
         idx: null,
         value: null
      }
      const events: SohoLookupChangeEvent[] = [event];
      this.lookup.setValue(events);
   }

   private initValue() {
      const event: SohoLookupChangeEvent = {
         elem: null,
         data: this.initialValue,
         idx: null,
         value: null
      }
      const events: SohoLookupChangeEvent[] = [event];
      this.lookup.setValue(events);
   }

   private initGrid(lookup: SohoLookupComponent) {

      // let browseFields = this.demoBrowseService.getBrowseFields(this.field);
      // let columns: SohoDataGridColumn[] = this.getBrowseColumns(lookup, browseFields);
      let columns: SohoDataGridColumn[] = [];

      // Field
      columns.push({
         width: 'auto',
         id: 'col-key',
         field: this.field,
         name: this.heading,
         resizable: false,
         filterType: 'text',
         sortable: false
      })

      // Additional Information
      columns.push({
         width: 'auto',
         id: 'col-' + this.additionalInfoField,
         field: this.additionalInfoField,
         name: 'Description',
         resizable: false,
         filterType: 'text',
         sortable: false
      })

      // Set lookup field
      lookup["lookup"].settings.field = this.field;

      // Set datagrid options
      const options: SohoDataGridOptions = {
         alternateRowShading: false,
         cellNavigation: false,
         clickToSelect: true,
         columns: columns,
         dataset: [],
         disableRowDeactivation: true,
         emptyMessage: {
            title: 'No records available',
            icon: 'icon-empty-no-data'
         },
         idProperty: 'col-key',
         indeterminate: true,
         paging: true,
         pagesize: 50,
         rowHeight: 'medium' as SohoDataGridRowHeight,
         selectable: 'single',
         showPageSizeSelector: false,
         toolbar: {
            keywordFilter: true,
         },
         source: (request: SohoDataGridSourceRequest, response: SohoDataGridResponseFunction) => {
            this.onBrowse(request, response, this.field);
         }
      }
      // Update lookup settings
      lookup["lookup"].settings.options = options;
   }

   private showErrorMessage(message: string) {
      const buttons = [{
         text: 'OK',
         click: (e, modal) => {
            modal.close();
         }
      }];
      this.messageService.error()
         .title('Error')
         .message(message)
         .buttons(buttons)
         .open();
   }

}
