import { Component, ViewEncapsulation } from '@angular/core';
import { CoreBase, MIRecord } from '@infor-up/m3-odin';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute } from '@angular/router';

@Component({
   styleUrls: ['./main-page.component.css'],
   templateUrl: './main-page.component.html',
   encapsulation: ViewEncapsulation.None
})
export class MainPageComponent extends CoreBase {

   isReady: boolean= true;
   selectedOrder: MIRecord;
   selectedOrderDetails: MIRecord;
   visibility = false;
   selectedRate: MIRecord;

   constructor(
      private activatedRoute: ActivatedRoute,
      public translate: TranslateService) {
      super('MainPageComponent');

      /**
       *    Receive data from the URL
       */
      this.activatedRoute.queryParams.subscribe(params => {
         console.log(params)
         let selectedData: string = params['selectedRecord'];
         console.log(selectedData)

         if (selectedData) {
            let record = new MIRecord();
            console.log(record)
            let dataArray: string[] = selectedData.split(",");
            let key = dataArray[0];
            console.log(dataArray)
            let value = dataArray[1];
            record[key] = value;
            this.selectedOrder = record;
            console.log(this.selectedOrder);
            this.selectedRate = record;
         }
      });

   }

   public onOrderDetailsChanged(record: MIRecord) {
      this.selectedOrderDetails = record;
      console.log(this.selectedOrderDetails + '  Order detiled changed');
      if (record && this.selectedOrderDetails) {
         record["ORNO"] = this.selectedOrder;

      }
      this.selectedRate = record;
      console.log(this.selectedRate)

   }

   public onRateChanged(record: MIRecord) {
      // Pass in the delivery method from the order
      if (record && this.selectedOrderDetails) {
         record["ORNO"] = this.selectedOrder;
         this.selectedRate = record;
         console.log(this.selectedRate)
      }


   }

}
